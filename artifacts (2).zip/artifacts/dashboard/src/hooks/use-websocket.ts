import { useEffect, useRef, useCallback, useState } from "react";
import type { LogEntry, BotStatus, QrResponse, CommandCategory } from "@workspace/api-client-react";

export type WsStatus = "connecting" | "connected" | "disconnected";
export type CommandsStatus = "loading" | "loaded" | "error";

export interface WsMessage {
  type: "status" | "qr" | "log" | "pong";
  data: unknown;
  ts: number;
}

interface UseWebSocketReturn {
  wsStatus: WsStatus;
  liveStatus: BotStatus | null;
  liveQr: QrResponse | null;
  liveLogs: LogEntry[];
  liveCommands: CommandCategory[];
  commandsStatus: CommandsStatus;
  qrReceivedAt: number | null;
}

const MAX_LIVE_LOGS = 150;
const RECONNECT_BASE_MS = 2_000;
const RECONNECT_MAX_MS = 30_000;
const PING_INTERVAL_MS = 20_000;

function getWsUrl(): string {
  const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
  return `${proto}//${window.location.host}/api/ws`;
}

export function useWebSocket(): UseWebSocketReturn {
  const [wsStatus, setWsStatus] = useState<WsStatus>("connecting");
  const [liveStatus, setLiveStatus] = useState<BotStatus | null>(null);
  const [liveQr, setLiveQr] = useState<QrResponse | null>(null);
  const [liveLogs, setLiveLogs] = useState<LogEntry[]>([]);
  const [liveCommands, setLiveCommands] = useState<CommandCategory[]>([]);
  const [commandsStatus, setCommandsStatus] = useState<CommandsStatus>("loading");
  const [qrReceivedAt, setQrReceivedAt] = useState<number | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectDelay = useRef(RECONNECT_BASE_MS);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pingTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const unmountedRef = useRef(false);
  const commandsRetryTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearTimers = useCallback(() => {
    if (reconnectTimer.current) { clearTimeout(reconnectTimer.current); reconnectTimer.current = null; }
    if (pingTimer.current) { clearInterval(pingTimer.current); pingTimer.current = null; }
  }, []);

  const connect = useCallback(() => {
    if (unmountedRef.current) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    setWsStatus("connecting");

    let ws: WebSocket;
    try {
      ws = new WebSocket(getWsUrl());
    } catch {
      scheduleReconnect();
      return;
    }
    wsRef.current = ws;

    ws.onopen = () => {
      if (unmountedRef.current) { ws.close(); return; }
      setWsStatus("connected");
      reconnectDelay.current = RECONNECT_BASE_MS;
      pingTimer.current = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "ping" }));
      }, PING_INTERVAL_MS);
    };

    ws.onmessage = (event) => {
      let msg: WsMessage;
      try { msg = JSON.parse(event.data as string) as WsMessage; } catch { return; }

      switch (msg.type) {
        case "status":
          setLiveStatus(msg.data as BotStatus);
          break;
        case "qr": {
          const qrPayload = msg.data as QrResponse;
          setLiveQr(qrPayload);
          if (qrPayload.status === "qr" && qrPayload.qr) {
            setQrReceivedAt(Date.now());
          }
          break;
        }
        case "log": {
          const entry = msg.data as LogEntry;
          setLiveLogs((prev) => [entry, ...prev].slice(0, MAX_LIVE_LOGS));
          break;
        }
        default:
          break;
      }
    };

    ws.onclose = () => {
      clearTimers();
      if (!unmountedRef.current) {
        setWsStatus("disconnected");
        scheduleReconnect();
      }
    };

    ws.onerror = () => { ws.close(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  function scheduleReconnect() {
    if (unmountedRef.current) return;
    reconnectTimer.current = setTimeout(() => {
      reconnectDelay.current = Math.min(reconnectDelay.current * 2, RECONNECT_MAX_MS);
      connect();
    }, reconnectDelay.current);
  }

  const fetchCommands = useCallback((attempt = 0) => {
    if (unmountedRef.current) return;
    fetch("/api/commands")
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json() as Promise<{ categories: CommandCategory[]; total: number }>;
      })
      .then((data) => {
        if (unmountedRef.current) return;
        setLiveCommands(data.categories ?? []);
        setCommandsStatus("loaded");
      })
      .catch(() => {
        if (unmountedRef.current) return;
        if (attempt < 6) {
          const delay = Math.min(1_500 * 2 ** attempt, 30_000);
          commandsRetryTimer.current = setTimeout(() => fetchCommands(attempt + 1), delay);
        } else {
          setCommandsStatus("error");
        }
      });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    unmountedRef.current = false;
    connect();
    fetchCommands(0);
    return () => {
      unmountedRef.current = true;
      clearTimers();
      wsRef.current?.close();
      if (commandsRetryTimer.current) clearTimeout(commandsRetryTimer.current);
    };
  }, [connect, clearTimers, fetchCommands]);

  return { wsStatus, liveStatus, liveQr, liveLogs, liveCommands, commandsStatus, qrReceivedAt };
}
