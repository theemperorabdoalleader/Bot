import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  useGetQr,
  useGetStatus,
  useSendMessage,
  useGetUsers,
  useGetLogs,
  useRestartBot,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import type { LogEntry, UserEntry } from "@workspace/api-client-react";
import {
  Terminal, Send, Activity, ShieldCheck, Clock, RefreshCw, QrCode,
  Users, LayoutDashboard, ScrollText, Wifi, WifiOff, Crown, Swords,
  Coins, Star, Trophy, BookOpen, Zap, Flame, Shield, RotateCcw,
} from "lucide-react";

const sendMessageSchema = z.object({
  phone: z.string().min(1, "Phone number is required"),
  message: z.string().min(1, "Message is required"),
});

function formatUptime(seconds: number | null | undefined) {
  if (!seconds) return "00:00:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function formatJid(jid: string) {
  return jid.replace(/@.*$/, "").replace(/(\d{3})(\d{3})(\d+)/, "+$1 $2 $3");
}

function formatTime(ts: number) {
  return new Date(ts).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function isVip(vipUntil: number) {
  return vipUntil > Date.now();
}

const LOG_COLORS: Record<string, string> = {
  command: "text-blue-400",
  connection: "text-green-400",
  error: "text-red-400",
  info: "text-yellow-400",
};

const LOG_ICONS: Record<string, string> = {
  command: "▶",
  connection: "⚡",
  error: "✕",
  info: "ℹ",
};

const CATEGORY_COLORS: Record<string, string> = {
  Media: "text-pink-400",
  Economy: "text-yellow-400",
  "Steal & Gambling": "text-orange-400",
  "PvP & Boss": "text-red-400",
  Games: "text-green-400",
  "Levels & Ranking": "text-purple-400",
  Gangs: "text-amber-400",
  "Missions & Achievements": "text-blue-400",
  AI: "text-cyan-400",
  Admin: "text-slate-400",
};

// ── QR countdown (counts down from 120s since last QR received) ───────────

const QR_TTL_S = 120;

function useQrCountdown(qrReceivedAt: number | null): number | null {
  const [countdown, setCountdown] = useState<number | null>(null);

  useEffect(() => {
    if (qrReceivedAt === null) { setCountdown(null); return; }
    const tick = () => {
      const elapsed = Math.floor((Date.now() - qrReceivedAt) / 1000);
      const remaining = Math.max(0, QR_TTL_S - elapsed);
      setCountdown(remaining);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [qrReceivedAt]);

  return countdown;
}

// ── Uptime counter that ticks every second ─────────────────────────────────

function useLiveUptime(serverUptime: number | null | undefined): number | null {
  const [uptime, setUptime] = useState<number | null>(serverUptime ?? null);
  const baseRef = useRef<{ serverVal: number; capturedAt: number } | null>(null);

  useEffect(() => {
    if (serverUptime != null) {
      baseRef.current = { serverVal: serverUptime, capturedAt: Date.now() };
      setUptime(serverUptime);
    }
  }, [serverUptime]);

  useEffect(() => {
    const id = setInterval(() => {
      if (!baseRef.current) return;
      const elapsed = Math.floor((Date.now() - baseRef.current.capturedAt) / 1000);
      setUptime(baseRef.current.serverVal + elapsed);
    }, 1000);
    return () => clearInterval(id);
  }, []);

  return uptime;
}

export default function Home() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");

  // ── WebSocket real-time layer ────────────────────────────────────────────
  const { wsStatus, liveStatus, liveQr, liveLogs, liveCommands, commandsStatus, qrReceivedAt } = useWebSocket();
  const qrCountdown = useQrCountdown(qrReceivedAt);

  // ── HTTP polling fallbacks (used when WS not yet connected) ─────────────
  const { data: pollStatus } = useGetQr({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    query: { refetchInterval: wsStatus === "connected" ? false : 5000 } as any,
  });
  const { data: pollQr } = useGetStatus({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    query: { refetchInterval: wsStatus === "connected" ? false : 5000 } as any,
  });

  // HTTP data for Users tab (only fetched when tab is active)
  const { data: usersData, isLoading: isLoadingUsers, refetch: refetchUsers } = useGetUsers({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    query: { refetchInterval: 15_000, enabled: activeTab === "users" } as any,
  });

  // HTTP fallback logs for when WS hasn't sent any yet
  const { data: fallbackLogs } = useGetLogs({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    query: { refetchInterval: wsStatus === "connected" ? false : 3000, enabled: activeTab === "logs" } as any,
  });

  const sendMessageMutation = useSendMessage();
  const restartBotMutation = useRestartBot();

  const onRestartBot = () => {
    if (!window.confirm("This will disconnect the current WhatsApp session and generate a new QR code. Continue?")) return;
    restartBotMutation.mutate(undefined, {
      onSuccess: () => {
        toast({ title: "Bot Restarting", description: "Session cleared — scan the new QR code to reconnect." });
      },
      onError: () => {
        toast({ title: "Restart Failed", description: "Could not reach the API server.", variant: "destructive" });
      },
    });
  };

  const form = useForm<z.infer<typeof sendMessageSchema>>({
    resolver: zodResolver(sendMessageSchema),
    defaultValues: { phone: "", message: "" },
  });

  const onSubmit = (values: z.infer<typeof sendMessageSchema>) => {
    sendMessageMutation.mutate(
      { data: values },
      {
        onSuccess: () => {
          toast({ title: "Message Sent", description: "Message delivered successfully." });
          form.reset();
        },
        onError: (err: unknown) => {
          const msg = err instanceof Error ? err.message : "Failed to send message.";
          toast({ title: "Error", description: msg, variant: "destructive" });
        },
      }
    );
  };

  // Merge WS data with HTTP fallbacks
  const status = liveStatus ?? pollQr;
  const qrData = liveQr ?? pollStatus;
  const isConnected = status?.connected ?? false;
  const totalUsers = status?.totalUsers ?? 0;

  // Live ticking uptime
  const liveUptime = useLiveUptime(status?.uptime);

  // Logs: prefer WS stream; fall back to HTTP poll
  const displayLogs: LogEntry[] = liveLogs.length > 0 ? liveLogs : (fallbackLogs?.logs ?? []);

  // Commands: from WS hook (fetched once via HTTP inside the hook)
  const commandCategories = liveCommands;
  const totalCommands = commandCategories.reduce((n, c) => n + c.items.length, 0);

  const wsIndicator = wsStatus === "connected"
    ? <span className="flex items-center gap-1 text-emerald-400 font-mono text-xs"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse inline-block" />WS Live</span>
    : wsStatus === "connecting"
    ? <span className="flex items-center gap-1 text-yellow-400 font-mono text-xs"><RefreshCw className="h-3 w-3 animate-spin" />Connecting</span>
    : <span className="flex items-center gap-1 text-slate-500 font-mono text-xs"><span className="h-1.5 w-1.5 rounded-full bg-slate-500 inline-block" />Polling</span>;

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Terminal className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold font-mono tracking-tight leading-none">WhatsApp Bot</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Dashboard Control Panel</p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {wsIndicator}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-muted/50 border border-border text-sm">
              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="font-mono text-xs">{formatUptime(liveUptime)}</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md border text-sm font-mono text-xs"
              style={isConnected
                ? { background: "rgba(34,197,94,0.08)", borderColor: "rgba(34,197,94,0.25)", color: "rgb(34,197,94)" }
                : { background: "rgba(239,68,68,0.08)", borderColor: "rgba(239,68,68,0.25)", color: "rgb(239,68,68)" }
              }
            >
              {isConnected ? (
                <><Wifi className="h-3.5 w-3.5" /><span>CONNECTED</span></>
              ) : (
                <><WifiOff className="h-3.5 w-3.5" /><span>OFFLINE</span></>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <Card className="border-border bg-card/50">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-green-500/10 flex items-center justify-center flex-shrink-0">
                <Activity className="h-4 w-4 text-green-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">Status</p>
                <p className="text-sm font-semibold font-mono mt-0.5">
                  {isConnected ? <span className="text-green-500">Active</span> : <span className="text-red-500">Offline</span>}
                </p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card/50">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                <Users className="h-4 w-4 text-blue-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">Users</p>
                <p className="text-sm font-semibold font-mono mt-0.5">{totalUsers}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card/50">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                <BookOpen className="h-4 w-4 text-purple-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">Commands</p>
                <p className="text-sm font-semibold font-mono mt-0.5">
                  {totalCommands > 0 ? totalCommands : "—"}
                </p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card/50">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-orange-500/10 flex items-center justify-center flex-shrink-0">
                <Clock className="h-4 w-4 text-orange-500" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-mono">Uptime</p>
                <p className="text-sm font-semibold font-mono mt-0.5">{formatUptime(liveUptime)}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 h-10 font-mono text-xs">
            <TabsTrigger value="overview" className="gap-1.5">
              <LayoutDashboard className="h-3.5 w-3.5" /> Overview
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-1.5">
              <Users className="h-3.5 w-3.5" /> Users
            </TabsTrigger>
            <TabsTrigger value="commands" className="gap-1.5">
              <Terminal className="h-3.5 w-3.5" /> Commands
            </TabsTrigger>
            <TabsTrigger value="logs" className="gap-1.5">
              <ScrollText className="h-3.5 w-3.5" />
              Logs
              {liveLogs.length > 0 && (
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse ml-0.5" />
              )}
            </TabsTrigger>
          </TabsList>

          {/* ── OVERVIEW TAB ── */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              {/* QR / Connection Panel */}
              <div className="lg:col-span-3">
                <Card className="border-border bg-card/50 h-full">
                  <CardHeader className="border-b border-border pb-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <QrCode className="h-4 w-4 text-primary" />
                        <CardTitle className="font-mono text-base">Connection</CardTitle>
                      </div>
                      <div className="flex items-center gap-2">
                        {isConnected && (
                          <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/25 font-mono text-xs">
                            ACTIVE SESSION
                          </Badge>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 px-2 font-mono text-xs gap-1 text-muted-foreground hover:text-destructive hover:border-destructive/50"
                          onClick={onRestartBot}
                          disabled={restartBotMutation.isPending}
                          title="Clear session and generate a new QR code"
                        >
                          {restartBotMutation.isPending
                            ? <RefreshCw className="h-3 w-3 animate-spin" />
                            : <RotateCcw className="h-3 w-3" />}
                          Restart
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center justify-center min-h-[260px] border border-dashed border-border rounded-lg bg-background/40">
                      {isConnected ? (
                        <div className="flex flex-col items-center gap-5 text-center max-w-xs">
                          <div className="h-20 w-20 rounded-full bg-green-500/10 border border-green-500/20 flex items-center justify-center">
                            <ShieldCheck className="h-10 w-10 text-green-500" />
                          </div>
                          <div>
                            <h3 className="text-base font-semibold">Connected to WhatsApp</h3>
                            <p className="text-sm text-muted-foreground mt-1">
                              The bot is active and monitoring for commands.
                            </p>
                            <p className="text-xs text-muted-foreground mt-2 font-mono">
                              Uptime: {formatUptime(liveUptime)}
                            </p>
                          </div>
                        </div>
                      ) : qrData?.status === "qr" && qrData.qr ? (
                        <div className="flex flex-col items-center gap-5 py-4">
                          <div className="bg-white p-3 rounded-xl shadow-md ring-1 ring-black/5">
                            <img src={qrData.qr} alt="WhatsApp QR Code" className="w-56 h-56 object-contain" />
                          </div>
                          <div className="text-center space-y-1.5 max-w-xs">
                            <p className="text-sm font-medium text-primary font-mono">SCAN QR CODE</p>
                            <p className="text-xs text-muted-foreground">
                              Open WhatsApp → Linked Devices → Link a Device → scan this code
                            </p>
                            {qrCountdown !== null && (
                              <p className={`text-xs font-mono mt-1 ${qrCountdown <= 20 ? "text-orange-400" : "text-muted-foreground/60"}`}>
                                {qrCountdown > 0
                                  ? `↻ Refreshes in ${qrCountdown}s`
                                  : "Refreshing QR code…"}
                              </p>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center gap-3 text-muted-foreground">
                          <RefreshCw className="h-7 w-7 animate-spin text-primary" />
                          <p className="font-mono text-sm">Waiting for QR code...</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Send Message Panel */}
              <div className="lg:col-span-2">
                <Card className="border-border bg-card/50 h-full">
                  <CardHeader className="border-b border-border pb-4">
                    <div className="flex items-center gap-2">
                      <Send className="h-4 w-4 text-primary" />
                      <CardTitle className="font-mono text-base">Send Message</CardTitle>
                    </div>
                    <CardDescription className="text-xs">Dispatch a message via the bot</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-5">
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
                                Phone Number
                              </FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. 9665XXXXXXXX" className="font-mono bg-background text-sm h-9" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="message"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
                                Message
                              </FormLabel>
                              <FormControl>
                                <Textarea placeholder="Enter message..." className="font-mono bg-background min-h-[100px] text-sm resize-y" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button
                          type="submit"
                          className="w-full font-mono text-xs h-9"
                          disabled={sendMessageMutation.isPending || !isConnected}
                        >
                          {sendMessageMutation.isPending ? (
                            <><RefreshCw className="mr-2 h-3.5 w-3.5 animate-spin" />Sending...</>
                          ) : (
                            <><Send className="mr-2 h-3.5 w-3.5" />Send Message</>
                          )}
                        </Button>
                        {!isConnected && (
                          <p className="text-xs text-destructive text-center font-mono">
                            Bot must be connected to send messages.
                          </p>
                        )}
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Live log mini-feed */}
            {displayLogs.length > 0 && (
              <Card className="border-border bg-card/50 mt-6">
                <CardHeader className="border-b border-border pb-3 pt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-yellow-400" />
                      <CardTitle className="font-mono text-sm">Recent Activity</CardTitle>
                    </div>
                    <button
                      className="text-xs text-primary font-mono hover:underline"
                      onClick={() => setActiveTab("logs")}
                    >
                      View all →
                    </button>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y divide-border/30">
                    {displayLogs.slice(0, 5).map((entry) => (
                      <div key={entry.id} className="px-4 py-2 flex items-center gap-3 font-mono text-xs hover:bg-muted/10">
                        <span className={`${LOG_COLORS[entry.type] ?? "text-muted-foreground"} w-4 text-center flex-shrink-0`}>
                          {LOG_ICONS[entry.type] ?? "·"}
                        </span>
                        <span className="text-muted-foreground flex-shrink-0">{formatTime(entry.timestamp)}</span>
                        <span className="truncate">{entry.message}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ── USERS TAB ── */}
          <TabsContent value="users">
            <Card className="border-border bg-card/50">
              <CardHeader className="border-b border-border pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-primary" />
                    <CardTitle className="font-mono text-base">User Database</CardTitle>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-xs">
                      {usersData?.total ?? 0} users
                    </Badge>
                    <button
                      onClick={() => void refetchUsers()}
                      className="text-xs text-muted-foreground font-mono hover:text-primary flex items-center gap-1"
                    >
                      <RefreshCw className="h-3 w-3" /> Refresh
                    </button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingUsers ? (
                  <div className="flex items-center justify-center py-16 text-muted-foreground">
                    <RefreshCw className="h-6 w-6 animate-spin text-primary mr-2" />
                    <span className="font-mono text-sm">Loading users...</span>
                  </div>
                ) : !usersData || !usersData.users.length ? (
                  <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
                    <Users className="h-8 w-8 opacity-30" />
                    <p className="font-mono text-sm">No users yet</p>
                    <p className="text-xs opacity-60">Users appear here once they interact with the bot</p>
                  </div>
                ) : (
                  <ScrollArea className="h-[560px]">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-border bg-muted/30">
                            <th className="text-left px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">#</th>
                            <th className="text-left px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">Phone</th>
                            <th className="text-right px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">
                              <span className="flex items-center justify-end gap-1"><Coins className="h-3 w-3" />Wallet</span>
                            </th>
                            <th className="text-right px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">Bank</th>
                            <th className="text-right px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">
                              <span className="flex items-center justify-end gap-1"><Star className="h-3 w-3" />XP</span>
                            </th>
                            <th className="text-left px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">Rank</th>
                            <th className="text-right px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">
                              <span className="flex items-center justify-end gap-1"><Trophy className="h-3 w-3" />W/L</span>
                            </th>
                            <th className="text-right px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">
                              <span className="flex items-center justify-end gap-1"><Shield className="h-3 w-3" />PvP</span>
                            </th>
                            <th className="text-right px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">
                              <span className="flex items-center justify-end gap-1"><Flame className="h-3 w-3" />Streak</span>
                            </th>
                            <th className="text-left px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">Gang</th>
                            <th className="text-center px-4 py-2.5 font-mono text-xs text-muted-foreground uppercase tracking-wider">VIP</th>
                          </tr>
                        </thead>
                        <tbody>
                          {usersData.users.map((user: UserEntry, i: number) => (
                            <tr key={user.jid} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                              <td className="px-4 py-2.5 text-muted-foreground font-mono text-xs">{i + 1}</td>
                              <td className="px-4 py-2.5 font-mono text-xs">{formatJid(user.jid)}</td>
                              <td className="px-4 py-2.5 text-right font-mono text-xs text-yellow-500">{user.wallet.toLocaleString()}</td>
                              <td className="px-4 py-2.5 text-right font-mono text-xs text-blue-400">{user.bank.toLocaleString()}</td>
                              <td className="px-4 py-2.5 text-right font-mono text-xs text-purple-400">{user.xp.toLocaleString()}</td>
                              <td className="px-4 py-2.5 font-mono text-xs">
                                <span className="flex items-center gap-1">
                                  <span>{user.tierEmoji ?? "🥉"}</span>
                                  <span className="text-muted-foreground">{user.rankName ?? "—"}</span>
                                </span>
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono text-xs">
                                <span className="text-green-400">{user.wins}</span>
                                <span className="text-muted-foreground">/</span>
                                <span className="text-red-400">{user.losses}</span>
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono text-xs">
                                <span className="text-cyan-400">{user.rankPoints?.toLocaleString() ?? 1000}</span>
                                <span className="text-muted-foreground text-[10px] ml-1">
                                  ({user.pvpWins ?? 0}W/{user.pvpLosses ?? 0}L)
                                </span>
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono text-xs">
                                {(user.dailyStreak ?? 0) > 0 ? (
                                  <span className="text-orange-400 flex items-center justify-end gap-1">
                                    <Flame className="h-3 w-3" />{user.dailyStreak}
                                  </span>
                                ) : (
                                  <span className="text-muted-foreground/40">—</span>
                                )}
                              </td>
                              <td className="px-4 py-2.5 text-xs">
                                {user.gangName ? (
                                  <span className="flex items-center gap-1">
                                    <Swords className="h-3 w-3 text-orange-400" />
                                    <span className="text-orange-400 font-mono">{user.gangName}</span>
                                  </span>
                                ) : (
                                  <span className="text-muted-foreground/40">—</span>
                                )}
                              </td>
                              <td className="px-4 py-2.5 text-center">
                                {isVip(user.vipUntil) ? (
                                  <Crown className="h-3.5 w-3.5 text-yellow-400 mx-auto" />
                                ) : (
                                  <span className="text-muted-foreground/30 text-xs">—</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── COMMANDS TAB ── */}
          <TabsContent value="commands">
            {commandsStatus === "error" ? (
              <div className="flex flex-col items-center justify-center py-20 text-muted-foreground gap-3">
                <Terminal className="h-8 w-8 opacity-30" />
                <p className="font-mono text-sm">Could not load commands</p>
                <p className="text-xs opacity-60">Make sure the API server is running, then refresh the page</p>
              </div>
            ) : commandCategories.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-muted-foreground gap-2">
                <RefreshCw className="h-5 w-5 animate-spin text-primary" />
                <span className="font-mono text-sm">Loading commands from bot…</span>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground font-mono">
                    {totalCommands} commands across {commandCategories.length} categories — auto-synced from bot
                  </p>
                  <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Live sync
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {commandCategories.map((cat) => {
                    const color = CATEGORY_COLORS[cat.category] ?? "text-primary";
                    return (
                      <Card key={cat.category} className="border-border bg-card/50">
                        <CardHeader className="border-b border-border pb-3 pt-4 px-4">
                          <CardTitle className={`font-mono text-sm flex items-center gap-2 ${color}`}>
                            <span>{cat.emoji}</span>
                            <span>{cat.categoryAr}</span>
                            <Badge variant="secondary" className="ml-auto font-mono text-xs h-5 px-1.5">
                              {cat.items.length}
                            </Badge>
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                          <div className="divide-y divide-border/50">
                            {cat.items.map((item) => (
                              <div key={item.cmd} className="px-4 py-2.5 hover:bg-muted/20 transition-colors">
                                <code className={`text-xs font-mono bg-primary/8 px-1.5 py-0.5 rounded ${color}`}>
                                  {item.cmd}
                                </code>
                                <p className="text-xs text-muted-foreground mt-1">{item.desc}</p>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </>
            )}
          </TabsContent>

          {/* ── LOGS TAB ── */}
          <TabsContent value="logs">
            <Card className="border-border bg-card/50">
              <CardHeader className="border-b border-border pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ScrollText className="h-4 w-4 text-primary" />
                    <CardTitle className="font-mono text-base">Activity Log</CardTitle>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground font-mono">
                    <span className="text-muted-foreground/60">{displayLogs.length} entries</span>
                    {wsStatus === "connected" ? (
                      <span className="flex items-center gap-1 text-emerald-400">
                        <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
                        Live · WebSocket
                      </span>
                    ) : (
                      <span className="flex items-center gap-1">
                        <span className="h-2 w-2 rounded-full bg-yellow-500 animate-pulse inline-block" />
                        Polling every 3s
                      </span>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {displayLogs.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
                    <ScrollText className="h-8 w-8 opacity-30" />
                    <p className="font-mono text-sm">No activity yet</p>
                    <p className="text-xs opacity-60">Logs appear here once the bot starts receiving messages</p>
                  </div>
                ) : (
                  <ScrollArea className="h-[560px]">
                    <div className="divide-y divide-border/30">
                      {displayLogs.map((entry) => (
                        <div key={entry.id} className="px-4 py-2.5 flex items-start gap-3 hover:bg-muted/10 transition-colors font-mono text-xs">
                          <span className={`${LOG_COLORS[entry.type] ?? "text-muted-foreground"} mt-0.5 w-4 flex-shrink-0 text-center`}>
                            {LOG_ICONS[entry.type] ?? "·"}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-muted-foreground/60 flex-shrink-0">{formatTime(entry.timestamp)}</span>
                              {entry.jid && (
                                <span className="text-muted-foreground/50 text-[10px] truncate max-w-[120px]">
                                  {formatJid(entry.jid)}
                                </span>
                              )}
                            </div>
                            <p className="mt-0.5 break-words text-foreground/90">{entry.message}</p>
                          </div>
                          <Badge
                            variant="outline"
                            className={`text-[9px] font-mono px-1 h-4 flex-shrink-0 border-current ${LOG_COLORS[entry.type] ?? ""}`}
                          >
                            {entry.type}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
