import { createServer } from "http";
import { WebSocketServer, type WebSocket } from "ws";
import QRCode from "qrcode";
import app from "./app.js";
import { logger } from "./lib/logger.js";
import { startBot } from "./bot/index.js";
import {
  getIsConnected, getQR, getUptime,
  setOnNewLog, setOnQrChange, setOnStatusChange,
  getCommandUserCount,
} from "./bot/state.js";
import { setWsServer, broadcast } from "./bot/ws-broadcast.js";

const rawPort = process.env["PORT"];
if (!rawPort) throw new Error("PORT environment variable is required but was not provided.");
const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) throw new Error(`Invalid PORT value: "${rawPort}"`);

// ── Build status/qr payloads ─────────────────────────────────────────────────

function buildStatusPayload() {
  return {
    connected: getIsConnected(),
    hasQr: getQR() !== null,
    uptime: getUptime(),
    totalUsers: getCommandUserCount(),
  };
}

async function buildQrPayload() {
  const connected = getIsConnected();
  const qrRaw = getQR();
  if (connected) return { status: "connected", qr: null };
  if (!qrRaw) return { status: "waiting", qr: null };
  try {
    const dataUrl = await QRCode.toDataURL(qrRaw, { errorCorrectionLevel: "M", margin: 2, width: 300 });
    return { status: "qr", qr: dataUrl };
  } catch {
    return { status: "error", qr: null };
  }
}

// ── Create HTTP + WebSocket server ───────────────────────────────────────────

const server = createServer(app);
const wss = new WebSocketServer({ noServer: true });
setWsServer(wss);

// Upgrade HTTP → WebSocket only at /api/ws
server.on("upgrade", (req, socket, head) => {
  if (req.url === "/api/ws") {
    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req);
    });
  } else {
    socket.destroy();
  }
});

wss.on("connection", async (ws: WebSocket) => {
  logger.info("WebSocket client connected");

  // Send full current state immediately
  try {
    ws.send(JSON.stringify({ type: "status", data: buildStatusPayload() }));
    ws.send(JSON.stringify({ type: "qr",    data: await buildQrPayload() }));
  } catch {}

  ws.on("message", (raw) => {
    try {
      const msg = JSON.parse(raw.toString()) as { type?: string };
      if (msg.type === "ping") ws.send(JSON.stringify({ type: "pong" }));
    } catch {}
  });

  ws.on("close", () => { logger.info("WebSocket client disconnected"); });
  ws.on("error", (err) => { logger.warn({ err }, "WebSocket error"); });
});

// ── Hook state events into WS broadcasts ─────────────────────────────────────

setOnNewLog((entry) => {
  broadcast("log", entry);
});

setOnStatusChange(() => {
  broadcast("status", buildStatusPayload());
});

setOnQrChange(async () => {
  broadcast("qr", await buildQrPayload());
});

// Periodic status broadcast (heartbeat + uptime update)
setInterval(() => {
  broadcast("status", buildStatusPayload());
}, 10_000);

// ── Start listening ───────────────────────────────────────────────────────────

// ── Global safety net — prevent process exit from unhandled async errors ──────
process.on("uncaughtException", (err) => {
  logger.error({ err }, "Uncaught exception — bot continuing");
});
process.on("unhandledRejection", (reason) => {
  logger.error({ reason }, "Unhandled rejection — bot continuing");
});

server.listen(port, (err?: Error) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  startBot().catch((botErr) => {
    logger.error({ err: botErr }, "Bot startup error");
  });
});
