import { Router } from "express";
import { getAllUsers } from "../bot/db.js";
import { getLevelInfo, getRankTier } from "../bot/commands/level.js";

const router = Router();

router.get("/users", (_req, res) => {
  const all = getAllUsers();
  const users = Object.entries(all).map(([jid, data]) => {
    const levelInfo = getLevelInfo(data.xp ?? 0);
    const tier = getRankTier(data.xp ?? 0);
    return {
      jid,
      wallet: data.wallet ?? 0,
      bank: data.bank ?? 0,
      xp: data.xp ?? 0,
      level: data.level ?? 0,
      rankName: levelInfo.nameAr,
      tierName: tier.name,
      tierEmoji: tier.emoji,
      wins: data.wins ?? 0,
      losses: data.losses ?? 0,
      gangName: data.gangName ?? null,
      vipUntil: data.vipUntil ?? 0,
      dailyStreak: data.dailyStreak ?? 0,
      rankPoints: data.rankPoints ?? 1000,
      pvpWins: data.pvpWins ?? 0,
      pvpLosses: data.pvpLosses ?? 0,
    };
  });

  users.sort((a, b) => (b.wallet + b.bank) - (a.wallet + a.bank));
  res.json({ users, total: users.length });
});

export default router;
