import { Router } from "express";
import { getActivityLogs } from "../bot/state.js";

const router = Router();

router.get("/logs", (_req, res) => {
  res.json({ logs: getActivityLogs() });
});

export default router;
