import { Router } from "express";
import QRCode from "qrcode";
import { getQR, getIsConnected } from "../bot/state.js";

const router = Router();

router.get("/qr", async (req, res) => {
  const connected = getIsConnected();
  const qrData = getQR();

  if (connected) {
    res.json({ status: "connected" });
    return;
  }

  if (!qrData) {
    res.json({ status: "waiting" });
    return;
  }

  try {
    const dataUrl = await QRCode.toDataURL(qrData, {
      errorCorrectionLevel: "M",
      margin: 2,
      width: 300,
    });
    res.json({ status: "qr", qr: dataUrl });
  } catch {
    res.status(500).json({ status: "error" });
  }
});

router.get("/qr/page", (_req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WhatsApp Bot — تسجيل الدخول</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #0a3d2b 0%, #075e3a 50%, #128c5e 100%);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #fff;
    }
    .card {
      background: rgba(255,255,255,0.07);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.15);
      border-radius: 24px;
      padding: 48px 40px;
      text-align: center;
      max-width: 420px;
      width: 90%;
      box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    }
    .logo {
      font-size: 56px;
      margin-bottom: 16px;
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.08); }
    }
    h1 {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 8px;
      letter-spacing: -0.5px;
    }
    .subtitle {
      font-size: 14px;
      color: rgba(255,255,255,0.65);
      margin-bottom: 32px;
      line-height: 1.6;
    }
    #qr-wrapper {
      min-height: 320px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      gap: 16px;
    }
    #qr-img {
      border-radius: 16px;
      background: #fff;
      padding: 12px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      display: none;
      transition: opacity 0.3s;
    }
    .status-icon { font-size: 64px; }
    .status-text {
      font-size: 18px;
      font-weight: 600;
      color: rgba(255,255,255,0.9);
    }
    .status-sub {
      font-size: 13px;
      color: rgba(255,255,255,0.55);
      margin-top: 6px;
    }
    .spinner {
      width: 48px;
      height: 48px;
      border: 4px solid rgba(255,255,255,0.2);
      border-top-color: #25d366;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .steps {
      margin-top: 28px;
      text-align: right;
      background: rgba(255,255,255,0.06);
      border-radius: 12px;
      padding: 16px 20px;
    }
    .steps h3 {
      font-size: 13px;
      color: rgba(255,255,255,0.5);
      margin-bottom: 10px;
      text-align: center;
    }
    .steps ol {
      list-style: none;
      counter-reset: steps;
    }
    .steps li {
      counter-increment: steps;
      font-size: 13px;
      color: rgba(255,255,255,0.75);
      padding: 4px 0;
      display: flex;
      align-items: flex-start;
      gap: 8px;
    }
    .steps li::before {
      content: counter(steps);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 20px;
      height: 20px;
      background: #25d366;
      color: #fff;
      border-radius: 50%;
      font-size: 11px;
      font-weight: 700;
      flex-shrink: 0;
    }
    .refresh-note {
      margin-top: 20px;
      font-size: 12px;
      color: rgba(255,255,255,0.4);
    }
    .dot-flash span {
      animation: dotFlash 1.4s infinite both;
      display: inline-block;
    }
    .dot-flash span:nth-child(2) { animation-delay: 0.2s; }
    .dot-flash span:nth-child(3) { animation-delay: 0.4s; }
    @keyframes dotFlash { 0%, 80%, 100% { opacity: 0.2; } 40% { opacity: 1; } }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">🤖</div>
    <h1>WhatsApp Bot</h1>
    <p class="subtitle">بوت واتساب ذكي — ترجمة، صور، تلخيص، وتذكيرات</p>

    <div id="qr-wrapper">
      <div class="spinner"></div>
      <div class="status-text">جارٍ التحميل<span class="dot-flash"><span>.</span><span>.</span><span>.</span></span></div>
    </div>

    <div class="steps" id="steps-section" style="display:none">
      <h3>كيفية ربط الجهاز</h3>
      <ol>
        <li>افتح واتساب على هاتفك</li>
        <li>اضغط على القائمة ثم "الأجهزة المرتبطة"</li>
        <li>اضغط "ربط جهاز" ثم امسح رمز QR</li>
      </ol>
    </div>

    <p class="refresh-note">يتحدث تلقائياً كل 5 ثوانٍ</p>
  </div>

  <script>
    const wrapper = document.getElementById('qr-wrapper');
    const steps = document.getElementById('steps-section');

    async function refresh() {
      try {
        const res = await fetch('/api/qr');
        const data = await res.json();

        if (data.status === 'connected') {
          wrapper.innerHTML = \`
            <div class="status-icon">✅</div>
            <div class="status-text">البوت متصل!</div>
            <div class="status-sub">يمكنك الآن استخدام البوت على واتساب</div>
          \`;
          steps.style.display = 'none';
          return;
        }

        if (data.status === 'qr') {
          let img = document.getElementById('qr-img');
          if (!img) {
            wrapper.innerHTML = '<img id="qr-img" width="280" height="280" />';
            img = document.getElementById('qr-img');
            img.style.display = 'block';
          }
          img.src = data.qr;
          img.style.display = 'block';
          steps.style.display = 'block';
          return;
        }

        wrapper.innerHTML = \`
          <div class="spinner"></div>
          <div class="status-text">في انتظار رمز QR<span class="dot-flash"><span>.</span><span>.</span><span>.</span></span></div>
          <div class="status-sub">يرجى الانتظار...</div>
        \`;
      } catch (e) {
        console.error(e);
      }
    }

    refresh();
    setInterval(refresh, 5000);
  </script>
</body>
</html>`);
});

export default router;
