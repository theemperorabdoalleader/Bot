import { Router } from "express";
import { getIsConnected, getQR, getUptime } from "../bot/state.js";
import { getAllUsers } from "../bot/db.js";

const router = Router();

router.get("/status", (_req, res) => {
  const users = getAllUsers();
  res.json({
    connected: getIsConnected(),
    hasQr: getQR() !== null,
    uptime: getUptime(),
    totalUsers: Object.keys(users).length,
  });
});

export default router;
