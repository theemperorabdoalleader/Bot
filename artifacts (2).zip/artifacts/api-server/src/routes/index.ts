import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import qrRouter from "./qr.js";
import statusRouter from "./status.js";
import sendRouter from "./send.js";
import usersRouter from "./users.js";
import logsRouter from "./logs.js";
import commandsRouter from "./commands.js";
import restartRouter from "./restart.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(qrRouter);
router.use(statusRouter);
router.use(sendRouter);
router.use(usersRouter);
router.use(logsRouter);
router.use(commandsRouter);
router.use(restartRouter);

export default router;
