import { Router } from "express";
import { restartBot } from "../bot/index.js";
import { logger } from "../lib/logger.js";

const router = Router();

router.post("/restart", (_req, res) => {
  logger.info("POST /api/restart — restarting bot");
  restartBot().catch((err) => {
    logger.error({ err }, "restartBot threw unexpectedly");
  });
  res.json({ ok: true, message: "Bot restart initiated — new QR will appear shortly" });
});

export default router;
