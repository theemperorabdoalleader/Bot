import { Router } from "express";
import { getSocket, getIsConnected } from "../bot/state.js";
import { logger } from "../lib/logger.js";

const router = Router();

router.post("/send", async (req, res) => {
  const { phone, message } = req.body as { phone?: string; message?: string };

  if (!phone || !message) {
    res.status(400).json({ error: "phone and message are required" });
    return;
  }

  if (!getIsConnected()) {
    res.status(503).json({ error: "Bot is not connected to WhatsApp" });
    return;
  }

  const sock = getSocket();
  if (!sock) {
    res.status(503).json({ error: "Bot socket is not available" });
    return;
  }

  const sanitizedPhone = phone.replace(/\D/g, "");
  const jid = `${sanitizedPhone}@s.whatsapp.net`;

  try {
    const result = await sock.sendMessage(jid, { text: message });
    res.json({
      success: true,
      messageId: result?.key?.id ?? null,
    });
  } catch (err) {
    logger.error({ err, jid }, "Failed to send message via API");
    res.status(500).json({ error: "Failed to send message" });
  }
});

export default router;
