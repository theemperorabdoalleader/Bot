import { Router } from "express";
import { COMMAND_REGISTRY, TOTAL_COMMANDS } from "../bot/commands-registry.js";

const router = Router();

router.get("/commands", (_req, res) => {
  res.json({
    categories: COMMAND_REGISTRY,
    total: TOTAL_COMMANDS,
  });
});

export default router;
