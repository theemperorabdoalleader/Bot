declare module "yt-search" {
  interface VideoSearchResult {
    title: string;
    url: string;
    videoId: string;
    description: string;
    duration: { seconds: number; timestamp: string };
    thumbnail: string;
    views: number;
  }

  interface SearchResult {
    videos: VideoSearchResult[];
  }

  function ytSearch(query: string): Promise<SearchResult>;
  namespace ytSearch {
    type VideoSearchResult = VideoSearchResult;
    type SearchResult = SearchResult;
  }
  export = ytSearch;
}
