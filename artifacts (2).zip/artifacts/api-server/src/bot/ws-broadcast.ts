/**
 * WebSocket broadcast module.
 * Call setWsServer() once during startup, then use broadcast() anywhere.
 */
import type { WebSocketServer, WebSocket } from "ws";
import { logger } from "../lib/logger.js";

let _wss: WebSocketServer | null = null;

/** Register the WS server (called once from index.ts) */
export function setWsServer(wss: WebSocketServer): void {
  _wss = wss;
}

/** Broadcast a typed JSON event to all connected clients */
export function broadcast(type: string, data: unknown): void {
  if (!_wss) return;
  const msg = JSON.stringify({ type, data, ts: Date.now() });
  for (const client of _wss.clients as Set<WebSocket>) {
    if (client.readyState === 1 /* OPEN */) {
      try { client.send(msg); } catch (err) {
        logger.warn({ err }, "WS send failed");
      }
    }
  }
}

/** Get number of connected WS clients */
export function getWsClientCount(): number {
  return _wss?.clients.size ?? 0;
}
