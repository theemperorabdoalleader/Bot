import { existsSync, readFileSync, writeFileSync, mkdirSync } from "fs";
import { join } from "path";

const DATA_DIR = join(process.cwd(), "data");
const DB_FILE = join(DATA_DIR, "users.json");

export interface HistoryEntry {
  type: "win" | "loss" | "reward";
  amount: number;
  description: string;
  timestamp: number;
}

export interface DailyMission {
  type: string;
  description: string;
  completed: boolean;
  coinReward: number;
  xpReward: number;
}

export interface UserData {
  wallet: number;
  bank: number;
  xp: number;
  level: number;
  lastLuck: number;
  lastDaily: number;
  lastLootbox: number;
  jailUntil: number;
  wins: number;
  losses: number;
  achievements: string[];
  gangName: string | null;
  vipUntil: number;
  coinBoostLevel: number;
  xpBoostLevel: number;
  inventory: string[];
  xpBoostUses: number;
  coinBoostUses: number;
  shieldUses: number;
  history: HistoryEntry[];
  missions: {
    date: string;
    list: DailyMission[];
  };
  // Advanced economy
  dailyStreak: number;
  lastStreakDate: string;
  // Competitive / PvP
  rankPoints: number;
  pvpWins: number;
  pvpLosses: number;
}

type DB = Record<string, UserData>;
let cache: DB = {};

const DEFAULT_USER: UserData = {
  wallet: 1000,
  bank: 0,
  xp: 0,
  level: 0,
  lastLuck: 0,
  lastDaily: 0,
  lastLootbox: 0,
  jailUntil: 0,
  wins: 0,
  losses: 0,
  achievements: [],
  gangName: null,
  vipUntil: 0,
  coinBoostLevel: 0,
  xpBoostLevel: 0,
  inventory: [],
  xpBoostUses: 0,
  coinBoostUses: 0,
  shieldUses: 0,
  history: [],
  missions: { date: "", list: [] },
  dailyStreak: 0,
  lastStreakDate: "",
  rankPoints: 1000,
  pvpWins: 0,
  pvpLosses: 0,
};

export function initDb(): void {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
  if (existsSync(DB_FILE)) {
    try { cache = JSON.parse(readFileSync(DB_FILE, "utf8")) as DB; } catch { cache = {}; }
  }
}

function save(): void {
  writeFileSync(DB_FILE, JSON.stringify(cache, null, 2), "utf8");
}

export function getUser(jid: string): UserData {
  if (!cache[jid]) {
    cache[jid] = { ...DEFAULT_USER, achievements: [], history: [], inventory: [], missions: { date: "", list: [] } };
    save();
  }
  const u = cache[jid]!;
  // Migrate missing fields
  if (u.lastDaily === undefined) u.lastDaily = 0;
  if (u.lastLootbox === undefined) u.lastLootbox = 0;
  if (u.jailUntil === undefined) u.jailUntil = 0;
  if (u.wins === undefined) u.wins = 0;
  if (u.losses === undefined) u.losses = 0;
  if (u.achievements === undefined) u.achievements = [];
  if (u.gangName === undefined) u.gangName = null;
  if (u.vipUntil === undefined) u.vipUntil = 0;
  if (u.coinBoostLevel === undefined) u.coinBoostLevel = 0;
  if (u.xpBoostLevel === undefined) u.xpBoostLevel = 0;
  if (u.history === undefined) u.history = [];
  if (u.missions === undefined) u.missions = { date: "", list: [] };
  if (u.dailyStreak === undefined) u.dailyStreak = 0;
  if (u.lastStreakDate === undefined) u.lastStreakDate = "";
  if (u.rankPoints === undefined) u.rankPoints = 1000;
  if (u.pvpWins === undefined) u.pvpWins = 0;
  if (u.pvpLosses === undefined) u.pvpLosses = 0;
  return u;
}

export function updateUser(jid: string, updates: Partial<UserData>): UserData {
  const user = getUser(jid);
  Object.assign(user, updates);
  save();
  return user;
}

export function addHistory(jid: string, entry: HistoryEntry): void {
  const user = getUser(jid);
  user.history.unshift(entry);
  if (user.history.length > 15) user.history = user.history.slice(0, 15);
  save();
}

export function getTopByWealth(n: number): Array<{ jid: string; total: number }> {
  return Object.entries(cache)
    .map(([jid, d]) => ({ jid, total: (d.wallet ?? 0) + (d.bank ?? 0) }))
    .sort((a, b) => b.total - a.total)
    .slice(0, n);
}

export function getTopByXP(n: number): Array<{ jid: string; xp: number }> {
  return Object.entries(cache)
    .map(([jid, d]) => ({ jid, xp: d.xp ?? 0 }))
    .sort((a, b) => b.xp - a.xp)
    .slice(0, n);
}

export function getAllUsers(): DB { return cache; }
