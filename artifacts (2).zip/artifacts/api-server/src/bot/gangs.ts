import { existsSync, readFileSync, writeFileSync, mkdirSync } from "fs";
import { join } from "path";

const DATA_DIR = join(process.cwd(), "data");
const GANGS_FILE = join(DATA_DIR, "gangs.json");

export interface Gang {
  name: string;
  leaderJid: string;
  members: string[];
  coins: number;
  createdAt: number;
}

type GangsDB = Record<string, Gang>;
let cache: GangsDB = {};

export function initGangs(): void {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
  if (existsSync(GANGS_FILE)) {
    try { cache = JSON.parse(readFileSync(GANGS_FILE, "utf8")) as GangsDB; } catch { cache = {}; }
  }
}

function save(): void {
  writeFileSync(GANGS_FILE, JSON.stringify(cache, null, 2), "utf8");
}

export function getGang(name: string): Gang | null {
  return cache[name.toLowerCase()] ?? null;
}

export function getAllGangs(): GangsDB { return cache; }

export function createGang(name: string, leaderJid: string): Gang {
  const gang: Gang = {
    name,
    leaderJid,
    members: [leaderJid],
    coins: 0,
    createdAt: Date.now(),
  };
  cache[name.toLowerCase()] = gang;
  save();
  return gang;
}

export function addMemberToGang(gangName: string, jid: string): boolean {
  const gang = cache[gangName.toLowerCase()];
  if (!gang || gang.members.includes(jid)) return false;
  gang.members.push(jid);
  save();
  return true;
}

export function updateGangCoins(gangName: string, delta: number): void {
  const gang = cache[gangName.toLowerCase()];
  if (!gang) return;
  gang.coins = Math.max(0, gang.coins + delta);
  save();
}

export function findMemberGang(jid: string): Gang | null {
  for (const gang of Object.values(cache)) {
    if (gang.members.includes(jid)) return gang;
  }
  return null;
}
