import type { WASocket } from "@whiskeysockets/baileys";
import ytdl from "@distube/ytdl-core";
import ytSearch from "yt-search";
import type { Readable } from "stream";
import { logger } from "../../lib/logger.js";

async function streamToBuffer(stream: Readable): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    stream.on("data", (chunk: Buffer) => chunks.push(Buffer.from(chunk)));
    stream.on("end", () => resolve(Buffer.concat(chunks)));
    stream.on("error", reject);
  });
}

export async function handleYoutube(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  if (!args.trim()) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى إدخال كلمة بحث. مثال: .يوتيوب anime edit",
    });
    return;
  }

  const query = `${args.trim()} shorts`;
  await sock.sendMessage(jid, { text: `🔍 جارٍ البحث عن "${args.trim()}"...` });

  let candidates: ytSearch.VideoSearchResult[];
  try {
    const res = await ytSearch(query);
    candidates = res.videos
      .filter((v) => v.duration.seconds > 0 && v.duration.seconds <= 65)
      .slice(0, 6);
    if (candidates.length === 0) {
      candidates = res.videos.slice(0, 4);
    }
  } catch (err) {
    logger.error({ err }, "YouTube search failed");
    await sock.sendMessage(jid, {
      text: "❌ حدث خطأ أثناء البحث. يرجى المحاولة لاحقاً.",
    });
    return;
  }

  if (candidates.length === 0) {
    await sock.sendMessage(jid, {
      text: `❌ لم يتم العثور على نتائج لـ "${args.trim()}".`,
    });
    return;
  }

  let sent = 0;
  for (const video of candidates) {
    if (sent >= 2) break;
    try {
      const stream = ytdl(video.url, {
        quality: "highestvideo",
        filter: "videoandaudio",
      });
      const buffer = await streamToBuffer(stream as unknown as Readable);
      await sock.sendMessage(jid, {
        video: buffer,
        mimetype: "video/mp4",
        caption: `🎬 ${video.title}`,
      });
      sent++;
    } catch (err) {
      logger.warn({ err, url: video.url }, "Failed to download YouTube video, skipping");
    }
  }

  if (sent === 0) {
    await sock.sendMessage(jid, {
      text: "❌ فشل في تحميل الفيديوهات. يرجى المحاولة لاحقاً.",
    });
  }
}
