import type { WASocket } from "@whiskeysockets/baileys";
import OpenAI from "openai";
import { getContext, addToContext, clearContext, getContextSize } from "../services/ai-context.js";
import { getAutoAiMode } from "../state.js";

let _client: OpenAI | null = null;

function getClient(): OpenAI {
  if (!_client) {
    const apiKey = process.env["OPENAI_API_KEY"];
    if (!apiKey) throw new Error("OPENAI_API_KEY is not set.");
    _client = new OpenAI({ apiKey });
  }
  return _client;
}

const SYSTEM_PROMPT = `أنت مساعد ذكي ومتعدد المهارات تعمل في مجموعة واتساب. أجب بشكل مختصر وواضح باللغة العربية. 
استخدم إيموجي مناسبة لتجعل الردود أكثر حيوية. إذا كان السؤال تقنياً يمكنك استخدام أمثلة.
لا تذكر أنك نموذج AI — أنت مساعد البوت.`;

export async function handleAsk(
  sock: WASocket,
  chatJid: string,
  question: string,
  senderJid?: string,
): Promise<void> {
  if (!question.trim()) {
    await sock.sendMessage(chatJid, {
      text: "❌ يرجى كتابة سؤالك. مثال: .اسأل ما عاصمة فرنسا؟",
    });
    return;
  }

  const userKey = senderJid ?? chatJid;
  const history = getContext(userKey);

  try {
    const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
      { role: "system", content: SYSTEM_PROMPT },
      ...history.map((turn) => ({
        role: turn.role as "user" | "assistant",
        content: turn.content,
      })),
      { role: "user", content: question },
    ];

    const completion = await getClient().chat.completions.create({
      model: "gpt-4o-mini",
      messages,
      max_tokens: 600,
      temperature: 0.7,
    });

    const answer = completion.choices[0]?.message?.content ?? "عذراً، لم أفهم السؤال.";

    // Store in context memory
    addToContext(userKey, "user", question);
    addToContext(userKey, "assistant", answer);

    const ctxNote = history.length > 0
      ? `\n_💬 السياق: ${Math.floor(getContextSize(userKey) / 2)} رسالة سابقة_`
      : "";

    await sock.sendMessage(chatJid, {
      text: `🤖 *سؤالك:* ${question}\n\n💬 *الإجابة:*\n${answer}${ctxNote}`,
    });
  } catch {
    await sock.sendMessage(chatJid, {
      text: "❌ فشل في الحصول على إجابة. تأكد من تعيين مفتاح OPENAI_API_KEY.",
    });
  }
}

export async function handleClearContext(
  sock: WASocket,
  chatJid: string,
  senderJid: string,
): Promise<void> {
  clearContext(senderJid);
  await sock.sendMessage(chatJid, {
    text: "🧹 تم مسح ذاكرة المحادثة! ستبدأ محادثة جديدة من الآن.",
  });
}

/**
 * Auto-reply with AI when auto mode is on and message is not a command.
 */
export async function handleAutoAiReply(
  sock: WASocket,
  chatJid: string,
  senderJid: string,
  text: string,
): Promise<void> {
  if (!getAutoAiMode(chatJid)) return;
  if (text.startsWith(".")) return;
  if (text.length < 5) return; // ignore very short messages

  await handleAsk(sock, chatJid, text, senderJid);
}
