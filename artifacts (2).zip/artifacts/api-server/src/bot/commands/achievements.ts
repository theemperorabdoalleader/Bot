import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";

interface Achievement {
  id: string;
  nameAr: string;
  description: string;
  coinReward: number;
  xpReward: number;
  check: (user: ReturnType<typeof getUser>) => boolean;
}

const ACHIEVEMENTS: Achievement[] = [
  {
    id: "first_win",
    nameAr: "🏅 أول انتصار",
    description: "اربح لعبتك الأولى",
    coinReward: 10_000,
    xpReward: 50,
    check: (u) => (u.wins ?? 0) >= 1,
  },
  {
    id: "ten_wins",
    nameAr: "🥇 محارب",
    description: "اربح 10 ألعاب",
    coinReward: 50_000,
    xpReward: 100,
    check: (u) => (u.wins ?? 0) >= 10,
  },
  {
    id: "fifty_wins",
    nameAr: "⚔️ بطل الساحة",
    description: "اربح 50 لعبة",
    coinReward: 200_000,
    xpReward: 300,
    check: (u) => (u.wins ?? 0) >= 50,
  },
  {
    id: "hundred_k",
    nameAr: "💰 مئة ألف",
    description: "اجمع 100,000 عملة",
    coinReward: 20_000,
    xpReward: 50,
    check: (u) => (u.wallet + u.bank) >= 100_000,
  },
  {
    id: "million_coins",
    nameAr: "💎 مليونير",
    description: "اجمع 1,000,000 عملة",
    coinReward: 100_000,
    xpReward: 200,
    check: (u) => (u.wallet + u.bank) >= 1_000_000,
  },
  {
    id: "gang_member",
    nameAr: "🏴 عضو عصابة",
    description: "انضم لعصابة",
    coinReward: 5_000,
    xpReward: 25,
    check: (u) => !!u.gangName,
  },
  {
    id: "first_steal",
    nameAr: "🦹 لص محترف",
    description: "اسرق شخصاً بنجاح",
    coinReward: 15_000,
    xpReward: 40,
    check: (u) => u.history.some((h) => h.type === "win" && h.description.includes("سرقة")),
  },
];

export async function checkAchievements(jid: string, sock: WASocket): Promise<void> {
  const user = getUser(jid);
  const unlocked = new Set(user.achievements ?? []);

  for (const ach of ACHIEVEMENTS) {
    if (unlocked.has(ach.id)) continue;
    if (!ach.check(user)) continue;

    unlocked.add(ach.id);
    updateUser(jid, {
      achievements: [...unlocked],
      wallet: user.wallet + ach.coinReward,
    });

    try {
      await sock.sendMessage(jid, {
        text: `🏆 إنجاز جديد!\n${ach.nameAr}\n📝 ${ach.description}\n\n💰 مكافأة: ${ach.coinReward.toLocaleString("ar-EG")} عملة\n✨ +${ach.xpReward} XP`,
      });
    } catch {}
  }
}

export async function handleAchievements(sock: WASocket, chatJid: string, senderJid: string): Promise<void> {
  const user = getUser(senderJid);
  const unlocked = new Set(user.achievements ?? []);

  const lines = ACHIEVEMENTS.map((a) => {
    const done = unlocked.has(a.id);
    return `${done ? "✅" : "🔒"} ${a.nameAr}\n   ${a.description}`;
  });

  await sock.sendMessage(chatJid, {
    text: `🏆 إنجازاتك (${unlocked.size}/${ACHIEVEMENTS.length})\n\n${lines.join("\n\n")}`,
  });
}
