import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser, type DailyMission } from "../db.js";
import { awardXP } from "./level.js";
import { awardCoins } from "./level.js";

interface MissionTemplate {
  type: string;
  description: string;
  coinReward: number;
  xpReward: number;
}

const MISSION_POOL: MissionTemplate[] = [
  { type: "win_game",      description: "🎮 اربح لعبة واحدة (.عين / .لاعب / .لغز)",  coinReward: 20_000, xpReward: 30 },
  { type: "use_luck",      description: "🎰 استخدم أمر .حظ",                           coinReward: 10_000, xpReward: 15 },
  { type: "answer_riddle", description: "🧩 أجب على لغز بشكل صحيح",                   coinReward: 15_000, xpReward: 20 },
  { type: "use_daily",     description: "🎁 استخدم أمر .يومي",                          coinReward: 5_000,  xpReward: 10 },
  { type: "gamble_once",   description: "🃏 العب القمار مرة واحدة (.قمار)",              coinReward: 10_000, xpReward: 15 },
  { type: "open_lootbox",  description: "📦 افتح صندوق مكافآت (.صندوق)",               coinReward: 8_000,  xpReward: 12 },
  { type: "steal_once",    description: "🦹 حاول السرقة مرة (.سرقة @user)",             coinReward: 12_000, xpReward: 18 },
];

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function generateMissions(): DailyMission[] {
  const pool = [...MISSION_POOL].sort(() => Math.random() - 0.5).slice(0, 3);
  return pool.map((t) => ({ ...t, completed: false }));
}

export function ensureMissions(jid: string): DailyMission[] {
  const user = getUser(jid);
  const today = todayStr();
  if (user.missions.date !== today) {
    const list = generateMissions();
    updateUser(jid, { missions: { date: today, list } });
    return list;
  }
  return user.missions.list;
}

export async function handleMissions(sock: WASocket, chatJid: string, senderJid: string): Promise<void> {
  const missions = ensureMissions(senderJid);
  const lines = missions.map((m, i) => {
    const status = m.completed ? "✅" : "⏳";
    return `${status} ${i + 1}. ${m.description}\n   🏆 ${m.coinReward.toLocaleString("ar-EG")} عملة + ${m.xpReward} XP`;
  });
  const allDone = missions.every((m) => m.completed);
  const footer = allDone ? "\n\n🎉 أنجزت جميع المهام اليوم! تعال بكرة!" : "\n\n🕐 المهام تُجدَّد كل 24 ساعة";
  await sock.sendMessage(chatJid, {
    text: `📋 مهامك اليومية\n\n${lines.join("\n\n")}${footer}`,
  });
}

export async function completeMission(
  jid: string, missionType: string, sock: WASocket,
): Promise<void> {
  const missions = ensureMissions(jid);
  const mission = missions.find((m) => m.type === missionType && !m.completed);
  if (!mission) return;

  mission.completed = true;
  const user = getUser(jid);
  updateUser(jid, { missions: { date: todayStr(), list: missions } });

  const coins = await awardCoins(jid, mission.coinReward);
  await awardXP(jid, mission.xpReward, sock);

  try {
    await sock.sendMessage(jid, {
      text: `✅ أنجزت مهمة!\n📋 "${mission.description}"\n💰 +${coins.toLocaleString("ar-EG")} عملة\n✨ +${mission.xpReward} XP`,
    });
  } catch {}
}
