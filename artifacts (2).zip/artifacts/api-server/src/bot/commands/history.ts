import type { WASocket } from "@whiskeysockets/baileys";
import { getUser } from "../db.js";

function fmt(n: number): string { return n.toLocaleString("ar-EG"); }
function timeAgo(ts: number): string {
  const diffMs = Date.now() - ts;
  const mins = Math.floor(diffMs / 60_000);
  if (mins < 60) return `${mins} دقيقة مضت`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} ساعة مضت`;
  return `${Math.floor(hours / 24)} يوم مضى`;
}

export async function handleHistory(sock: WASocket, chatJid: string, senderJid: string): Promise<void> {
  const user = getUser(senderJid);
  const history = user.history ?? [];

  if (history.length === 0) {
    await sock.sendMessage(chatJid, { text: "📊 سجلك فارغ! ابدأ باللعب لتملأه." });
    return;
  }

  const lines = history.slice(0, 10).map((h, i) => {
    const icon = h.type === "win" ? "✅" : h.type === "loss" ? "❌" : "🎁";
    const amountStr = h.amount > 0 ? ` — ${fmt(h.amount)} عملة` : "";
    return `${i + 1}. ${icon} ${h.description}${amountStr}\n   🕐 ${timeAgo(h.timestamp)}`;
  });

  const wins = history.filter((h) => h.type === "win").length;
  const losses = history.filter((h) => h.type === "loss").length;
  const rewards = history.filter((h) => h.type === "reward").length;

  await sock.sendMessage(chatJid, {
    text: `📊 سجلك الأخير\n\n✅ انتصارات: ${user.wins ?? 0} | ❌ خسارات: ${user.losses ?? 0}\n\n${lines.join("\n\n")}\n\n(آخر 10 أحداث)`,
  });

  void wins; void losses; void rewards;
}
