import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";

const VIP_COST = 200_000;
const VIP_DURATION_MS = 7 * 24 * 60 * 60 * 1000;

const UPGRADE_COSTS = [0, 50_000, 150_000, 400_000, 1_000_000, 2_500_000];

function fmt(n: number): string { return n.toLocaleString("ar-EG"); }
function msToHuman(ms: number): string {
  const hours = Math.floor(ms / 3_600_000);
  const days = Math.floor(hours / 24);
  return days > 0 ? `${days} يوم` : `${hours} ساعة`;
}

export async function handleVIP(sock: WASocket, chatJid: string, senderJid: string): Promise<void> {
  const user = getUser(senderJid);
  const now = Date.now();
  const isVIP = user.vipUntil > now;

  if (isVIP) {
    const remaining = msToHuman(user.vipUntil - now);
    await sock.sendMessage(chatJid, {
      text: `👑 أنت بالفعل VIP!\n⏰ ينتهي خلال: ${remaining}\n\n✨ مزايا VIP:\n+20% عملات\n+20% XP\nشارة خاصة 👑`,
    });
    return;
  }

  await sock.sendMessage(chatJid, {
    text: `👑 نظام VIP\n\n✨ مزايا:\n• +20% عملات على كل مكافأة\n• +20% XP على كل نقطة\n• شارة 👑 خاصة\n\n💰 السعر: ${fmt(VIP_COST)} عملة / 7 أيام\n\nللشراء: .شراء_vip`,
  });
}

export async function handleBuyVIP(sock: WASocket, chatJid: string, senderJid: string): Promise<void> {
  const user = getUser(senderJid);
  if (user.wallet < VIP_COST) {
    await sock.sendMessage(chatJid, {
      text: `❌ رصيدك غير كافٍ!\n💰 تحتاج ${fmt(VIP_COST)} عملة\n💳 رصيدك: ${fmt(user.wallet)} عملة`,
    });
    return;
  }

  const now = Date.now();
  const existing = user.vipUntil > now ? user.vipUntil : now;
  updateUser(senderJid, { wallet: user.wallet - VIP_COST, vipUntil: existing + VIP_DURATION_MS });

  await sock.sendMessage(chatJid, {
    text: `👑 مرحباً بك في VIP!\n✅ تم الاشتراك لمدة 7 أيام\n💰 خُصم ${fmt(VIP_COST)} عملة\n\nاستمتع بمزاياك! 🎉`,
  });
}

export async function handleUpgrade(
  sock: WASocket, chatJid: string, senderJid: string, args: string,
): Promise<void> {
  const user = getUser(senderJid);
  const coinLvl = user.coinBoostLevel ?? 0;
  const xpLvl = user.xpBoostLevel ?? 0;

  const sub = args.trim().toLowerCase();

  if (!sub) {
    const coinNext = coinLvl < 5 ? fmt(UPGRADE_COSTS[coinLvl + 1]!) : "الحد الأقصى";
    const xpNext = xpLvl < 5 ? fmt(UPGRADE_COSTS[xpLvl + 1]!) : "الحد الأقصى";

    await sock.sendMessage(chatJid, {
      text: `⚙️ نظام التطوير\n\n💰 مضاعف العملات: المستوى ${coinLvl}/5 (+${coinLvl * 10}%)\n   التطوير التالي: ${coinNext} عملة\n   الأمر: .تطوير عملات\n\n✨ مضاعف XP: المستوى ${xpLvl}/5 (+${xpLvl * 10}%)\n   التطوير التالي: ${xpNext} عملة\n   الأمر: .تطوير خبرة`,
    });
    return;
  }

  if (sub === "عملات") {
    if (coinLvl >= 5) {
      await sock.sendMessage(chatJid, { text: "✅ مضاعف العملات وصل للحد الأقصى!" });
      return;
    }
    const cost = UPGRADE_COSTS[coinLvl + 1]!;
    if (user.wallet < cost) {
      await sock.sendMessage(chatJid, { text: `❌ تحتاج ${fmt(cost)} عملة للتطوير. رصيدك: ${fmt(user.wallet)}` });
      return;
    }
    updateUser(senderJid, { wallet: user.wallet - cost, coinBoostLevel: coinLvl + 1 });
    await sock.sendMessage(chatJid, {
      text: `⚙️ تمت الترقية!\n💰 مضاعف العملات: المستوى ${coinLvl + 1}/5\n+${(coinLvl + 1) * 10}% على كل مكافأة!`,
    });
  } else if (sub === "خبرة") {
    if (xpLvl >= 5) {
      await sock.sendMessage(chatJid, { text: "✅ مضاعف XP وصل للحد الأقصى!" });
      return;
    }
    const cost = UPGRADE_COSTS[xpLvl + 1]!;
    if (user.wallet < cost) {
      await sock.sendMessage(chatJid, { text: `❌ تحتاج ${fmt(cost)} عملة للتطوير. رصيدك: ${fmt(user.wallet)}` });
      return;
    }
    updateUser(senderJid, { wallet: user.wallet - cost, xpBoostLevel: xpLvl + 1 });
    await sock.sendMessage(chatJid, {
      text: `⚙️ تمت الترقية!\n✨ مضاعف XP: المستوى ${xpLvl + 1}/5\n+${(xpLvl + 1) * 10}% على كل نقطة XP!`,
    });
  } else {
    await sock.sendMessage(chatJid, { text: "❌ خيار غير صحيح. استخدم: .تطوير عملات / .تطوير خبرة" });
  }
}
