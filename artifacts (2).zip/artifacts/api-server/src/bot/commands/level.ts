import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";
import { logger } from "../../lib/logger.js";

export interface LevelInfo {
  level: number;
  nameAr: string;
  xpRequired: number;
  nextXp: number | null;
}

export interface RankTier {
  name: string;
  emoji: string;
  minXp: number;
}

// ── Military ranks (for progression) ──────────────────────────────────────────
const LEVELS: LevelInfo[] = [
  { level: 0, nameAr: "مجند",      xpRequired: 0,     nextXp: 500   },
  { level: 1, nameAr: "ملازم",     xpRequired: 500,   nextXp: 1500  },
  { level: 2, nameAr: "ملازم أول", xpRequired: 1500,  nextXp: 3000  },
  { level: 3, nameAr: "نقيب",      xpRequired: 3000,  nextXp: 6000  },
  { level: 4, nameAr: "رائد",      xpRequired: 6000,  nextXp: 12000 },
  { level: 5, nameAr: "مقدم",      xpRequired: 12000, nextXp: 25000 },
  { level: 6, nameAr: "عقيد",      xpRequired: 25000, nextXp: 50000 },
  { level: 7, nameAr: "لواء",      xpRequired: 50000, nextXp: 100000 },
  { level: 8, nameAr: "فريق",      xpRequired: 100000, nextXp: null  },
];

// ── Competitive rank tiers (for display badge) ─────────────────────────────────
const RANK_TIERS: RankTier[] = [
  { name: "برونز",   emoji: "🥉", minXp: 0       },
  { name: "فضة",    emoji: "🥈", minXp: 1000    },
  { name: "ذهب",    emoji: "🥇", minXp: 5000    },
  { name: "بلاتين", emoji: "💎", minXp: 15000   },
  { name: "ماسي",   emoji: "💠", minXp: 40000   },
  { name: "أسطوري", emoji: "🌟", minXp: 100000  },
];

export function getLevelInfo(xp: number): LevelInfo {
  let current = LEVELS[0]!;
  for (const lvl of LEVELS) {
    if (xp >= lvl.xpRequired) current = lvl;
  }
  return current;
}

export function getRankTier(xp: number): RankTier {
  let current = RANK_TIERS[0]!;
  for (const tier of RANK_TIERS) {
    if (xp >= tier.minXp) current = tier;
  }
  return current;
}

export async function awardXP(jid: string, amount: number, sock?: WASocket): Promise<void> {
  try {
    const user = getUser(jid);
    const oldLevel = getLevelInfo(user.xp);

    // Multiplier: shop boost (single-use ×2) + permanent upgrade (+10% per level) + VIP (+20%)
    let multiplier = 1;
    if (user.xpBoostUses > 0) multiplier *= 2;
    multiplier *= 1 + (user.xpBoostLevel ?? 0) * 0.10;
    if ((user.vipUntil ?? 0) > Date.now()) multiplier *= 1.20;

    const gained = Math.floor(amount * multiplier);
    const newXp = user.xp + gained;

    const updates: Partial<typeof user> = { xp: newXp };
    if (user.xpBoostUses > 0) updates.xpBoostUses = user.xpBoostUses - 1;
    updateUser(jid, updates);

    const newLevel = getLevelInfo(newXp);
    const newTier = getRankTier(newXp);
    const oldTier = getRankTier(user.xp);

    if (sock) {
      if (newLevel.level > oldLevel.level) {
        await sock.sendMessage(jid, {
          text: `🎉 *ترقية عسكرية!*\nوصلت لرتبة: *${newLevel.nameAr}* 👮‍♂️`,
        });
      }
      if (newTier.name !== oldTier.name) {
        await sock.sendMessage(jid, {
          text: `${newTier.emoji} *ترقية رتبة تنافسية!*\nأصبحت في فئة: *${newTier.name}* ${newTier.emoji}`,
        });
      }
    }
  } catch (err) {
    logger.warn({ err }, "awardXP failed");
  }
}

export async function awardCoins(jid: string, amount: number): Promise<number> {
  const user = getUser(jid);

  // Multiplier: shop boost (×2) + permanent upgrade (+10% per level) + VIP (+20%)
  let multiplier = 1;
  if (user.coinBoostUses > 0) multiplier *= 2;
  multiplier *= 1 + (user.coinBoostLevel ?? 0) * 0.10;
  if ((user.vipUntil ?? 0) > Date.now()) multiplier *= 1.20;

  const gained = Math.floor(amount * multiplier);
  const updates: Partial<typeof user> = { wallet: user.wallet + gained };
  if (user.coinBoostUses > 0) updates.coinBoostUses = user.coinBoostUses - 1;
  updateUser(jid, updates);
  return gained;
}

export async function handleLevel(sock: WASocket, jid: string): Promise<void> {
  const user = getUser(jid);
  const info = getLevelInfo(user.xp);
  const tier = getRankTier(user.xp);

  const xpProgress = info.nextXp !== null
    ? `${user.xp.toLocaleString("ar-EG")} / ${info.nextXp.toLocaleString("ar-EG")} XP`
    : `${user.xp.toLocaleString("ar-EG")} XP (الحد الأقصى)`;

  const xpToNext = info.nextXp !== null
    ? `\n📍 متبقي للمستوى التالي: ${(info.nextXp - user.xp).toLocaleString("ar-EG")} XP`
    : "";

  const vipBadge = (user.vipUntil ?? 0) > Date.now()
    ? `\n👑 VIP نشط حتى ${new Date(user.vipUntil).toLocaleDateString("ar-EG")}`
    : "";

  const coinUpgrade = user.coinBoostLevel > 0 ? ` (+${user.coinBoostLevel * 10}%)` : "";
  const xpUpgrade = user.xpBoostLevel > 0 ? ` (+${user.xpBoostLevel * 10}%)` : "";

  const pvpWins = user.pvpWins ?? 0;
  const pvpLosses = user.pvpLosses ?? 0;
  const rankPoints = user.rankPoints ?? 1000;

  await sock.sendMessage(jid, {
    text: `👤 *ملفك الشخصي*\n\n🪖 الرتبة العسكرية: *${info.nameAr}*\n${tier.emoji} الفئة التنافسية: *${tier.name}*\n\n📈 *XP:* ${xpProgress}${xpToNext}${vipBadge}\n\n⚔️ *PvP:* نقاط ${rankPoints.toLocaleString("ar-EG")} | فوز ${pvpWins} / خسارة ${pvpLosses}\n🏆 انتصارات: ${user.wins ?? 0}\n\n🔧 تطوير العملات: مستوى ${user.coinBoostLevel ?? 0}${coinUpgrade}\n✨ تطوير XP: مستوى ${user.xpBoostLevel ?? 0}${xpUpgrade}`,
  });
}
