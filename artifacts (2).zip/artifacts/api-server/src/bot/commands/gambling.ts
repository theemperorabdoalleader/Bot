import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser, addHistory } from "../db.js";
import { awardXP } from "./level.js";
import { checkAchievements } from "./achievements.js";

const LOOTBOX_COOLDOWN_MS = 30 * 60 * 1000;

function fmt(n: number): string { return n.toLocaleString("ar-EG"); }
function msToMin(ms: number): string {
  const m = Math.ceil(ms / 60_000);
  return `${m} دقيقة`;
}

const SHOP_ITEMS = ["مضاعف_فلوس", "زيادة_XP", "حماية"];

export async function handleGamble(
  sock: WASocket,
  chatJid: string,
  senderJid: string,
  amountStr: string,
): Promise<void> {
  const amount = parseInt(amountStr.trim());
  if (!amount || amount <= 0) {
    await sock.sendMessage(chatJid, { text: "❌ يرجى تحديد مبلغ صحيح. مثال: .قمار 50000" });
    return;
  }

  const user = getUser(senderJid);
  if (user.wallet < amount) {
    await sock.sendMessage(chatJid, {
      text: `❌ رصيدك غير كافٍ!\n💰 محفظتك: ${fmt(user.wallet)} عملة`,
    });
    return;
  }

  const win = Math.random() < 0.5;
  if (win) {
    updateUser(senderJid, { wallet: user.wallet + amount, wins: (user.wins ?? 0) + 1 });
    addHistory(senderJid, { type: "win", amount, description: "قمار — فاز", timestamp: Date.now() });
    await awardXP(senderJid, 10, sock);
    await checkAchievements(senderJid, sock);
    await sock.sendMessage(chatJid, {
      text: `🎰 حظك سعيد!\n💸 ربحت ${fmt(amount)} عملة!\n💰 رصيدك: ${fmt(user.wallet + amount)} عملة`,
    });
  } else {
    updateUser(senderJid, { wallet: user.wallet - amount, losses: (user.losses ?? 0) + 1 });
    addHistory(senderJid, { type: "loss", amount, description: "قمار — خسر", timestamp: Date.now() });
    await sock.sendMessage(chatJid, {
      text: `🎰 يا حسرة!\n💸 خسرت ${fmt(amount)} عملة!\n💰 رصيدك: ${fmt(user.wallet - amount)} عملة`,
    });
  }
}

export async function handleLootbox(sock: WASocket, chatJid: string, senderJid: string): Promise<void> {
  const user = getUser(senderJid);
  const now = Date.now();
  const elapsed = now - (user.lastLootbox ?? 0);

  if (elapsed < LOOTBOX_COOLDOWN_MS) {
    await sock.sendMessage(chatJid, { text: `🎁 الصندوق غير جاهز! انتظر ${msToMin(LOOTBOX_COOLDOWN_MS - elapsed)}.` });
    return;
  }

  updateUser(senderJid, { lastLootbox: now });

  const roll = Math.random();
  if (roll < 0.50) {
    // Coins reward
    const coins = Math.floor(Math.random() * 90_000) + 10_000;
    updateUser(senderJid, { wallet: getUser(senderJid).wallet + coins });
    addHistory(senderJid, { type: "reward", amount: coins, description: "صندوق — عملات", timestamp: Date.now() });
    await checkAchievements(senderJid, sock);
    await sock.sendMessage(chatJid, {
      text: `🎁 فتحت الصندوق!\n💰 حصلت على ${fmt(coins)} عملة! 🤑`,
    });
  } else if (roll < 0.80) {
    // XP reward
    const xp = Math.floor(Math.random() * 150) + 50;
    await awardXP(senderJid, xp, sock);
    addHistory(senderJid, { type: "reward", amount: xp, description: "صندوق — XP", timestamp: Date.now() });
    await sock.sendMessage(chatJid, {
      text: `🎁 فتحت الصندوق!\n✨ حصلت على ${xp} XP! 📈`,
    });
  } else {
    // Shop item
    const item = SHOP_ITEMS[Math.floor(Math.random() * SHOP_ITEMS.length)]!;
    const inv = [...(getUser(senderJid).inventory ?? []), item];
    updateUser(senderJid, { inventory: inv });
    addHistory(senderJid, { type: "reward", amount: 0, description: `صندوق — عنصر: ${item}`, timestamp: Date.now() });
    await sock.sendMessage(chatJid, {
      text: `🎁 فتحت الصندوق!\n🎮 حصلت على عنصر: *${item}*! 🛍️`,
    });
  }
}
