import type { WASocket } from "@whiskeysockets/baileys";
import { summarizeText } from "../services/ai.js";
import { logger } from "../../lib/logger.js";

export async function handleSummarize(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  if (!args.trim()) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى إدخال النص المراد تلخيصه.\nمثال: .ملخص أدخل النص هنا...",
    });
    return;
  }

  await sock.sendMessage(jid, { text: "⏳ جارٍ التلخيص..." });

  try {
    const summary = await summarizeText(args.trim());
    await sock.sendMessage(jid, { text: `📝 *الملخص:*\n\n${summary}` });
  } catch (err) {
    logger.error({ err }, "Summarization failed");
    await sock.sendMessage(jid, {
      text: "❌ فشل في التلخيص. يرجى المحاولة مرة أخرى.",
    });
  }
}
