/**
 * Group moderation commands (admin-only):
 *   .مود مشرفين  — restrict commands to admins only
 *   .مود اعضاء   — allow all members to use commands
 *   .كتم         — mute a user (reply or mention)
 *   .الغاء كتم   — unmute a user
 *   .حذف         — delete a replied-to message + the command itself
 */
import type { WAMessage, WASocket } from "@whiskeysockets/baileys";
import {
  getGroupMode, setGroupMode,
  isUserMuted, muteUser, unmuteUser, getMutedUsers,
} from "../group-state.js";
import { addActivityLog } from "../state.js";

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Extract the target JID from a reply or first mention. */
function resolveTarget(msg: WAMessage, mentions: string[]): string | null {
  // Reply takes priority
  const participant = msg.message?.extendedTextMessage?.contextInfo?.participant;
  if (participant) return participant;
  // Fall back to first mention
  return mentions[0] ?? null;
}

function phone(jid: string): string {
  return jid.replace(/[^0-9]/g, "");
}

// ── Commands ─────────────────────────────────────────────────────────────────

/** .مود مشرفين — set group mode to admins-only */
export async function handleModeAdmins(
  sock: WASocket,
  jid: string,
  senderJid: string,
): Promise<void> {
  if (getGroupMode(jid) === "admins") {
    await sock.sendMessage(jid, { text: "ℹ️ وضع المشرفين مُفعَّل مسبقاً. لا توجد تغييرات." });
    return;
  }
  setGroupMode(jid, "admins");
  addActivityLog("info", `Group mode set to admins-only by @${phone(senderJid)}`, jid);
  await sock.sendMessage(jid, {
    text: "🔐 *وضع المشرفين مُفعَّل*\n\nمن الآن فقط المشرفون يمكنهم استخدام أوامر البوت.\nالأعضاء العاديون لن يستطيعوا استخدام الأوامر.\n\nاكتب *.مود اعضاء* للرجوع للوضع العادي.",
  });
}

/** .مود اعضاء — set group mode to allow all members */
export async function handleModeMembers(
  sock: WASocket,
  jid: string,
  senderJid: string,
): Promise<void> {
  if (getGroupMode(jid) === "members") {
    await sock.sendMessage(jid, { text: "ℹ️ وضع الأعضاء مُفعَّل مسبقاً. لا توجد تغييرات." });
    return;
  }
  setGroupMode(jid, "members");
  addActivityLog("info", `Group mode set to members by @${phone(senderJid)}`, jid);
  await sock.sendMessage(jid, {
    text: "🔓 *وضع الأعضاء مُفعَّل*\n\nمن الآن جميع الأعضاء يمكنهم استخدام أوامر البوت.\n\nاكتب *.مود مشرفين* للتقييد على المشرفين فقط.",
  });
}

/** .كتم — mute a user (reply or mention) */
export async function handleMute(
  sock: WASocket,
  jid: string,
  msg: WAMessage,
  mentions: string[],
  senderJid: string,
): Promise<void> {
  const target = resolveTarget(msg, mentions);
  if (!target) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى الرد على رسالة المستخدم أو ذكره باستخدام @.\nمثال: *.كتم @user* أو الرد على رسالته",
    });
    return;
  }

  const targetPhone = phone(target);

  if (isUserMuted(jid, target)) {
    await sock.sendMessage(jid, {
      text: `ℹ️ @${targetPhone} محظور بالفعل.`,
      mentions: [target],
    });
    return;
  }

  muteUser(jid, target);
  addActivityLog("info", `User @${targetPhone} muted by @${phone(senderJid)}`, jid);

  await sock.sendMessage(jid, {
    text: `🔇 *تم كتم المستخدم*\n\n@${targetPhone} تم كتمه. سيتم حذف رسائله تلقائياً.\n\nلإلغاء الكتم: *.الغاء كتم @${targetPhone}*`,
    mentions: [target],
  });
}

/** .الغاء كتم — unmute a user */
export async function handleUnmute(
  sock: WASocket,
  jid: string,
  msg: WAMessage,
  mentions: string[],
  senderJid: string,
): Promise<void> {
  const target = resolveTarget(msg, mentions);
  if (!target) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى الرد على رسالة المستخدم أو ذكره باستخدام @.",
    });
    return;
  }

  const targetPhone = phone(target);

  if (!isUserMuted(jid, target)) {
    await sock.sendMessage(jid, {
      text: `ℹ️ @${targetPhone} غير محظور.`,
      mentions: [target],
    });
    return;
  }

  unmuteUser(jid, target);
  addActivityLog("info", `User @${targetPhone} unmuted by @${phone(senderJid)}`, jid);

  await sock.sendMessage(jid, {
    text: `🔊 *تم إلغاء الكتم*\n\n@${targetPhone} يمكنه الآن إرسال الرسائل مجدداً.`,
    mentions: [target],
  });
}

/** .حذف — delete the replied-to message and the command itself */
export async function handleDelete(
  sock: WASocket,
  jid: string,
  msg: WAMessage,
  senderJid: string,
): Promise<void> {
  const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
  const stanzaId    = contextInfo?.stanzaId;
  const participant = contextInfo?.participant;

  if (!stanzaId) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى الرد على الرسالة التي تريد حذفها.",
    });
    return;
  }

  let deleted = false;

  // Delete the quoted message
  try {
    await sock.sendMessage(jid, {
      delete: {
        remoteJid: jid,
        fromMe: false,
        id: stanzaId,
        participant: participant ?? undefined,
      },
    });
    deleted = true;
  } catch {
    // Bot may not be admin — handle gracefully
  }

  // Delete the command message itself
  try {
    await sock.sendMessage(jid, { delete: msg.key });
  } catch {}

  if (!deleted) {
    await sock.sendMessage(jid, {
      text: "❌ تعذّر حذف الرسالة. تأكد أن البوت مشرف في المجموعة.",
    });
  } else {
    addActivityLog("info", `Message deleted by @${phone(senderJid)}`, jid);
  }
}

/** Returns summary of muted users (for info commands) */
export function getMutedList(jid: string): string {
  const muted = getMutedUsers(jid);
  if (muted.length === 0) return "لا يوجد مستخدمون محظورون في هذه المجموعة.";
  return `🔇 المستخدمون المحظورون (${muted.length}):\n` +
    muted.map((u) => `• @${phone(u)}`).join("\n");
}
