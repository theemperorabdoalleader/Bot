import type { WASocket } from "@whiskeysockets/baileys";
import { translateToEnglish } from "../services/ai.js";
import { searchImages, fetchImageBuffer } from "../services/pixabay.js";
import { logger } from "../../lib/logger.js";

const MAX_IMAGES = 10;
const DEFAULT_IMAGES = 5;

export async function handleImages(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  if (!args.trim()) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى إدخال كلمة بحث. مثال: .صور ناروتو\nأو: .صور 3 ناروتو",
    });
    return;
  }

  let count = DEFAULT_IMAGES;
  let query = args.trim();

  const firstWord = query.split(" ")[0];
  if (firstWord && /^\d+$/.test(firstWord)) {
    const parsed = parseInt(firstWord, 10);
    count = Math.min(Math.max(1, parsed), MAX_IMAGES);
    query = query.slice(firstWord.length).trim();
  }

  if (!query) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى إدخال كلمة بحث بعد العدد.",
    });
    return;
  }

  await sock.sendMessage(jid, { text: `🔍 جارٍ البحث عن "${query}"...` });

  let englishQuery = query;
  try {
    englishQuery = await translateToEnglish(query);
  } catch (err) {
    logger.warn({ err }, "Translation failed, using original query");
  }

  let urls: string[];
  try {
    urls = await searchImages(englishQuery, count);
  } catch (err) {
    logger.error({ err }, "Pixabay search failed");
    await sock.sendMessage(jid, {
      text: "❌ حدث خطأ أثناء البحث عن الصور. يرجى المحاولة لاحقاً.",
    });
    return;
  }

  if (urls.length === 0) {
    await sock.sendMessage(jid, {
      text: `❌ لم يتم العثور على نتائج لـ "${query}". جرّب كلمة بحث أخرى.`,
    });
    return;
  }

  const total = urls.length;
  let sent = 0;

  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    if (!url) continue;

    try {
      const buffer = await fetchImageBuffer(url);
      if (!buffer) {
        logger.warn({ url }, "Failed to fetch image buffer, skipping");
        continue;
      }

      await sock.sendMessage(jid, {
        image: buffer,
        caption: `📸 ${sent + 1}/${total} — ${query}`,
      });
      sent++;
    } catch (err) {
      logger.warn({ err, url }, "Failed to send image, skipping");
    }
  }

  if (sent === 0) {
    await sock.sendMessage(jid, {
      text: "❌ فشل في إرسال الصور. يرجى المحاولة مرة أخرى.",
    });
  }
}
