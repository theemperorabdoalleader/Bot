import type { WASocket } from "@whiskeysockets/baileys";
import { logger } from "../../lib/logger.js";

interface MemeApiMeme {
  title: string;
  url: string;
  postLink: string;
  subreddit: string;
}

interface MemeApiResponse {
  count: number;
  memes: MemeApiMeme[];
}

const MEME_API = "https://meme-api.com/gimme/3";
const FETCH_HEADERS = {
  "User-Agent": "Mozilla/5.0",
};

async function fetchImageBuffer(url: string): Promise<Buffer> {
  const res = await fetch(url, { headers: FETCH_HEADERS });
  if (!res.ok) throw new Error(`Image fetch HTTP ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

export async function handleMeme(sock: WASocket, jid: string): Promise<void> {
  let memes: MemeApiMeme[];
  try {
    const res = await fetch(MEME_API, { headers: FETCH_HEADERS });
    if (!res.ok) throw new Error(`meme-api HTTP ${res.status}`);
    const data = (await res.json()) as MemeApiResponse;
    memes = data.memes ?? [];
  } catch (err) {
    logger.error({ err }, "Meme API fetch failed");
    await sock.sendMessage(jid, {
      text: "❌ فشل في جلب الميمز. يرجى المحاولة لاحقاً.",
    });
    return;
  }

  if (memes.length === 0) {
    await sock.sendMessage(jid, { text: "❌ لا توجد ميمز متاحة حالياً." });
    return;
  }

  let sent = 0;
  for (const meme of memes.slice(0, 3)) {
    try {
      const buffer = await fetchImageBuffer(meme.url);
      await sock.sendMessage(jid, {
        image: buffer,
        caption: `😂 ${meme.title}`,
      });
      sent++;
    } catch (err) {
      logger.warn({ err, url: meme.url }, "Meme image download failed, skipping");
    }
  }

  if (sent === 0) {
    await sock.sendMessage(jid, {
      text: "❌ فشل في إرسال الميمز. يرجى المحاولة لاحقاً.",
    });
  }
}
