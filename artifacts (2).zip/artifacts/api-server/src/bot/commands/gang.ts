import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser, getAllUsers } from "../db.js";
import {
  initGangs, getGang, createGang, addMemberToGang,
  findMemberGang, updateGangCoins, getAllGangs,
} from "../gangs.js";

function fmt(n: number): string { return n.toLocaleString("ar-EG"); }

export { initGangs };

function gangPower(gangName: string): number {
  const users = getAllUsers();
  let power = 0;
  for (const u of Object.values(users)) {
    if (u.gangName?.toLowerCase() === gangName.toLowerCase()) {
      power += u.xp ?? 0;
    }
  }
  return power;
}

export async function handleCreateGang(
  sock: WASocket, chatJid: string, senderJid: string, args: string,
): Promise<void> {
  const name = args.trim();
  if (!name || name.length < 2 || name.length > 20) {
    await sock.sendMessage(chatJid, { text: "❌ اسم العصابة يجب أن يكون بين 2 و20 حرفاً." });
    return;
  }

  const existing = findMemberGang(senderJid);
  if (existing) {
    await sock.sendMessage(chatJid, { text: `❌ أنت بالفعل في عصابة: *${existing.name}*` });
    return;
  }

  if (getGang(name)) {
    await sock.sendMessage(chatJid, { text: `❌ عصابة بهذا الاسم موجودة بالفعل!` });
    return;
  }

  createGang(name, senderJid);
  updateUser(senderJid, { gangName: name });

  await sock.sendMessage(chatJid, {
    text: `🏴 تم إنشاء العصابة!\n👑 اسمها: *${name}*\n🔰 أنت الزعيم!\nادع الآخرين بـ: .انضمام ${name}`,
  });
}

export async function handleJoinGang(
  sock: WASocket, chatJid: string, senderJid: string, args: string,
): Promise<void> {
  const name = args.trim();
  if (!name) {
    await sock.sendMessage(chatJid, { text: "❌ يرجى ذكر اسم العصابة. مثال: .انضمام اسم_العصابة" });
    return;
  }

  const existing = findMemberGang(senderJid);
  if (existing) {
    await sock.sendMessage(chatJid, { text: `❌ أنت بالفعل في عصابة: *${existing.name}*` });
    return;
  }

  const gang = getGang(name);
  if (!gang) {
    await sock.sendMessage(chatJid, { text: `❌ لا توجد عصابة باسم "${name}".` });
    return;
  }

  addMemberToGang(gang.name, senderJid);
  updateUser(senderJid, { gangName: gang.name });

  await sock.sendMessage(chatJid, {
    text: `✅ انضممت لعصابة *${gang.name}*!\n👥 عدد الأعضاء: ${gang.members.length}`,
  });
}

export async function handleMyGang(
  sock: WASocket, chatJid: string, senderJid: string,
): Promise<void> {
  const gang = findMemberGang(senderJid);
  if (!gang) {
    await sock.sendMessage(chatJid, { text: "❌ أنت لست في أي عصابة. أنشئ واحدة بـ .انشاء_عصابة <اسم>" });
    return;
  }

  const power = gangPower(gang.name);
  const leaderNum = gang.leaderJid.replace(/[^0-9]/g, "");
  const memberList = gang.members.slice(0, 5).map((m) => `• @${m.replace(/[^0-9]/g, "")}`).join("\n");

  await sock.sendMessage(chatJid, {
    text: `🏴 عصابة *${gang.name}*\n👑 الزعيم: @${leaderNum}\n👥 الأعضاء: ${gang.members.length}\n⚡ القوة: ${fmt(power)}\n💰 خزينة العصابة: ${fmt(gang.coins)} عملة\n\nالأعضاء:\n${memberList}`,
    mentions: gang.members.slice(0, 5),
  });
}

export async function handleGangWar(
  sock: WASocket, chatJid: string, senderJid: string, args: string,
): Promise<void> {
  const myGang = findMemberGang(senderJid);
  if (!myGang) {
    await sock.sendMessage(chatJid, { text: "❌ أنت لست في عصابة!" });
    return;
  }

  const targetName = args.trim();
  if (!targetName) {
    await sock.sendMessage(chatJid, { text: "❌ يرجى ذكر اسم العصابة المنافسة. مثال: .حرب اسم_العصابة" });
    return;
  }

  const targetGang = getGang(targetName);
  if (!targetGang) {
    await sock.sendMessage(chatJid, { text: `❌ لا توجد عصابة باسم "${targetName}".` });
    return;
  }
  if (targetGang.name.toLowerCase() === myGang.name.toLowerCase()) {
    await sock.sendMessage(chatJid, { text: "❌ لا يمكنك مهاجمة عصابتك الخاصة!" });
    return;
  }

  await sock.sendMessage(chatJid, { text: `⚔️ الحرب اشتعلت!\n🏴 ${myGang.name} ضد ${targetGang.name}\nجارٍ الحساب...` });

  // Power-based with randomness
  const myPower = gangPower(myGang.name) * (0.7 + Math.random() * 0.6);
  const enemyPower = gangPower(targetGang.name) * (0.7 + Math.random() * 0.6);

  await new Promise((r) => setTimeout(r, 2000));

  const myWins = myPower > enemyPower;
  const winnerGang = myWins ? myGang : targetGang;
  const loserGang = myWins ? targetGang : myGang;

  const loot = Math.floor(Math.random() * 50_000) + 20_000;
  updateGangCoins(winnerGang.name, loot);
  updateGangCoins(loserGang.name, -Math.min(loot, loserGang.coins));

  const allGangs = getAllGangs();
  const winner = allGangs[winnerGang.name.toLowerCase()]!;
  const loser = allGangs[loserGang.name.toLowerCase()]!;

  await sock.sendMessage(chatJid, {
    text: `🏆 انتهت الحرب!\n\n⚡ ${myGang.name}: ${fmt(Math.round(myPower))} قوة\n⚡ ${targetGang.name}: ${fmt(Math.round(enemyPower))} قوة\n\n🏴 الفائز: *${winnerGang.name}*\n💰 غنيمة: ${fmt(loot)} عملة\n🏦 خزينة الفائز: ${fmt(winner.coins)} عملة\n💔 خزينة الخاسر: ${fmt(loser.coins)} عملة`,
  });
}
