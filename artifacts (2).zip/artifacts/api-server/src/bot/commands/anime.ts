import type { WASocket } from "@whiskeysockets/baileys";
import ytdl from "@distube/ytdl-core";
import ytSearch from "yt-search";
import type { Readable } from "stream";
import { logger } from "../../lib/logger.js";

async function streamToBuffer(stream: Readable): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    stream.on("data", (chunk: Buffer) => chunks.push(Buffer.from(chunk)));
    stream.on("end", () => resolve(Buffer.concat(chunks)));
    stream.on("error", reject);
  });
}

interface TikWmVideo {
  id: string;
  title: string;
  play: string;
  duration: number;
}

interface TikWmSearchResponse {
  code: number;
  data?: { videos?: TikWmVideo[] };
}

const TIKWM_BASE = "https://www.tikwm.com";
const FETCH_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  Referer: "https://www.tiktok.com/",
};

async function searchTikWm(query: string): Promise<TikWmVideo[]> {
  const url = `${TIKWM_BASE}/api/feed/search?keywords=${encodeURIComponent(query)}&count=10&cursor=0&web=1&hd=1`;
  const res = await fetch(url, { headers: FETCH_HEADERS });
  if (!res.ok) throw new Error(`tikwm HTTP ${res.status}`);
  const json = (await res.json()) as TikWmSearchResponse;
  if (json.code !== 0) throw new Error(`tikwm code ${json.code}`);
  return json.data?.videos ?? [];
}

async function downloadTikTokBuffer(videoId: string): Promise<Buffer> {
  const videoUrl = `https://www.tiktok.com/@user/video/${videoId}`;
  const apiUrl = `${TIKWM_BASE}/api/?url=${encodeURIComponent(videoUrl)}&hd=1`;
  const infoRes = await fetch(apiUrl, { headers: FETCH_HEADERS });
  if (!infoRes.ok) throw new Error(`tikwm info HTTP ${infoRes.status}`);
  const info = (await infoRes.json()) as {
    code: number;
    data?: { play: string };
  };
  if (info.code !== 0 || !info.data?.play) throw new Error("no play URL");
  const dlRes = await fetch(info.data.play, { headers: FETCH_HEADERS });
  if (!dlRes.ok) throw new Error(`download HTTP ${dlRes.status}`);
  return Buffer.from(await dlRes.arrayBuffer());
}

export async function handleAnime(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  if (!args.trim()) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى كتابة اسم الأنمي. مثال: .انمي naruto",
    });
    return;
  }

  const name = args.trim();
  const ytQuery = `${name} anime edit shorts`;
  const ttQuery = `${name} anime edit`;

  await sock.sendMessage(jid, {
    text: `🎌 جارٍ البحث عن إيدتات "${name}"...`,
  });

  let sent = 0;

  // --- YouTube first ---
  try {
    const res = await ytSearch(ytQuery);
    const shorts = res.videos
      .filter((v) => v.duration.seconds > 0 && v.duration.seconds <= 65)
      .slice(0, 5);

    for (const video of shorts) {
      if (sent >= 2) break;
      try {
        const stream = ytdl(video.url, {
          quality: "highestvideo",
          filter: "videoandaudio",
        });
        const buffer = await streamToBuffer(stream as unknown as Readable);
        await sock.sendMessage(jid, {
          video: buffer,
          mimetype: "video/mp4",
          caption: `🎌 ${video.title}`,
        });
        sent++;
      } catch (err) {
        logger.warn({ err, url: video.url }, "Anime YT download failed, skipping");
      }
    }
  } catch (err) {
    logger.warn({ err }, "Anime YouTube search failed");
  }

  // --- TikTok fallback if YouTube didn't yield 2 ---
  if (sent < 2) {
    try {
      const videos = await searchTikWm(ttQuery);
      const pool = videos
        .filter((v) => v.duration > 0 && v.duration <= 65)
        .slice(0, 5);

      for (const v of pool) {
        if (sent >= 2) break;
        try {
          const buffer = await downloadTikTokBuffer(v.id);
          await sock.sendMessage(jid, {
            video: buffer,
            mimetype: "video/mp4",
            ...(v.title ? { caption: `🎌 ${v.title}` } : {}),
          });
          sent++;
        } catch (err) {
          logger.warn({ err, id: v.id }, "Anime TT download failed, skipping");
        }
      }
    } catch (err) {
      logger.warn({ err }, "Anime TikTok search failed");
    }
  }

  if (sent === 0) {
    await sock.sendMessage(jid, {
      text: `❌ لم يتم العثور على إيدتات لـ "${name}". جرّب اسم أنمي آخر.`,
    });
  }
}
