import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";
import { SHOP_ITEMS, findItem } from "../data/shop-items.js";

function fmt(n: number): string {
  return n.toLocaleString("ar-EG");
}

export async function handleShop(sock: WASocket, jid: string): Promise<void> {
  const lines = SHOP_ITEMS.map(
    (item, i) =>
      `${i + 1}. ${item.nameAr}\n   📝 ${item.description}\n   💰 السعر: ${fmt(item.price)} عملة`,
  );

  await sock.sendMessage(jid, {
    text: `🛒 المتجر\n\n${lines.join("\n\n")}\n\n📌 للشراء: .شراء <اسم العنصر>`,
  });
}

export async function handleBuy(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  if (!args.trim()) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى كتابة اسم العنصر. مثال: .شراء مضاعف فلوس",
    });
    return;
  }

  const item = findItem(args);
  if (!item) {
    await sock.sendMessage(jid, {
      text: `❌ العنصر "${args}" غير موجود في المتجر.\nاكتب .متجر لعرض العناصر المتاحة.`,
    });
    return;
  }

  const user = getUser(jid);
  if (user.wallet < item.price) {
    await sock.sendMessage(jid, {
      text: `❌ رصيدك غير كافٍ!\n💰 محفظتك: ${fmt(user.wallet)} عملة\n💸 السعر: ${fmt(item.price)} عملة`,
    });
    return;
  }

  const updates: Parameters<typeof updateUser>[1] = {
    wallet: user.wallet - item.price,
  };

  if (item.id === "coin_boost") {
    updates.coinBoostUses = (user.coinBoostUses ?? 0) + item.uses;
  } else if (item.id === "xp_boost") {
    updates.xpBoostUses = (user.xpBoostUses ?? 0) + item.uses;
  } else if (item.id === "shield") {
    updates.shieldUses = (user.shieldUses ?? 0) + item.uses;
  }

  updateUser(jid, updates);

  await sock.sendMessage(jid, {
    text: `✅ تم الشراء بنجاح!\n🛍 ${item.nameAr}\n💰 تبقى في محفظتك: ${fmt(user.wallet - item.price)} عملة`,
  });
}
