import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser, addHistory } from "../db.js";
import { checkCooldown, setCooldown, msToHuman } from "../cooldown.js";

const STEAL_COOLDOWN_MS = 30 * 60 * 1000;   // 30 min between attempts
const JAIL_DURATION_MS  = 15 * 60 * 1000;   // 15 min jail
const FAIL_LOSS_MIN = 10_000;
const FAIL_LOSS_MAX = 60_000;

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function fmt(n: number): string { return n.toLocaleString("ar-EG"); }

/** Risk tier based on target wealth — poorer targets are harder to rob (they're more desperate) */
function getSuccessChance(targetWallet: number): number {
  if (targetWallet < 5_000)  return 0.20;
  if (targetWallet < 20_000) return 0.35;
  if (targetWallet < 80_000) return 0.50;
  return 0.60;
}

function riskLabel(successChance: number): string {
  if (successChance <= 0.20) return "🔴 خطر جداً";
  if (successChance <= 0.35) return "🟠 خطر";
  if (successChance <= 0.50) return "🟡 متوسط";
  return "🟢 جيد";
}

export function isJailed(jid: string): { jailed: boolean; remainingMs: number } {
  const user = getUser(jid);
  const now = Date.now();
  if (user.jailUntil > now) return { jailed: true, remainingMs: user.jailUntil - now };
  return { jailed: false, remainingMs: 0 };
}

export async function handleSteal(
  sock: WASocket,
  chatJid: string,
  senderJid: string,
  mentionedJids: string[],
): Promise<void> {
  // Jail check
  const { jailed, remainingMs: jailMs } = isJailed(senderJid);
  if (jailed) {
    await sock.sendMessage(chatJid, {
      text: `⛓️ أنت في السجن! اخرج بعد ${msToHuman(jailMs)}.`,
    });
    return;
  }

  // Cooldown check
  const { ok, remainingMs } = checkCooldown(senderJid, "steal", STEAL_COOLDOWN_MS);
  if (!ok) {
    await sock.sendMessage(chatJid, {
      text: `⏳ لازم تستنى ${msToHuman(remainingMs)} قبل ما تحاول تسرق تاني!`,
    });
    return;
  }

  const targetJid = mentionedJids[0];
  if (!targetJid) {
    await sock.sendMessage(chatJid, { text: "❌ حدد الضحية. مثال: .سرقة @user" });
    return;
  }
  if (targetJid === senderJid) {
    await sock.sendMessage(chatJid, { text: "😂 مش هتقدر تسرق نفسك!" });
    return;
  }

  const target = getUser(targetJid);
  if (target.wallet < 1_000) {
    await sock.sendMessage(chatJid, { text: "❌ الضحية مفلسة — مفيش حاجة تسرقها 😂" });
    return;
  }

  // Shield check
  if ((target.shieldUses ?? 0) > 0) {
    updateUser(targetJid, { shieldUses: target.shieldUses - 1 });
    setCooldown(senderJid, "steal"); // still triggers cooldown
    const targetNum = targetJid.replace(/[^0-9]/g, "");
    await sock.sendMessage(chatJid, {
      text: `🛡️ @${targetNum} محمي بدرع! فشلت السرقة.\n🛡️ دروع متبقية: ${target.shieldUses - 1}`,
      mentions: [targetJid],
    });
    return;
  }

  const successChance = getSuccessChance(target.wallet);
  const success = Math.random() < successChance;
  setCooldown(senderJid, "steal");

  const targetNum = targetJid.replace(/[^0-9]/g, "");

  if (success) {
    const pct = 0.10 + Math.random() * 0.25; // steal 10-35%
    const stolen = Math.floor(target.wallet * pct);
    updateUser(targetJid, { wallet: target.wallet - stolen });
    updateUser(senderJid, { wallet: getUser(senderJid).wallet + stolen });
    addHistory(senderJid, { type: "win", amount: stolen, description: `سرقة من @${targetNum}`, timestamp: Date.now() });
    addHistory(targetJid, { type: "loss", amount: stolen, description: `تم سرقته من @${senderJid.replace(/[^0-9]/g, "")}`, timestamp: Date.now() });

    await sock.sendMessage(chatJid, {
      text: `🦹 *نجحت السرقة!*\nسرقت ${fmt(stolen)} عملة من @${targetNum} 💸\n📊 نسبة النجاح كانت: ${Math.round(successChance * 100)}%\n⏳ كولداون: 30 دقيقة`,
      mentions: [targetJid],
    });
  } else {
    const lost = randomInt(FAIL_LOSS_MIN, FAIL_LOSS_MAX);
    const sender = getUser(senderJid);
    const actualLost = Math.min(lost, sender.wallet);
    updateUser(senderJid, {
      wallet: sender.wallet - actualLost,
      jailUntil: Date.now() + JAIL_DURATION_MS,
      losses: (sender.losses ?? 0) + 1,
    });
    addHistory(senderJid, { type: "loss", amount: actualLost, description: "فشل سرقة — دخل السجن", timestamp: Date.now() });

    const risk = riskLabel(successChance);
    await sock.sendMessage(chatJid, {
      text: `🚨 *امسكوه!*\nفشلت السرقة وتم القبض عليك! ⛓️\n💸 خسرت ${fmt(actualLost)} عملة\n⛓️ السجن: 15 دقيقة\n📊 مستوى المخاطرة: ${risk}`,
    });
  }
}

export async function handleEscape(sock: WASocket, chatJid: string, senderJid: string): Promise<void> {
  const user = getUser(senderJid);
  const now = Date.now();
  if (!user.jailUntil || user.jailUntil <= now) {
    updateUser(senderJid, { jailUntil: 0 });
    await sock.sendMessage(chatJid, { text: "🔓 أنت لست في السجن أصلاً!" });
    return;
  }
  const remainingMs = user.jailUntil - now;
  await sock.sendMessage(chatJid, { text: `⛓️ لا يمكنك الخروج بعد! انتظر ${msToHuman(remainingMs)}.` });
}

export async function handleRelease(sock: WASocket, chatJid: string, senderJid: string): Promise<void> {
  updateUser(senderJid, { jailUntil: 0 });
  await sock.sendMessage(chatJid, { text: "🔓 تم الإفراج عنك!" });
}
