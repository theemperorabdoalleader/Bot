import type { WASocket } from "@whiskeysockets/baileys";
import { addReminder, getReminders, removeReminder } from "../state.js";
import { logger } from "../../lib/logger.js";

export async function handleReminder(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  const parts = args.trim().split(/\s+/);
  const minutesStr = parts[0];
  const message = parts.slice(1).join(" ");

  if (!minutesStr || !message) {
    await sock.sendMessage(jid, {
      text: "❌ الصيغة الصحيحة: .تذكير <دقائق> <الرسالة>\nمثال: .تذكير 30 اشرب ماء",
    });
    return;
  }

  const minutes = parseInt(minutesStr, 10);
  if (isNaN(minutes) || minutes <= 0) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى إدخال عدد دقائق صحيح وموجب.",
    });
    return;
  }

  const reminder = addReminder(jid, minutes, message, async () => {
    try {
      await sock.sendMessage(jid, {
        text: `⏰ *تذكير!*\n\n${message}`,
      });
      removeReminder(jid, reminder.id);
    } catch (err) {
      logger.error({ err }, "Failed to send reminder");
    }
  });

  const dueTime = reminder.dueAt.toLocaleTimeString("ar-SA", {
    hour: "2-digit",
    minute: "2-digit",
  });

  await sock.sendMessage(jid, {
    text: `✅ تم ضبط التذكير!\n⏰ سيتم التذكير خلال *${minutes}* دقيقة\n📌 الرسالة: ${message}`,
  });
}

export async function handleListReminders(
  sock: WASocket,
  jid: string,
): Promise<void> {
  const list = getReminders(jid);

  if (list.length === 0) {
    await sock.sendMessage(jid, {
      text: "📭 لا توجد تذكيرات معلقة.",
    });
    return;
  }

  const lines = list.map((r, i) => {
    const remaining = Math.ceil((r.dueAt.getTime() - Date.now()) / 60000);
    return `${i + 1}. ⏰ بعد *${remaining}* دقيقة — ${r.message}`;
  });

  await sock.sendMessage(jid, {
    text: `📋 *تذكيراتك المعلقة (${list.length}):*\n\n${lines.join("\n")}`,
  });
}
