import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";
import { awardXP } from "./level.js";
import { checkAchievements } from "./achievements.js";
import { addHistory } from "../db.js";
import { getActiveBoss, setActiveBoss, clearActiveBoss } from "../state.js";

const BOSS_HP = 2000;
const BOSS_TIMEOUT_MS = 10 * 60_000;
const KILL_REWARD_MIN = 150_000;
const KILL_REWARD_MAX = 500_000;
const MVP_BONUS_MULTIPLIER = 1.5;

// Track per-boss damage across all attackers (keyed by chatJid)
const bossDamageMap = new Map<string, Map<string, number>>();

function hpBar(current: number, max: number): string {
  const pct = Math.round((current / max) * 10);
  const filled = "█".repeat(Math.max(0, pct));
  const empty = "░".repeat(Math.max(0, 10 - pct));
  return `[${filled}${empty}] ${current}/${max} HP`;
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function fmt(n: number): string { return n.toLocaleString("ar-EG"); }

function buildDamageLeaderboard(damageMap: Map<string, number>): string {
  const sorted = [...damageMap.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  const medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"];
  return sorted
    .map(([jid, dmg], i) => `${medals[i] ?? "•"} @${jid.replace(/[^0-9]/g, "")} — ${fmt(dmg)} ضرر`)
    .join("\n");
}

export async function handleSpawnBoss(sock: WASocket, chatJid: string): Promise<void> {
  if (getActiveBoss(chatJid)) {
    await sock.sendMessage(chatJid, { text: "⚠️ يوجد زعيم نشط الآن! اهجموه بـ .هجوم" });
    return;
  }

  bossDamageMap.set(chatJid, new Map<string, number>());

  const bossLevel = randomInt(1, 5);
  const scaledHp = BOSS_HP * bossLevel;
  const bossName = ["الوحش", "التنين", "الإمبراطور", "الشيطان", "الأسطورة"][bossLevel - 1]!;

  const timeout = setTimeout(async () => {
    const dmgMap = bossDamageMap.get(chatJid);
    bossDamageMap.delete(chatJid);
    clearActiveBoss(chatJid);
    try {
      const lb = dmgMap && dmgMap.size > 0 ? `\n\n🏆 *أعلى ضرر:*\n${buildDamageLeaderboard(dmgMap)}` : "";
      await sock.sendMessage(chatJid, {
        text: `💨 هرب ${bossName}! لم يهزمه أحد هذه المرة...${lb}`,
      });
    } catch {}
  }, BOSS_TIMEOUT_MS);

  setActiveBoss(chatJid, { hp: scaledHp, maxHp: scaledHp, lastAttackerJid: "", timeout });

  await sock.sendMessage(chatJid, {
    text: `👹 *ظهر ${bossName}!* (المستوى ${bossLevel})\n\n❤️ ${hpBar(scaledHp, scaledHp)}\n\n⚔️ اهجموه بـ .هجوم\n⏰ لديكم 10 دقائق!\n🏆 من يوجه الضربة الأخيرة يفوز بـ ${fmt(KILL_REWARD_MIN)}–${fmt(KILL_REWARD_MAX)} عملة!\n🥇 المهاجمون الأوائل يحصلون على مكافآت إضافية!`,
  });
}

export async function handleBossAttack(
  sock: WASocket, chatJid: string, attackerJid: string,
): Promise<void> {
  const boss = getActiveBoss(chatJid);
  if (!boss) {
    await sock.sendMessage(chatJid, { text: "❌ لا يوجد زعيم الآن. استخدم .زعيم لاستدعائه." });
    return;
  }

  const user = getUser(attackerJid);
  // Damage scales with attacker's level and wins
  const baseDmg = randomInt(50, 200);
  const levelBonus = Math.floor((user.level ?? 0) * 10);
  const damage = baseDmg + levelBonus;

  boss.hp = Math.max(0, boss.hp - damage);
  boss.lastAttackerJid = attackerJid;

  // Track damage
  const dmgMap = bossDamageMap.get(chatJid) ?? new Map<string, number>();
  dmgMap.set(attackerJid, (dmgMap.get(attackerJid) ?? 0) + damage);
  bossDamageMap.set(chatJid, dmgMap);

  const attackerNum = attackerJid.replace(/[^0-9]/g, "");

  if (boss.hp <= 0) {
    const allDmg = bossDamageMap.get(chatJid) ?? new Map<string, number>();
    bossDamageMap.delete(chatJid);
    clearActiveBoss(chatJid);

    // Kill reward goes to the last attacker (killing blow)
    const killReward = randomInt(KILL_REWARD_MIN, KILL_REWARD_MAX);
    updateUser(attackerJid, {
      wallet: getUser(attackerJid).wallet + killReward,
      wins: (getUser(attackerJid).wins ?? 0) + 1,
    });
    await awardXP(attackerJid, 200, sock);
    addHistory(attackerJid, { type: "win", amount: killReward, description: "قضى على الزعيم", timestamp: Date.now() });
    await checkAchievements(attackerJid, sock);

    // Consolation prizes for top attackers (not the killer)
    const sortedAttackers = [...allDmg.entries()]
      .sort((a, b) => b[1] - a[1])
      .filter(([jid]) => jid !== attackerJid)
      .slice(0, 3);

    const consolation = [30_000, 15_000, 8_000];
    const consolationMentions: string[] = [];
    let consolationLines = "";
    for (let i = 0; i < sortedAttackers.length; i++) {
      const [jid, dmg] = sortedAttackers[i]!;
      const prize = consolation[i] ?? 5_000;
      updateUser(jid, { wallet: getUser(jid).wallet + prize });
      await awardXP(jid, 50, sock);
      consolationLines += `\n${["🥈", "🥉", "4️⃣"][i]} @${jid.replace(/[^0-9]/g, "")} — ${fmt(dmg)} ضرر → +${fmt(prize)} عملة`;
      consolationMentions.push(jid);
    }

    const lb = buildDamageLeaderboard(allDmg);
    const mvpMult = (killReward * MVP_BONUS_MULTIPLIER).toFixed(0);
    void mvpMult;

    await sock.sendMessage(chatJid, {
      text: `💥 *الضربة القاضية!*\n⚔️ @${attackerNum} أنهى الزعيم!\n\n🏆 *مكافأة القتل:* ${fmt(killReward)} عملة!\n✨ +200 XP\n\n📊 *ترتيب الضرر الكلي:*\n${lb}${consolationLines ? `\n\n🎁 *مكافآت المساهمة:*${consolationLines}` : ""}`,
      mentions: [attackerJid, ...consolationMentions],
    });
    return;
  }

  const hpPct = Math.floor((boss.hp / boss.maxHp) * 100);
  const urgency = hpPct < 20 ? "\n🔥 *الزعيم ضعيف! أنهوه الآن!*" : "";

  await sock.sendMessage(chatJid, {
    text: `⚔️ @${attackerNum} ضرب بـ *${fmt(damage)}* ضرر!\n\n👹 ${hpBar(boss.hp, boss.maxHp)}${urgency}`,
    mentions: [attackerJid],
  });
}
