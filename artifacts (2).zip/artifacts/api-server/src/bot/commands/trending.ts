import type { WASocket } from "@whiskeysockets/baileys";
import ytdl from "@distube/ytdl-core";
import ytSearch from "yt-search";
import type { Readable } from "stream";
import { logger } from "../../lib/logger.js";

async function streamToBuffer(stream: Readable): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    stream.on("data", (chunk: Buffer) => chunks.push(Buffer.from(chunk)));
    stream.on("end", () => resolve(Buffer.concat(chunks)));
    stream.on("error", reject);
  });
}

const TRENDING_QUERIES = [
  "viral shorts trending today",
  "trending youtube shorts 2025",
  "most viewed shorts this week",
];

export async function handleTrending(
  sock: WASocket,
  jid: string,
): Promise<void> {
  await sock.sendMessage(jid, { text: "🔥 جارٍ جلب الفيديوهات الأكثر انتشاراً..." });

  let candidates: ytSearch.VideoSearchResult[] = [];

  for (const query of TRENDING_QUERIES) {
    try {
      const res = await ytSearch(query);
      const shorts = res.videos.filter(
        (v) => v.duration.seconds > 0 && v.duration.seconds <= 65,
      );
      candidates.push(...shorts);
      if (candidates.length >= 10) break;
    } catch (err) {
      logger.warn({ err, query }, "Trending search query failed, trying next");
    }
  }

  if (candidates.length === 0) {
    await sock.sendMessage(jid, {
      text: "❌ تعذّر جلب الفيديوهات الترندينج حالياً. حاول لاحقاً.",
    });
    return;
  }

  const shuffled = candidates
    .filter((v, i, arr) => arr.findIndex((x) => x.videoId === v.videoId) === i)
    .slice(0, 8);

  let sent = 0;
  for (const video of shuffled) {
    if (sent >= 3) break;
    try {
      const stream = ytdl(video.url, {
        quality: "highestvideo",
        filter: "videoandaudio",
      });
      const buffer = await streamToBuffer(stream as unknown as Readable);
      await sock.sendMessage(jid, {
        video: buffer,
        mimetype: "video/mp4",
        caption: `🔥 ${video.title}`,
      });
      sent++;
    } catch (err) {
      logger.warn({ err, url: video.url }, "Trending video download failed, skipping");
    }
  }

  if (sent === 0) {
    await sock.sendMessage(jid, {
      text: "❌ فشل في تحميل الفيديوهات. يرجى المحاولة لاحقاً.",
    });
  }
}
