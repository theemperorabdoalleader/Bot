import type { WASocket } from "@whiskeysockets/baileys";
import { randomCharacter } from "../data/anime-eyes.js";
import { randomPlayer } from "../data/football-players.js";
import { randomRiddle } from "../data/riddles.js";
import { awardXP, awardCoins } from "./level.js";
import { setActiveGame, clearActiveGame, type GameSession } from "../state.js";
import { logger } from "../../lib/logger.js";

const GAME_TIMEOUT_MS = 2 * 60 * 1000;

function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/[أإآا]/g, "ا")
    .replace(/[ةه]/g, "ه")
    .replace(/ى/g, "ي")
    .trim();
}

function isCorrect(input: string, answer: string, altAnswers: string[]): boolean {
  const norm = normalize(input);
  const targets = [answer, ...altAnswers].map(normalize);
  return targets.some((t) => norm === t || norm.includes(t) || t.includes(norm));
}

async function fetchAniListImage(anilistId: number): Promise<string> {
  const body = JSON.stringify({
    query: `query { Character(id: ${anilistId}) { image { large } } }`,
  });
  const res = await fetch("https://graphql.anilist.co", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body,
  });
  if (!res.ok) throw new Error(`AniList HTTP ${res.status}`);
  const data = (await res.json()) as {
    data: { Character: { image: { large: string } } };
  };
  return data.data.Character.image.large;
}

async function fetchPlayerImage(searchName: string): Promise<string | null> {
  const url = `https://www.thesportsdb.com/api/v1/json/3/searchplayers.php?p=${encodeURIComponent(searchName)}`;
  const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
  if (!res.ok) return null;
  const data = (await res.json()) as {
    player?: Array<{ strThumb?: string; strCutout?: string }>;
  };
  const player = data.player?.[0];
  return player?.strThumb ?? player?.strCutout ?? null;
}

async function downloadBuffer(url: string): Promise<Buffer> {
  const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
  if (!res.ok) throw new Error(`Image HTTP ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

export async function handleGameAnswer(
  sock: WASocket,
  jid: string,
  input: string,
  game: GameSession,
): Promise<void> {
  clearActiveGame(jid);

  if (isCorrect(input, game.answer, game.altAnswers)) {
    const gained = await awardCoins(jid, 100_000);
    await awardXP(jid, 50, sock);
    await sock.sendMessage(jid, {
      text: `✅ إجابة صحيحة! 🎉\n💰 +${gained.toLocaleString("ar-EG")} عملة\n✨ +50 XP`,
    });
  } else {
    await sock.sendMessage(jid, {
      text: `❌ إجابة خاطئة!\nالإجابة الصحيحة: *${game.displayAnswer}*`,
    });
  }
}

export async function handleEyeGame(sock: WASocket, jid: string): Promise<void> {
  const char = randomCharacter();
  await sock.sendMessage(jid, { text: "👁 خمّن شخصية الأنمي من صورتها!\n💡 أرسل الاسم خلال دقيقتين" });

  let imageUrl: string;
  try {
    imageUrl = await fetchAniListImage(char.anilistId);
  } catch (err) {
    logger.error({ err }, "AniList image fetch failed");
    await sock.sendMessage(jid, { text: "❌ فشل في جلب الصورة. حاول مرة أخرى." });
    return;
  }

  let buffer: Buffer;
  try {
    buffer = await downloadBuffer(imageUrl);
  } catch (err) {
    logger.error({ err }, "Image download failed");
    await sock.sendMessage(jid, { text: "❌ فشل في تحميل الصورة. حاول مرة أخرى." });
    return;
  }

  await sock.sendMessage(jid, { image: buffer, caption: "🎌 من هذه الشخصية؟" });

  const timeout = setTimeout(async () => {
    clearActiveGame(jid);
    try {
      await sock.sendMessage(jid, {
        text: `⏰ انتهى الوقت!\nالإجابة الصحيحة: *${char.nameAr}*`,
      });
    } catch {}
  }, GAME_TIMEOUT_MS);

  setActiveGame(jid, {
    type: "eye",
    answer: char.nameAr,
    altAnswers: [char.nameEn],
    displayAnswer: `${char.nameAr} (${char.series})`,
    timeout,
  });
}

export async function handlePlayerGame(sock: WASocket, jid: string): Promise<void> {
  const player = randomPlayer();
  await sock.sendMessage(jid, { text: "⚽ خمّن اسم اللاعب من صورته!\n💡 أرسل الاسم خلال دقيقتين" });

  const imageUrl = await fetchPlayerImage(player.searchName);
  if (!imageUrl) {
    await sock.sendMessage(jid, { text: "❌ فشل في جلب صورة اللاعب. حاول مرة أخرى." });
    return;
  }

  let buffer: Buffer;
  try {
    buffer = await downloadBuffer(imageUrl);
  } catch (err) {
    logger.error({ err }, "Player image download failed");
    await sock.sendMessage(jid, { text: "❌ فشل في تحميل الصورة. حاول مرة أخرى." });
    return;
  }

  await sock.sendMessage(jid, { image: buffer, caption: `⚽ من هذا اللاعب؟\n🌍 ${player.nationality}` });

  const timeout = setTimeout(async () => {
    clearActiveGame(jid);
    try {
      await sock.sendMessage(jid, {
        text: `⏰ انتهى الوقت!\nالإجابة الصحيحة: *${player.nameAr}* (${player.searchName})`,
      });
    } catch {}
  }, GAME_TIMEOUT_MS);

  setActiveGame(jid, {
    type: "player",
    answer: player.nameAr,
    altAnswers: [player.nameEn, player.searchName.toLowerCase()],
    displayAnswer: `${player.nameAr} — ${player.searchName}`,
    timeout,
  });
}

export async function handleRiddleGame(sock: WASocket, jid: string): Promise<void> {
  const riddle = randomRiddle();

  await sock.sendMessage(jid, {
    text: `🧩 لغز!\n\n❓ ${riddle.question}\n\n💡 أرسل إجابتك خلال دقيقتين`,
  });

  const timeout = setTimeout(async () => {
    clearActiveGame(jid);
    try {
      await sock.sendMessage(jid, {
        text: `⏰ انتهى الوقت!\nالإجابة الصحيحة: *${riddle.answer}*`,
      });
    } catch {}
  }, GAME_TIMEOUT_MS);

  setActiveGame(jid, {
    type: "riddle",
    answer: riddle.answer,
    altAnswers: [],
    displayAnswer: riddle.answer,
    timeout,
  });
}
