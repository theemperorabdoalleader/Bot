import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";
import { awardXP, awardCoins } from "./level.js";
import { getActiveEvent, setActiveEvent, clearActiveEvent, getActiveChats } from "../state.js";

const EVENT_INTERVAL_MS = 20 * 60_000;
const EVENT_TIMEOUT_MS  = 90_000; // 90 seconds to answer

// ── Event pools ───────────────────────────────────────────────────────────────

const QUICK_EVENTS = [
  { trigger: "GO",    prompt: '⚡ *حدث سريع!*\n\nأول واحد يكتب *GO* يكسب 50,000 عملة!\nعندك 90 ثانية! 🏃', answer: "go",    reward: 50_000 },
  { trigger: "نعم",   prompt: '⚡ *حدث سريع!*\n\nأول واحد يكتب *نعم* يكسب 35,000 عملة! 🎁',               answer: "نعم",   reward: 35_000 },
  { trigger: "ابدأ",  prompt: '⚡ *حدث سريع!*\n\nأول واحد يكتب *ابدأ* يكسب 45,000 عملة! 🚀',             answer: "ابدأ",  reward: 45_000 },
  { trigger: "قوة",   prompt: '⚡ *طاقة الفريق!*\n\nأول واحد يكتب *قوة* يكسب 40,000 عملة! 💪',          answer: "قوة",   reward: 40_000 },
  { trigger: "فوز",   prompt: '⚡ *لحظة نصر!*\n\nأول واحد يكتب *فوز* يكسب 55,000 عملة! 🏆',            answer: "فوز",   reward: 55_000 },
];

const MATH_EVENTS = [
  { question: "كم يساوي 7 × 8؟",       answer: "56",  reward: 30_000 },
  { question: "كم يساوي 15 + 27؟",      answer: "42",  reward: 25_000 },
  { question: "كم يساوي 100 − 37؟",     answer: "63",  reward: 25_000 },
  { question: "كم يساوي 9 × 9؟",        answer: "81",  reward: 30_000 },
  { question: "كم يساوي 144 ÷ 12؟",     answer: "12",  reward: 25_000 },
  { question: "كم يساوي 3 × 3 × 3؟",   answer: "27",  reward: 30_000 },
  { question: "كم يساوي 50 × 4؟",       answer: "200", reward: 35_000 },
  { question: "كم يساوي 200 ÷ 8؟",      answer: "25",  reward: 30_000 },
  { question: "كم يساوي 12 × 12؟",      answer: "144", reward: 35_000 },
  { question: "كم يساوي (5 + 3) × 7؟", answer: "56",  reward: 40_000 },
  { question: "كم يساوي 1000 ÷ 25؟",   answer: "40",  reward: 40_000 },
];

const TRIVIA_EVENTS = [
  { question: "ما عاصمة فرنسا؟",                           answer: "باريس",     reward: 20_000 },
  { question: "ما أكبر دولة في العالم مساحةً؟",            answer: "روسيا",     reward: 20_000 },
  { question: "كم عدد أيام السنة؟",                        answer: "365",       reward: 20_000 },
  { question: "ما عاصمة اليابان؟",                          answer: "طوكيو",     reward: 20_000 },
  { question: "ما أطول نهر في العالم؟",                    answer: "النيل",     reward: 20_000 },
  { question: "ما أكبر كوكب في المجموعة الشمسية؟",         answer: "المشتري",   reward: 20_000 },
  { question: "ما عاصمة البرازيل؟",                         answer: "برازيليا",  reward: 20_000 },
  { question: "من اخترع الهاتف؟",                           answer: "غراهام بيل", reward: 25_000 },
  { question: "ما أصغر دولة في العالم؟",                   answer: "الفاتيكان", reward: 25_000 },
  { question: "كم عدد ألوان الطيف؟",                       answer: "7",         reward: 20_000 },
  { question: "ما عملة اليابان؟",                           answer: "الين",      reward: 20_000 },
  { question: "كم عدد أيام شهر فبراير في السنة العادية؟", answer: "28",         reward: 20_000 },
];

const EMOJI_EVENTS = [
  { clue: "🦁👑", answer: "ملك الغابة", alts: ["اسد", "الاسد"], reward: 30_000 },
  { clue: "🌙⭐🌙", answer: "رمضان",    alts: ["شهر رمضان"],   reward: 30_000 },
  { clue: "⚽🏆",  answer: "كأس العالم", alts: ["كاس العالم"],  reward: 30_000 },
  { clue: "🌊🏄",  answer: "ركوب الأمواج", alts: ["تزلج الماء"], reward: 25_000 },
  { clue: "🎭🎬",  answer: "مسرح",       alts: ["المسرح"],      reward: 25_000 },
];

// ── Penalty events (taken if nobody answers) ─────────────────────────────────
const STORM_EVENTS = [
  { prompt: "⚡ *عاصفة عملات!*\n\nعاصفة قادمة! أول واحد يكتب *احمِ* ينجو ويكسب 80,000 عملة!\nوإلا ستُسرق عملات عشوائياً! 🌪️", answer: "احمِ", reward: 80_000 },
  { prompt: "🔥 *هجوم اللصوص!*\n\nعصابة تهاجم المجموعة! أول واحد يكتب *دافع* ينقذ الجميع ويكسب 70,000 عملة! 🛡️", answer: "دافع", reward: 70_000 },
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]!;
}

export function spawnRandomEvent(sock: WASocket): void {
  const chats = [...getActiveChats()];
  if (chats.length === 0) return;

  const chatJid = pick(chats);
  if (getActiveEvent(chatJid)) return;

  const roll = Math.random();
  let prompt: string;
  let answer: string;
  let reward: number;
  let isStorm = false;
  let extraAlts: string[] = [];

  if (roll < 0.25) {
    const e = pick(QUICK_EVENTS);
    prompt = e.prompt;
    answer = e.answer.toLowerCase();
    reward = e.reward;
  } else if (roll < 0.45) {
    const e = pick(MATH_EVENTS);
    prompt = `⚡ *سؤال رياضيات سريع!*\n\n🔢 ${e.question}\n\nأول إجابة صحيحة تفوز بـ ${e.reward.toLocaleString("ar-EG")} عملة! ⏱️`;
    answer = e.answer;
    reward = e.reward;
  } else if (roll < 0.65) {
    const e = pick(TRIVIA_EVENTS);
    prompt = `⚡ *سؤال ثقافي!*\n\n❓ ${e.question}\n\nأول إجابة صحيحة تفوز بـ ${e.reward.toLocaleString("ar-EG")} عملة! 🎯`;
    answer = e.answer;
    reward = e.reward;
  } else if (roll < 0.80) {
    const e = pick(EMOJI_EVENTS);
    prompt = `⚡ *خمّن من الإيموجي!*\n\n${e.clue}\n\nماذا يمثل هذا؟ أول إجابة صحيحة تفوز بـ ${e.reward.toLocaleString("ar-EG")} عملة! 🤔`;
    answer = e.answer;
    extraAlts = e.alts;
    reward = e.reward;
  } else {
    const e = pick(STORM_EVENTS);
    prompt = e.prompt;
    answer = e.answer;
    reward = e.reward;
    isStorm = true;
  }

  const timeout = setTimeout(() => {
    clearActiveEvent(chatJid);
    const timeoutMsg = isStorm
      ? `🌪️ لم يردّ أحد! بعض اللاعبين خسروا 15,000 عملة من العاصفة! 💸`
      : `⏰ انتهى وقت الحدث! الإجابة كانت: *${answer}*`;

    if (isStorm) {
      // Penalize random active users (simulated)
      // We don't track who's active per group easily, so just announce
    }

    sock.sendMessage(chatJid, { text: timeoutMsg }).catch(() => {});
  }, EVENT_TIMEOUT_MS);

  setActiveEvent(chatJid, { answer, reward, timeout, alts: extraAlts });
  sock.sendMessage(chatJid, { text: prompt }).catch(() => {});
}

export function startEventScheduler(sock: WASocket): void {
  setInterval(() => { spawnRandomEvent(sock); }, EVENT_INTERVAL_MS);
}

export async function handleEventAnswer(
  sock: WASocket,
  chatJid: string,
  senderJid: string,
  text: string,
): Promise<boolean> {
  const event = getActiveEvent(chatJid);
  if (!event) return false;

  const normalized = text.trim().toLowerCase()
    .replace(/[أإآا]/g, "ا")
    .replace(/[ةه]/g, "ه")
    .replace(/ى/g, "ي");

  const answerNorm = event.answer.toLowerCase()
    .replace(/[أإآا]/g, "ا")
    .replace(/[ةه]/g, "ه")
    .replace(/ى/g, "ي");

  const alts = (event.alts ?? []).map((a: string) => a.toLowerCase()
    .replace(/[أإآا]/g, "ا")
    .replace(/[ةه]/g, "ه")
    .replace(/ى/g, "ي"));

  const isMatch = normalized === answerNorm ||
    alts.some((a: string) => normalized === a || normalized.includes(a));

  if (!isMatch) return false;

  clearActiveEvent(chatJid);
  const gained = await awardCoins(senderJid, event.reward);
  await awardXP(senderJid, 25, sock);

  const num = senderJid.replace(/[^0-9]/g, "");
  await sock.sendMessage(chatJid, {
    text: `🎉 *إجابة صحيحة!*\n⚡ @${num} فاز بـ ${gained.toLocaleString("ar-EG")} عملة! 💰\n✨ +25 XP`,
    mentions: [senderJid],
  });
  return true;
}
