import type { WASocket } from "@whiskeysockets/baileys";
import { logger } from "../../lib/logger.js";

interface TikWmVideo {
  id: string;
  title: string;
  play: string;
  wmplay: string;
  duration: number;
}

interface TikWmSearchResponse {
  code: number;
  data?: {
    videos?: TikWmVideo[];
  };
}

interface TikWmVideoResponse {
  code: number;
  data?: {
    play: string;
    wmplay: string;
    title: string;
    duration: number;
  };
}

const TIKWM_BASE = "https://www.tikwm.com";
const FETCH_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Referer": "https://www.tiktok.com/",
};

async function searchTikTok(query: string): Promise<TikWmVideo[]> {
  const url = `${TIKWM_BASE}/api/feed/search?keywords=${encodeURIComponent(query)}&count=10&cursor=0&web=1&hd=1`;
  const res = await fetch(url, { headers: FETCH_HEADERS });
  if (!res.ok) throw new Error(`tikwm search HTTP ${res.status}`);
  const json = (await res.json()) as TikWmSearchResponse;
  if (json.code !== 0) throw new Error(`tikwm search code ${json.code}`);
  return json.data?.videos ?? [];
}

async function downloadBuffer(videoUrl: string): Promise<Buffer> {
  const apiUrl = `${TIKWM_BASE}/api/?url=${encodeURIComponent(videoUrl)}&hd=1`;
  const infoRes = await fetch(apiUrl, { headers: FETCH_HEADERS });
  if (!infoRes.ok) throw new Error(`tikwm info HTTP ${infoRes.status}`);
  const info = (await infoRes.json()) as TikWmVideoResponse;
  if (info.code !== 0 || !info.data?.play) {
    throw new Error(`tikwm info code ${info.code}`);
  }

  const playUrl = info.data.play;
  const dlRes = await fetch(playUrl, { headers: FETCH_HEADERS });
  if (!dlRes.ok) throw new Error(`video download HTTP ${dlRes.status}`);
  const ab = await dlRes.arrayBuffer();
  return Buffer.from(ab);
}

export async function handleTiktok(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  if (!args.trim()) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى إدخال كلمة بحث. مثال: .اديت anime edit",
    });
    return;
  }

  await sock.sendMessage(jid, {
    text: `🔍 جارٍ البحث عن "${args.trim()}" على تيك توك...`,
  });

  let videos: TikWmVideo[];
  try {
    videos = await searchTikTok(args.trim());
  } catch (err) {
    logger.error({ err }, "TikTok search failed");
    await sock.sendMessage(jid, {
      text: "❌ حدث خطأ أثناء البحث. يرجى المحاولة لاحقاً.",
    });
    return;
  }

  if (videos.length === 0) {
    await sock.sendMessage(jid, {
      text: `❌ لم يتم العثور على نتائج لـ "${args.trim()}".`,
    });
    return;
  }

  const shorts = videos.filter((v) => v.duration > 0 && v.duration <= 60);
  const pool = shorts.length > 0 ? shorts : videos;

  let sent = 0;
  for (const v of pool) {
    if (sent >= 3) break;
    const tiktokUrl = `https://www.tiktok.com/@user/video/${v.id}`;
    try {
      const buffer = await downloadBuffer(tiktokUrl);
      await sock.sendMessage(jid, {
        video: buffer,
        mimetype: "video/mp4",
        ...(v.title ? { caption: `🎬 ${v.title}` } : {}),
      });
      sent++;
    } catch (err) {
      logger.warn({ err, id: v.id }, "Failed to download TikTok video, skipping");
    }
  }

  if (sent === 0) {
    await sock.sendMessage(jid, {
      text: "❌ فشل في تحميل الفيديوهات. يرجى المحاولة لاحقاً.",
    });
  }
}
