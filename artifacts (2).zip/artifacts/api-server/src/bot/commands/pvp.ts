/**
 * PvP Duel System — .دوري @user <amount>
 * Auto-resolved combat: each player rolls 3 rounds, highest total wins.
 * Win/Loss affects rankPoints (ELO-style).
 */
import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser, addHistory } from "../db.js";
import { awardXP } from "./level.js";
import { getRankTier } from "./level.js";
import { checkCooldown, setCooldown, msToHuman } from "../cooldown.js";

const ACCEPT_TIMEOUT_MS = 60_000;
const PVP_COOLDOWN_MS   = 10 * 60_000; // 10 min between duels
const ELO_K = 32;

interface PendingDuel {
  challengerJid: string;
  amount: number;
  timeout: ReturnType<typeof setTimeout>;
}

const pendingDuels = new Map<string, PendingDuel>(); // chatJid -> duel

function fmt(n: number): string { return n.toLocaleString("ar-EG"); }

function rollRounds(rounds = 3): number[] {
  return Array.from({ length: rounds }, () => Math.floor(Math.random() * 100) + 1);
}

function eloChange(winnerRating: number, loserRating: number): number {
  const expected = 1 / (1 + Math.pow(10, (loserRating - winnerRating) / 400));
  return Math.round(ELO_K * (1 - expected));
}

export async function handlePvpChallenge(
  sock: WASocket,
  chatJid: string,
  challengerJid: string,
  args: string,
  mentionedJids: string[],
): Promise<void> {
  const targetJid = mentionedJids[0];
  if (!targetJid) {
    await sock.sendMessage(chatJid, { text: "❌ حدد الخصم. مثال: .دوري @user 50000" });
    return;
  }
  if (targetJid === challengerJid) {
    await sock.sendMessage(chatJid, { text: "❌ لا يمكنك تحدي نفسك!" });
    return;
  }

  const { ok, remainingMs } = checkCooldown(challengerJid, "pvp", PVP_COOLDOWN_MS);
  if (!ok) {
    await sock.sendMessage(chatJid, { text: `⏳ عليك الانتظار ${msToHuman(remainingMs)} قبل دوري جديد.` });
    return;
  }

  const amountStr = args.replace(/@\S+/g, "").trim();
  const amount = parseInt(amountStr);
  if (!amount || amount < 1000) {
    await sock.sendMessage(chatJid, { text: "❌ الحد الأدنى للرهان 1,000 عملة." });
    return;
  }

  const challenger = getUser(challengerJid);
  if (challenger.wallet < amount) {
    await sock.sendMessage(chatJid, {
      text: `❌ رصيدك غير كافٍ!\n💰 محفظتك: ${fmt(challenger.wallet)} عملة`,
    });
    return;
  }

  if (pendingDuels.has(chatJid)) {
    await sock.sendMessage(chatJid, { text: "⚠️ يوجد دوري معلق في هذه المجموعة. انتظر حتى ينتهي." });
    return;
  }

  const timeout = setTimeout(async () => {
    pendingDuels.delete(chatJid);
    try {
      await sock.sendMessage(chatJid, { text: "⏰ انتهى وقت قبول الدوري. تم الإلغاء." });
    } catch {}
  }, ACCEPT_TIMEOUT_MS);

  pendingDuels.set(chatJid, { challengerJid, amount, timeout });

  const challengerTier = getRankTier(challenger.xp);
  const targetNum = targetJid.replace(/[^0-9]/g, "");

  await sock.sendMessage(chatJid, {
    text: `⚔️ *تحدي دوري!*\n\n${challengerTier.emoji} @${challengerJid.replace(/[^0-9]/g, "")} يتحدى @${targetNum}\n💰 الرهان: ${fmt(amount)} عملة\n\n📣 @${targetNum} اكتب .قبول_دوري خلال دقيقة!`,
    mentions: [challengerJid, targetJid],
  });
}

export async function handlePvpAccept(
  sock: WASocket,
  chatJid: string,
  acceptorJid: string,
): Promise<void> {
  const duel = pendingDuels.get(chatJid);
  if (!duel) {
    await sock.sendMessage(chatJid, { text: "❌ لا يوجد دوري معلق." });
    return;
  }
  if (duel.challengerJid === acceptorJid) {
    await sock.sendMessage(chatJid, { text: "❌ لا يمكنك قبول تحديك الخاص!" });
    return;
  }

  const acceptor = getUser(acceptorJid);
  if (acceptor.wallet < duel.amount) {
    await sock.sendMessage(chatJid, {
      text: `❌ رصيدك غير كافٍ لقبول الدوري!\n💰 محفظتك: ${fmt(acceptor.wallet)} عملة`,
    });
    return;
  }

  clearTimeout(duel.timeout);
  pendingDuels.delete(chatJid);

  // Deduct bets
  const challenger = getUser(duel.challengerJid);
  updateUser(duel.challengerJid, { wallet: challenger.wallet - duel.amount });
  updateUser(acceptorJid, { wallet: acceptor.wallet - duel.amount });

  setCooldown(duel.challengerJid, "pvp");
  setCooldown(acceptorJid, "pvp");

  // ── Simulate battle ──────────────────────────────────────────────────────
  const cRolls = rollRounds(3);
  const aRolls = rollRounds(3);
  const cTotal = cRolls.reduce((a, b) => a + b, 0);
  const aTotal = aRolls.reduce((a, b) => a + b, 0);

  const challengerNum = duel.challengerJid.replace(/[^0-9]/g, "");
  const acceptorNum   = acceptorJid.replace(/[^0-9]/g, "");

  const battleLines = [1, 2, 3].map((r) => {
    const cr = cRolls[r - 1]!;
    const ar = aRolls[r - 1]!;
    const roundWinner = cr > ar ? `⚔️ جولة ${r}: ${cr} vs ${ar} → @${challengerNum}` :
                         ar > cr ? `⚔️ جولة ${r}: ${cr} vs ${ar} → @${acceptorNum}` :
                         `⚔️ جولة ${r}: ${cr} vs ${ar} → تعادل!`;
    return roundWinner;
  }).join("\n");

  // ELO-based rank point changes
  const cRankPts = challenger.rankPoints ?? 1000;
  const aRankPts = acceptor.rankPoints ?? 1000;

  let winnerJid: string;
  let loserJid: string;
  let winnerTotal: number;
  let loserTotal: number;

  if (cTotal > aTotal) {
    winnerJid = duel.challengerJid;
    loserJid  = acceptorJid;
    winnerTotal = cTotal;
    loserTotal  = aTotal;
  } else if (aTotal > cTotal) {
    winnerJid = acceptorJid;
    loserJid  = duel.challengerJid;
    winnerTotal = aTotal;
    loserTotal  = cTotal;
  } else {
    // Tie — refund both
    updateUser(duel.challengerJid, { wallet: getUser(duel.challengerJid).wallet + duel.amount });
    updateUser(acceptorJid, { wallet: getUser(acceptorJid).wallet + duel.amount });
    await sock.sendMessage(chatJid, {
      text: `⚔️ *دوري — تعادل!*\n\n${battleLines}\n\n📊 النتيجة: ${cTotal} vs ${aTotal}\n🔁 تم إرجاع الرهانات.`,
      mentions: [duel.challengerJid, acceptorJid],
    });
    return;
  }

  const prize = duel.amount * 2;
  const winnerUser = getUser(winnerJid);
  const loserUser  = getUser(loserJid);
  const eloGain = eloChange(
    winnerJid === duel.challengerJid ? cRankPts : aRankPts,
    winnerJid === duel.challengerJid ? aRankPts : cRankPts,
  );

  updateUser(winnerJid, {
    wallet: winnerUser.wallet + prize,
    wins: (winnerUser.wins ?? 0) + 1,
    pvpWins: (winnerUser.pvpWins ?? 0) + 1,
    rankPoints: Math.min(5000, (winnerJid === duel.challengerJid ? cRankPts : aRankPts) + eloGain),
  });

  updateUser(loserJid, {
    losses: (loserUser.losses ?? 0) + 1,
    pvpLosses: (loserUser.pvpLosses ?? 0) + 1,
    rankPoints: Math.max(100, (loserJid === duel.challengerJid ? cRankPts : aRankPts) - eloGain),
  });

  await awardXP(winnerJid, 80, sock);
  await awardXP(loserJid, 20, sock);

  addHistory(winnerJid, { type: "win", amount: prize, description: "فاز بدوري PvP", timestamp: Date.now() });
  addHistory(loserJid,  { type: "loss", amount: duel.amount, description: "خسر دوري PvP", timestamp: Date.now() });

  const winnerNum = winnerJid.replace(/[^0-9]/g, "");
  const winnerTier = getRankTier(getUser(winnerJid).xp);

  await sock.sendMessage(chatJid, {
    text: `⚔️ *نتيجة الدوري!*\n\n${battleLines}\n\n📊 النتيجة الإجمالية:\n@${challengerNum}: ${winnerTotal} | @${acceptorNum}: ${loserTotal}\n\n🏆 الفائز: @${winnerNum} ${winnerTier.emoji}\n💰 الجائزة: ${fmt(prize)} عملة\n📈 نقاط الرتبة: +${eloGain}\n✨ +80 XP للفائز, +20 XP للخاسر`,
    mentions: [winnerJid, loserJid],
  });
}

export function getPendingPvpDuel(chatJid: string): PendingDuel | undefined {
  return pendingDuels.get(chatJid);
}
