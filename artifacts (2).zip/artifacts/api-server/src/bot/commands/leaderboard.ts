import type { WASocket } from "@whiskeysockets/baileys";
import { getTopByWealth, getTopByXP } from "../db.js";
import { getLevelInfo } from "./level.js";

const MEDALS = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"];

function fmt(n: number): string {
  return n.toLocaleString("ar-EG");
}

function shortNum(jid: string): string {
  return jid.replace(/[^0-9]/g, "");
}

export async function handleRichLeaderboard(sock: WASocket, jid: string): Promise<void> {
  const top = getTopByWealth(5);
  if (top.length === 0) {
    await sock.sendMessage(jid, { text: "❌ لا يوجد مستخدمون بعد." });
    return;
  }

  const lines = top.map((entry, i) => {
    const num = shortNum(entry.jid);
    return `${MEDALS[i]} @${num} — ${fmt(entry.total)} عملة`;
  });

  await sock.sendMessage(jid, {
    text: `👑 الأباطرة — أغنى 5 لاعبين\n\n${lines.join("\n")}`,
    mentions: top.map((e) => e.jid),
  });
}

export async function handleXPLeaderboard(sock: WASocket, jid: string): Promise<void> {
  const top = getTopByXP(5);
  if (top.length === 0) {
    await sock.sendMessage(jid, { text: "❌ لا يوجد مستخدمون بعد." });
    return;
  }

  const lines = top.map((entry, i) => {
    const num = shortNum(entry.jid);
    const rank = getLevelInfo(entry.xp).nameAr;
    return `${MEDALS[i]} @${num} — ${fmt(entry.xp)} XP (${rank})`;
  });

  await sock.sendMessage(jid, {
    text: `🎖 الجيش — أعلى 5 رتباً\n\n${lines.join("\n")}`,
    mentions: top.map((e) => e.jid),
  });
}
