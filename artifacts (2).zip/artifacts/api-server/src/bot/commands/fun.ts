import type { WASocket } from "@whiskeysockets/baileys";

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]!;
}

const MARRIAGE_WIN = [
  "💍 تم الزواج بنجاح! 🎉\n{1} ❤️ {2}\nمبروك عليكم! 🥂",
  "💍 اتجوزوا على خير!\n{1} 💕 {2}\nربنا يكملها بالبركة 🌸",
  "💍 اتفضلوا سكر!\n{1} 😍 {2}\nالله يتمم بالخير! 🎊",
];
const MARRIAGE_FAIL = [
  "💔 فشل الزواج 😂\n{1} ✋ {2}\nمش مناسبين لبعض!",
  "💔 مرفوض! 😭\n{2} عايز حاجة أحسن من {1} 😂",
  "💔 الزواج ده مش هينفع 😅\nحاول مع حد تاني!",
];

export async function handleMarriage(
  sock: WASocket,
  jid: string,
  user1: string,
  user2: string,
): Promise<void> {
  const success = Math.random() > 0.4;
  const templates = success ? MARRIAGE_WIN : MARRIAGE_FAIL;
  const msg = pick(templates).replace("{1}", user1).replace("{2}", user2);
  await sock.sendMessage(jid, { text: msg });
}

const HATE_YES = [
  "😡 آه والله! {user} بيكرهك بشكل شخصي 💀",
  "🔪 {user} مش بس بيكرهك، بيترفعلك كمان 😂",
  "😤 الشخص ده بيكرهك من زمان وبس خبي 💔",
];
const HATE_NO = [
  "😂 لا بالعكس! {user} بيموت فيك 🥰",
  "🤣 {user} ده بيحبك وبيعمل نفسه بيكرهك!",
  "😅 إيه ده؟ {user} فاكرك أحسن واحد! 😂",
];

export async function handleHate(
  sock: WASocket,
  jid: string,
  user: string,
): Promise<void> {
  const hates = Math.random() > 0.5;
  const msg = pick(hates ? HATE_YES : HATE_NO).replace(/{user}/g, user);
  await sock.sendMessage(jid, { text: msg });
}

const LOVE_YES = [
  "❤️ آه! {user} بيحبك من قلبه 😍",
  "🥰 {user} بيفكر فيك طول اليوم! ❤️‍🔥",
  "💕 الشخص ده بيحبك وبيخبي 😭❤️",
];
const LOVE_NO = [
  "😂 لا! {user} عامل نفسه بس 🤥",
  "🤣 {user} ده بيمثل معاك يا حبيبي 😅",
  "💔 لا ده مش بيحبك، بس بيلاقيك 😂",
];

export async function handleLove(
  sock: WASocket,
  jid: string,
  user: string,
): Promise<void> {
  const loves = Math.random() > 0.5;
  const msg = pick(loves ? LOVE_YES : LOVE_NO).replace(/{user}/g, user);
  await sock.sendMessage(jid, { text: msg });
}

export async function handleIQ(sock: WASocket, jid: string): Promise<void> {
  const iq = Math.floor(Math.random() * 100) + 1;
  let label: string;
  if (iq <= 20) label = "😂 انت غبي شوية";
  else if (iq <= 40) label = "😅 انت احمق بس طيب";
  else if (iq <= 80) label = "😎 انت شاطر";
  else label = "🧠 انت عبقرينو 🔥";

  await sock.sendMessage(jid, {
    text: `🧠 نتيجة اختبار الذكاء:\n\nذكاؤك: ${iq}%\n${label}`,
  });
}
