import type { WASocket } from "@whiskeysockets/baileys";
import { COMMAND_REGISTRY } from "../commands-registry.js";

function buildCommandsText(): string {
  const lines: string[] = ["📜 *قائمة الأوامر الكاملة*\n"];
  for (const cat of COMMAND_REGISTRY) {
    lines.push(`${cat.emoji} *${cat.categoryAr}*`);
    for (const item of cat.items) {
      lines.push(`  ‣ \`${item.cmd}\` — ${item.desc}`);
    }
    lines.push("");
  }
  return lines.join("\n").trim();
}

export async function handleCommands(sock: WASocket, jid: string): Promise<void> {
  await sock.sendMessage(jid, { text: buildCommandsText() });
}
