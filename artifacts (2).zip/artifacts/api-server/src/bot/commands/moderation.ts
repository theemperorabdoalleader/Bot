/**
 * Group Moderation System
 * - Anti-spam: warn users who send too many messages too fast
 * - Bad words filter: detect and warn
 * - Welcome / Goodbye messages
 */
import type { WASocket, GroupParticipant } from "@whiskeysockets/baileys";
import { isGroupAllowed } from "../groups.js";

// ── Bad words list (Arabic + English) ─────────────────────────────────────────
const BAD_WORDS = [
  // Arabic
  "كلب", "خنزير", "حمار", "غبي", "احمق", "لعين", "ملعون", "عاهرة", "شرموط",
  "حقير", "نجس", "وسخ", "زبالة", "منافق",
  // English
  "fuck", "shit", "bitch", "asshole", "idiot", "bastard", "damn", "crap",
];

// ── Anti-spam tracker ──────────────────────────────────────────────────────────
const SPAM_WINDOW_MS = 8_000;   // 8-second window
const SPAM_THRESHOLD = 6;        // 6 messages = spam
const SPAM_MUTE_MS   = 3 * 60_000; // 3 min cooldown after spam warn

interface SpamEntry { timestamps: number[]; mutedUntil: number; warnCount: number; }
const spamTracker = new Map<string, Map<string, SpamEntry>>();

function getSpamEntry(chatJid: string, userJid: string): SpamEntry {
  let chatMap = spamTracker.get(chatJid);
  if (!chatMap) { chatMap = new Map<string, SpamEntry>(); spamTracker.set(chatJid, chatMap); }
  let entry = chatMap.get(userJid);
  if (!entry) { entry = { timestamps: [], mutedUntil: 0, warnCount: 0 }; chatMap.set(userJid, entry); }
  return entry;
}

/**
 * Check if a user is spamming. Returns true if the message should be ignored.
 */
export async function checkSpam(
  sock: WASocket,
  chatJid: string,
  userJid: string,
): Promise<boolean> {
  if (!chatJid.endsWith("@g.us")) return false;
  if (!isGroupAllowed(chatJid)) return false;

  const now = Date.now();
  const entry = getSpamEntry(chatJid, userJid);

  // Check if currently muted
  if (entry.mutedUntil > now) return true;

  // Record this message
  entry.timestamps.push(now);
  // Remove old timestamps outside window
  entry.timestamps = entry.timestamps.filter((t) => now - t < SPAM_WINDOW_MS);

  if (entry.timestamps.length >= SPAM_THRESHOLD) {
    entry.timestamps = [];
    entry.mutedUntil = now + SPAM_MUTE_MS;
    entry.warnCount += 1;
    const userNum = userJid.replace(/[^0-9]/g, "");
    const isRepeat = entry.warnCount > 1;

    await sock.sendMessage(chatJid, {
      text: `🚫 *تحذير مكافحة الإسبام!*\n@${userNum} أرسل رسائل كثيرة جداً!\n⏳ تم تجاهل رسائله لمدة 3 دقائق.\n${isRepeat ? `⚠️ هذا تحذير رقم ${entry.warnCount}!` : "⚠️ المرة القادمة ستكون العقوبة أشد!"}`,
      mentions: [userJid],
    });
    return true;
  }

  return false;
}

/**
 * Check if message contains bad words. Returns true if matched.
 */
export async function checkBadWords(
  sock: WASocket,
  chatJid: string,
  userJid: string,
  text: string,
): Promise<boolean> {
  if (!chatJid.endsWith("@g.us")) return false;
  if (!isGroupAllowed(chatJid)) return false;

  const lower = text.toLowerCase();
  const found = BAD_WORDS.find((w) => lower.includes(w));
  if (!found) return false;

  const userNum = userJid.replace(/[^0-9]/g, "");
  await sock.sendMessage(chatJid, {
    text: `⚠️ *تحذير!*\n@${userNum} يرجى الالتزام بآداب الحوار.\nالكلمات المسيئة ممنوعة في هذه المجموعة! 🚫`,
    mentions: [userJid],
  });
  return true;
}

/**
 * Send a welcome message when a user joins.
 */
export async function sendWelcome(
  sock: WASocket,
  chatJid: string,
  newMemberJids: string[],
): Promise<void> {
  if (!isGroupAllowed(chatJid)) return;
  if (newMemberJids.length === 0) return;

  const mentions = newMemberJids;
  const names = newMemberJids.map((j) => `@${j.replace(/[^0-9]/g, "")}`).join(", ");

  await sock.sendMessage(chatJid, {
    text: `👋 *أهلاً وسهلاً!*\n\nمرحباً ${names} في المجموعة! 🎉\n\n📜 اكتب *.اوامر* لترى قائمة الأوامر المتاحة.\n💰 لديك رصيد ابتدائي: 1,000 عملة. ابدأ رحلتك الآن!`,
    mentions,
  });
}

/**
 * Send a goodbye message when a user leaves.
 */
export async function sendGoodbye(
  sock: WASocket,
  chatJid: string,
  leftMemberJids: string[],
): Promise<void> {
  if (!isGroupAllowed(chatJid)) return;
  if (leftMemberJids.length === 0) return;

  const names = leftMemberJids.map((j) => `@${j.replace(/[^0-9]/g, "")}`).join(", ");

  await sock.sendMessage(chatJid, {
    text: `👋 وداعاً ${names}!\nنتمنى أن نراك مجدداً 🌟`,
  });
}

/**
 * Handle group-participants.update events.
 */
export async function handleParticipantsUpdate(
  sock: WASocket,
  chatJid: string,
  participants: string[],
  action: "add" | "remove" | "promote" | "demote",
): Promise<void> {
  if (action === "add") {
    await sendWelcome(sock, chatJid, participants);
  } else if (action === "remove") {
    await sendGoodbye(sock, chatJid, participants);
  } else if (action === "promote") {
    const mentions = participants;
    const names = participants.map((j) => `@${j.replace(/[^0-9]/g, "")}`).join(", ");
    await sock.sendMessage(chatJid, {
      text: `🎖️ تمت ترقية ${names} إلى مشرف! مبروك! 👑`,
      mentions,
    });
  }
}
