import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";
import { awardXP, awardCoins } from "./level.js";
import { checkCooldown, setCooldown, msToHuman } from "../cooldown.js";

const LUCK_COOLDOWN_MS = 60 * 60 * 1000;
const DAILY_COOLDOWN_MS = 24 * 60 * 60 * 1000;
const BANK_INTEREST_COOLDOWN_MS = 24 * 60 * 60 * 1000;
const BANK_INTEREST_RATE = 0.05;
const BANK_INTEREST_MAX = 100_000;
const LUCK_MIN = 10_000;
const LUCK_MAX = 100_000;
const DAILY_MIN = 8_000;
const DAILY_MAX = 20_000;

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function fmt(n: number): string {
  return n.toLocaleString("ar-EG");
}

function streakBonusMultiplier(streak: number): number {
  if (streak >= 30) return 3.0;
  if (streak >= 14) return 2.5;
  if (streak >= 7)  return 2.0;
  if (streak >= 3)  return 1.5;
  return 1.0;
}

function streakEmoji(streak: number): string {
  if (streak >= 30) return "🔥🔥🔥";
  if (streak >= 14) return "🔥🔥";
  if (streak >= 7)  return "🔥";
  if (streak >= 3)  return "⚡";
  return "✨";
}

export async function handleBalance(sock: WASocket, jid: string): Promise<void> {
  const user = getUser(jid);
  const total = user.wallet + user.bank;
  await sock.sendMessage(jid, {
    text: `💰 *رصيدك*\n\n👜 المحفظة: ${fmt(user.wallet)} عملة\n🏦 البنك: ${fmt(user.bank)} عملة\n💎 الإجمالي: ${fmt(total)} عملة`,
  });
}

export async function handleBank(sock: WASocket, jid: string): Promise<void> {
  const user = getUser(jid);
  const total = user.wallet + user.bank;
  const interestEarnable = Math.floor(user.bank * BANK_INTEREST_RATE);
  const cdResult = checkCooldown(jid, "bank_interest", BANK_INTEREST_COOLDOWN_MS);
  const interestStatus = cdResult.ok
    ? `💡 فائدة متاحة: ${fmt(interestEarnable)} عملة! اكتب .فائدة`
    : `⏳ الفائدة القادمة بعد: ${msToHuman(cdResult.remainingMs)}`;

  await sock.sendMessage(jid, {
    text: `🏦 *حسابك المصرفي*\n\n👜 المحفظة: ${fmt(user.wallet)} عملة\n🏦 البنك: ${fmt(user.bank)} عملة\n💎 الإجمالي: ${fmt(total)} عملة\n\n${interestStatus}`,
  });
}

export async function handleDeposit(sock: WASocket, jid: string, amountStr: string): Promise<void> {
  const amount = parseInt(amountStr);
  if (!amount || amount <= 0) {
    await sock.sendMessage(jid, { text: "❌ حدد مبلغاً صحيحاً. مثال: .ايداع 5000" });
    return;
  }
  const user = getUser(jid);
  if (user.wallet < amount) {
    await sock.sendMessage(jid, { text: `❌ رصيدك غير كافٍ!\n👜 المحفظة: ${fmt(user.wallet)} عملة` });
    return;
  }
  updateUser(jid, { wallet: user.wallet - amount, bank: user.bank + amount });
  await sock.sendMessage(jid, {
    text: `🏦 تم الإيداع!\n\n+${fmt(amount)} عملة في البنك\n👜 المحفظة المتبقية: ${fmt(user.wallet - amount)} عملة`,
  });
}

export async function handleWithdraw(sock: WASocket, jid: string, amountStr: string): Promise<void> {
  const amount = parseInt(amountStr);
  if (!amount || amount <= 0) {
    await sock.sendMessage(jid, { text: "❌ حدد مبلغاً صحيحاً. مثال: .سحب 5000" });
    return;
  }
  const user = getUser(jid);
  if (user.bank < amount) {
    await sock.sendMessage(jid, { text: `❌ رصيد البنك غير كافٍ!\n🏦 البنك: ${fmt(user.bank)} عملة` });
    return;
  }
  updateUser(jid, { bank: user.bank - amount, wallet: user.wallet + amount });
  await sock.sendMessage(jid, {
    text: `💸 تم السحب!\n\n+${fmt(amount)} عملة في المحفظة\n🏦 البنك المتبقي: ${fmt(user.bank - amount)} عملة`,
  });
}

export async function handleBankInterest(sock: WASocket, jid: string): Promise<void> {
  const user = getUser(jid);
  if (user.bank < 1000) {
    await sock.sendMessage(jid, { text: "❌ تحتاج على الأقل 1,000 عملة في البنك لكسب فائدة." });
    return;
  }
  const { ok, remainingMs } = checkCooldown(jid, "bank_interest", BANK_INTEREST_COOLDOWN_MS);
  if (!ok) {
    await sock.sendMessage(jid, { text: `⏳ الفائدة القادمة بعد: ${msToHuman(remainingMs)}` });
    return;
  }
  setCooldown(jid, "bank_interest");
  const interest = Math.min(Math.floor(user.bank * BANK_INTEREST_RATE), BANK_INTEREST_MAX);
  updateUser(jid, { wallet: user.wallet + interest });
  await sock.sendMessage(jid, {
    text: `💹 *فائدة البنك*\n\n🏦 رصيد البنك: ${fmt(user.bank)} عملة\n📈 الفائدة (5%): +${fmt(interest)} عملة\n👜 المحفظة الآن: ${fmt(user.wallet + interest)} عملة`,
  });
}

export async function handleLuck(sock: WASocket, jid: string): Promise<void> {
  const { ok, remainingMs } = checkCooldown(jid, "luck", LUCK_COOLDOWN_MS);
  if (!ok) {
    await sock.sendMessage(jid, { text: `⏳ حظك مش متاح! انتظر ${msToHuman(remainingMs)}.` });
    return;
  }

  setCooldown(jid, "luck");
  const gained = await awardCoins(jid, randomInt(LUCK_MIN, LUCK_MAX));
  await awardXP(jid, 20, sock);

  await sock.sendMessage(jid, {
    text: `🎰 *حظك اليوم!*\n💸 حصلت على ${fmt(gained)} عملة!\n✨ +20 XP`,
  });
}

export async function handleDaily(sock: WASocket, jid: string): Promise<void> {
  const user = getUser(jid);
  const now = Date.now();
  const elapsed = now - (user.lastDaily ?? 0);

  if (elapsed < DAILY_COOLDOWN_MS) {
    const { remainingMs } = checkCooldown(jid, "daily_internal", 0);
    void remainingMs;
    const remaining = DAILY_COOLDOWN_MS - elapsed;
    await sock.sendMessage(jid, {
      text: `⏳ مكافأتك اليومية جاهزة بعد ${msToHuman(remaining)}.`,
    });
    return;
  }

  // ── Streak logic ──────────────────────────────────────────────────────────
  const todayStr = new Date().toISOString().slice(0, 10);
  const yesterdayStr = new Date(Date.now() - 86400_000).toISOString().slice(0, 10);

  let streak = user.dailyStreak ?? 0;
  if (user.lastStreakDate === yesterdayStr) {
    streak += 1;
  } else if (user.lastStreakDate === todayStr) {
    // already claimed today (shouldn't reach here but guard)
  } else {
    streak = 1;
  }

  const mult = streakBonusMultiplier(streak);
  const base = randomInt(DAILY_MIN, DAILY_MAX);
  const bonusCoins = Math.floor(base * mult);

  updateUser(jid, {
    lastDaily: now,
    dailyStreak: streak,
    lastStreakDate: todayStr,
  });

  const gained = await awardCoins(jid, bonusCoins);

  const streakMsg = streak > 1
    ? `\n🔥 *سلسلة متواصلة: ${streak} يوم!* ${streakEmoji(streak)}\n📈 مضاعف: ×${mult.toFixed(1)}`
    : "";

  await sock.sendMessage(jid, {
    text: `🎁 *مكافأتك اليومية!*\n💸 حصلت على ${fmt(gained)} عملة!${streakMsg}\n\nتعال بكرة للمزيد! 🌟`,
  });
}

export async function handleTransfer(
  sock: WASocket,
  chatJid: string,
  senderJid: string,
  args: string,
  mentionedJids: string[],
): Promise<void> {
  const recipientJid = mentionedJids[0];
  if (!recipientJid) {
    await sock.sendMessage(chatJid, { text: "❌ يرجى ذكر المستلم. مثال: .تحويل @user 5000" });
    return;
  }
  if (recipientJid === senderJid) {
    await sock.sendMessage(chatJid, { text: "😂 مش هتقدر تحول لنفسك!" });
    return;
  }

  const amountStr = args.replace(/@\S+/g, "").trim();
  const amount = parseInt(amountStr);
  if (!amount || amount <= 0) {
    await sock.sendMessage(chatJid, { text: "❌ يرجى تحديد مبلغ صحيح." });
    return;
  }

  // Transfer fee: 2% for non-VIP
  const sender = getUser(senderJid);
  const isVip = (sender.vipUntil ?? 0) > Date.now();
  const fee = isVip ? 0 : Math.floor(amount * 0.02);
  const totalNeeded = amount + fee;

  if (sender.wallet < totalNeeded) {
    const feeMsg = fee > 0 ? `\n💡 رسوم التحويل (2%): ${fmt(fee)} عملة` : "";
    await sock.sendMessage(chatJid, {
      text: `❌ رصيدك غير كافٍ!\n💰 محفظتك: ${fmt(sender.wallet)} عملة${feeMsg}`,
    });
    return;
  }

  updateUser(senderJid, { wallet: sender.wallet - totalNeeded });
  const recipient = getUser(recipientJid);
  updateUser(recipientJid, { wallet: recipient.wallet + amount });

  const recipientNum = recipientJid.replace(/[^0-9]/g, "");
  const feeMsg = fee > 0 ? `\n💳 رسوم: ${fmt(fee)} عملة` : " (VIP — بدون رسوم)";
  await sock.sendMessage(chatJid, {
    text: `💸 *تم التحويل!*\n📤 أرسلت ${fmt(amount)} عملة لـ @${recipientNum}${feeMsg}\n💰 رصيدك الآن: ${fmt(sender.wallet - totalNeeded)} عملة`,
    mentions: [recipientJid],
  });
}
