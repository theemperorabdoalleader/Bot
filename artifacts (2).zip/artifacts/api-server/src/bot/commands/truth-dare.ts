import type { WASocket } from "@whiskeysockets/baileys";
import { randomTruth } from "../data/truths.js";
import { randomDare } from "../data/dares.js";

export async function handleTruth(sock: WASocket, jid: string): Promise<void> {
  const question = randomTruth();
  await sock.sendMessage(jid, {
    text: `🤫 صراحة!\n\n❓ ${question}`,
  });
}

export async function handleDare(sock: WASocket, jid: string): Promise<void> {
  const dare = randomDare();
  await sock.sendMessage(jid, {
    text: `😈 جرأة!\n\n🎯 ${dare}`,
  });
}
