import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";
import { awardXP } from "./level.js";
import { setActiveXOGame, clearActiveXOGame, type XOGame } from "../state.js";
import { logger } from "../../lib/logger.js";

const TIMEOUT_MS = 2 * 60_000;
const WIN_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

const NUM_EMOJI = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"];

function renderBoard(board: string[]): string {
  const cells = board.map((v, i) =>
    v === "X" ? "❌" : v === "O" ? "⭕" : NUM_EMOJI[i]!,
  );
  return [
    `${cells[0]} ${cells[1]} ${cells[2]}`,
    `${cells[3]} ${cells[4]} ${cells[5]}`,
    `${cells[6]} ${cells[7]} ${cells[8]}`,
  ].join("\n");
}

function checkWin(board: string[], mark: string): boolean {
  return WIN_LINES.some((line) => line.every((i) => board[i] === mark));
}

function checkDraw(board: string[]): boolean {
  return board.every((c) => c !== "");
}

export async function startXOGame(
  sock: WASocket,
  chatJid: string,
  xPlayerJid: string,
  oPlayerJid: string,
  amount: number,
): Promise<void> {
  const board = Array(9).fill("") as string[];
  const xNum = xPlayerJid.replace(/[^0-9]/g, "");
  const oNum = oPlayerJid.replace(/[^0-9]/g, "");

  const timeout = setTimeout(async () => {
    clearActiveXOGame(chatJid);
    try {
      await sock.sendMessage(chatJid, {
        text: "⏰ انتهى وقت اللعبة! تعادل — تم إرجاع الرهان.",
      });
      updateUser(xPlayerJid, { wallet: getUser(xPlayerJid).wallet + amount / 2 });
      updateUser(oPlayerJid, { wallet: getUser(oPlayerJid).wallet + amount / 2 });
    } catch {}
  }, TIMEOUT_MS);

  setActiveXOGame(chatJid, {
    board,
    xPlayerJid,
    oPlayerJid,
    currentTurn: "X",
    amount,
    timeout,
  });

  await sock.sendMessage(chatJid, {
    text: `🎮 لعبة XO بدأت!\n\n${renderBoard(board)}\n\n❌ @${xNum} — دورك! أرسل رقماً من 1 إلى 9`,
    mentions: [xPlayerJid],
  });
}

export async function handleXOMove(
  sock: WASocket,
  chatJid: string,
  moverJid: string,
  input: string,
  game: XOGame,
): Promise<void> {
  const pos = parseInt(input.trim()) - 1;
  if (isNaN(pos) || pos < 0 || pos > 8) return;

  const isXTurn = game.currentTurn === "X";
  const isXPlayer = moverJid === game.xPlayerJid;
  const isOPlayer = moverJid === game.oPlayerJid;
  if (isXTurn && !isXPlayer) return;
  if (!isXTurn && !isOPlayer) return;

  if (game.board[pos] !== "") {
    await sock.sendMessage(chatJid, { text: "❌ هذه الخانة محجوزة! اختر خانة أخرى." });
    return;
  }

  const mark = game.currentTurn;
  game.board[pos] = mark;

  if (checkWin(game.board, mark)) {
    clearActiveXOGame(chatJid);
    const winnerJid = mark === "X" ? game.xPlayerJid : game.oPlayerJid;
    const loserJid = mark === "X" ? game.oPlayerJid : game.xPlayerJid;
    const winnerNum = winnerJid.replace(/[^0-9]/g, "");

    updateUser(winnerJid, { wallet: getUser(winnerJid).wallet + game.amount });
    await awardXP(winnerJid, 50, sock);

    await sock.sendMessage(chatJid, {
      text: `${renderBoard(game.board)}\n\n🏆 فاز @${winnerNum}!\n💰 حصل على ${game.amount.toLocaleString("ar-EG")} عملة!\n✨ +50 XP`,
      mentions: [winnerJid],
    });
    void loserJid;
    return;
  }

  if (checkDraw(game.board)) {
    clearActiveXOGame(chatJid);
    updateUser(game.xPlayerJid, { wallet: getUser(game.xPlayerJid).wallet + game.amount / 2 });
    updateUser(game.oPlayerJid, { wallet: getUser(game.oPlayerJid).wallet + game.amount / 2 });
    await sock.sendMessage(chatJid, {
      text: `${renderBoard(game.board)}\n\n🤝 تعادل! تم إرجاع الرهان لكلاكما.`,
    });
    return;
  }

  game.currentTurn = mark === "X" ? "O" : "X";
  const nextJid = game.currentTurn === "X" ? game.xPlayerJid : game.oPlayerJid;
  const nextNum = nextJid.replace(/[^0-9]/g, "");
  const nextSymbol = game.currentTurn === "X" ? "❌" : "⭕";

  await sock.sendMessage(chatJid, {
    text: `${renderBoard(game.board)}\n\n${nextSymbol} @${nextNum} — دورك! أرسل رقماً من 1 إلى 9`,
    mentions: [nextJid],
  });

  logger.debug({ chatJid, moverJid, pos, mark }, "XO move");
}
