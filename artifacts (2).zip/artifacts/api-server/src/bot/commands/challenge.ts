import type { WASocket } from "@whiskeysockets/baileys";
import { getUser, updateUser } from "../db.js";
import { awardXP } from "./level.js";
import { startXOGame } from "./xo.js";
import { randomRiddle } from "../data/riddles.js";
import { randomCharacter } from "../data/anime-eyes.js";
import { randomPlayer } from "../data/football-players.js";
import {
  setPendingChallenge,
  getPendingChallenge,
  clearPendingChallenge,
  setActiveChallengeGame,
  getActiveChallengeGame,
  clearActiveChallengeGame,
  type ActiveChallengeGame,
} from "../state.js";
import { logger } from "../../lib/logger.js";

const ACCEPT_TIMEOUT_MS = 60_000;
const GAME_TIMEOUT_MS = 2 * 60_000;
const VALID_GAMES = ["لغز", "عين", "لاعب", "xo"];

function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/[أإآا]/g, "ا")
    .replace(/[ةه]/g, "ه")
    .replace(/ى/g, "ي")
    .trim();
}

function isCorrect(input: string, answer: string, alts: string[]): boolean {
  const norm = normalize(input);
  return [answer, ...alts]
    .map(normalize)
    .some((t) => norm === t || norm.includes(t) || t.includes(norm));
}

async function fetchAniListImage(id: number): Promise<Buffer> {
  const res = await fetch("https://graphql.anilist.co", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      query: `query { Character(id: ${id}) { image { large } } }`,
    }),
  });
  const data = (await res.json()) as {
    data: { Character: { image: { large: string } } };
  };
  const imgRes = await fetch(data.data.Character.image.large, {
    headers: { "User-Agent": "Mozilla/5.0" },
  });
  return Buffer.from(await imgRes.arrayBuffer());
}

async function fetchPlayerImage(searchName: string): Promise<Buffer | null> {
  const res = await fetch(
    `https://www.thesportsdb.com/api/v1/json/3/searchplayers.php?p=${encodeURIComponent(searchName)}`,
    { headers: { "User-Agent": "Mozilla/5.0" } },
  );
  const data = (await res.json()) as {
    player?: Array<{ strThumb?: string }>;
  };
  const url = data.player?.[0]?.strThumb;
  if (!url) return null;
  const imgRes = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
  return Buffer.from(await imgRes.arrayBuffer());
}

async function startChallengeGame(
  sock: WASocket,
  chatJid: string,
  challengerJid: string,
  challengedJid: string,
  amount: number,
  gameType: string,
): Promise<void> {
  // XO is handled separately
  if (gameType === "xo") {
    await startXOGame(sock, chatJid, challengerJid, challengedJid, amount);
    return;
  }

  let answer = "";
  let altAnswers: string[] = [];
  let displayAnswer = "";

  try {
    if (gameType === "لغز") {
      const riddle = randomRiddle();
      answer = riddle.answer;
      displayAnswer = riddle.answer;
      await sock.sendMessage(chatJid, {
        text: `⚔️ التحدي بدأ!\n🧩 ${riddle.question}\n\n💡 أول إجابة صحيحة يفوز بـ ${amount.toLocaleString("ar-EG")} عملة!`,
      });
    } else if (gameType === "عين") {
      const char = randomCharacter();
      answer = char.nameAr;
      altAnswers = [char.nameEn];
      displayAnswer = `${char.nameAr} (${char.series})`;
      const buffer = await fetchAniListImage(char.anilistId);
      await sock.sendMessage(chatJid, {
        image: buffer,
        caption: `⚔️ التحدي بدأ!\n🎌 من هذه الشخصية؟\n\n💡 أول إجابة صحيحة يفوز بـ ${amount.toLocaleString("ar-EG")} عملة!`,
      });
    } else if (gameType === "لاعب") {
      const player = randomPlayer();
      answer = player.nameAr;
      altAnswers = [player.nameEn, player.searchName.toLowerCase()];
      displayAnswer = `${player.nameAr} — ${player.searchName}`;
      const buffer = await fetchPlayerImage(player.searchName);
      if (!buffer) throw new Error("player image failed");
      await sock.sendMessage(chatJid, {
        image: buffer,
        caption: `⚔️ التحدي بدأ!\n⚽ من هذا اللاعب؟\n\n💡 أول إجابة صحيحة يفوز بـ ${amount.toLocaleString("ar-EG")} عملة!`,
      });
    } else {
      await sock.sendMessage(chatJid, { text: `❌ نوع اللعبة غير صحيح. اختر: ${VALID_GAMES.join(" / ")}` });
      return;
    }
  } catch (err) {
    logger.error({ err }, "Challenge game start failed");
    await sock.sendMessage(chatJid, { text: "❌ فشل في بدء اللعبة. حاول مرة أخرى." });
    return;
  }

  const timeout = setTimeout(async () => {
    clearActiveChallengeGame(chatJid);
    try {
      await sock.sendMessage(chatJid, {
        text: `⏰ انتهى وقت التحدي!\nالإجابة الصحيحة: *${displayAnswer}*\n💔 تعادل — تم إرجاع الرهان.`,
      });
      updateUser(challengerJid, { wallet: getUser(challengerJid).wallet + amount / 2 });
      updateUser(challengedJid, { wallet: getUser(challengedJid).wallet + amount / 2 });
    } catch {}
  }, GAME_TIMEOUT_MS);

  setActiveChallengeGame(chatJid, {
    challengerJid,
    challengedJid,
    amount,
    gameAnswer: answer,
    gameAltAnswers: altAnswers,
    gameDisplayAnswer: displayAnswer,
    timeout,
  });
}

export async function handleChallenge(
  sock: WASocket,
  chatJid: string,
  challengerJid: string,
  args: string,
  mentionedJids: string[],
): Promise<void> {
  const challengedJid = mentionedJids[0];
  if (!challengedJid) {
    await sock.sendMessage(chatJid, {
      text: `❌ يرجى ذكر المتحدي. مثال: .تحدي @user 50000 لغز`,
    });
    return;
  }
  if (challengedJid === challengerJid) {
    await sock.sendMessage(chatJid, { text: "❌ لا يمكنك تحدي نفسك!" });
    return;
  }

  const clean = args.replace(/@\S+/g, "").trim().split(/\s+/);
  const amount = parseInt(clean[0] ?? "0");
  const gameType = clean[1] ?? "";

  if (!amount || amount <= 0) {
    await sock.sendMessage(chatJid, { text: "❌ يرجى تحديد مبلغ صحيح. مثال: .تحدي @user 50000 لغز" });
    return;
  }
  if (!VALID_GAMES.includes(gameType)) {
    await sock.sendMessage(chatJid, { text: `❌ نوع اللعبة غير صحيح. اختر: ${VALID_GAMES.join(" / ")}` });
    return;
  }

  const challenger = getUser(challengerJid);
  if (challenger.wallet < amount) {
    await sock.sendMessage(chatJid, {
      text: `❌ رصيدك غير كافٍ!\n💰 محفظتك: ${challenger.wallet.toLocaleString("ar-EG")} عملة`,
    });
    return;
  }

  const challengedNum = challengedJid.replace(/[^0-9]/g, "");
  const timeout = setTimeout(async () => {
    clearPendingChallenge(chatJid);
    try {
      await sock.sendMessage(chatJid, { text: "⏰ انتهى وقت قبول التحدي. تم الإلغاء." });
    } catch {}
  }, ACCEPT_TIMEOUT_MS);

  setPendingChallenge(chatJid, {
    challengerJid,
    challengedJid,
    amount,
    gameType,
    timeout,
  });

  await sock.sendMessage(chatJid, {
    text: `⚔️ تحدي!\n👤 @${challengedNum} لديك دقيقة للرد بـ .قبول\n🎮 اللعبة: ${gameType}\n💰 الرهان: ${amount.toLocaleString("ar-EG")} عملة`,
    mentions: [challengedJid],
  });
}

export async function handleAccept(
  sock: WASocket,
  chatJid: string,
  acceptorJid: string,
): Promise<void> {
  const pending = getPendingChallenge(chatJid);
  if (!pending) {
    await sock.sendMessage(chatJid, { text: "❌ لا يوجد تحدي معلق حالياً." });
    return;
  }
  if (pending.challengedJid !== acceptorJid) {
    await sock.sendMessage(chatJid, { text: "❌ هذا التحدي ليس موجهاً لك." });
    return;
  }

  clearPendingChallenge(chatJid);

  const challenged = getUser(acceptorJid);
  if (challenged.wallet < pending.amount) {
    await sock.sendMessage(chatJid, {
      text: `❌ رصيدك غير كافٍ لقبول التحدي!\n💰 محفظتك: ${challenged.wallet.toLocaleString("ar-EG")} عملة`,
    });
    return;
  }

  updateUser(pending.challengerJid, {
    wallet: getUser(pending.challengerJid).wallet - pending.amount,
  });
  updateUser(acceptorJid, { wallet: challenged.wallet - pending.amount });

  await sock.sendMessage(chatJid, { text: "✅ تم قبول التحدي! جارٍ تحضير اللعبة..." });
  await startChallengeGame(
    sock, chatJid,
    pending.challengerJid, acceptorJid,
    pending.amount * 2, pending.gameType,
  );
}

export async function handleChallengeAnswer(
  sock: WASocket,
  chatJid: string,
  answererJid: string,
  input: string,
  game: ActiveChallengeGame,
): Promise<void> {
  if (!isCorrect(input, game.gameAnswer, game.gameAltAnswers)) return;

  clearActiveChallengeGame(chatJid);
  const winnerNum = answererJid.replace(/[^0-9]/g, "");

  updateUser(answererJid, { wallet: getUser(answererJid).wallet + game.amount });
  await awardXP(answererJid, 50, sock);

  await sock.sendMessage(chatJid, {
    text: `✅ إجابة صحيحة! *${game.gameDisplayAnswer}*\n\n🏆 الفائز: @${winnerNum}\n💰 حصل على ${game.amount.toLocaleString("ar-EG")} عملة!\n✨ +50 XP`,
    mentions: [answererJid],
  });
}

// Re-export for use in index.ts
export { getActiveChallengeGame };
