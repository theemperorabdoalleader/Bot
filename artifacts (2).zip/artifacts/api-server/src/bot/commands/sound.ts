import type { WASocket } from "@whiskeysockets/baileys";
import ytdl from "@distube/ytdl-core";
import ytSearch from "yt-search";
import type { Readable } from "stream";
import { logger } from "../../lib/logger.js";

async function streamToBuffer(stream: Readable): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    stream.on("data", (chunk: Buffer) => chunks.push(Buffer.from(chunk)));
    stream.on("end", () => resolve(Buffer.concat(chunks)));
    stream.on("error", reject);
  });
}

export async function handleSound(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  if (!args.trim()) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى إدخال كلمة بحث. مثال: .صوت faded alan walker",
    });
    return;
  }

  await sock.sendMessage(jid, { text: `🎵 جارٍ البحث عن "${args.trim()}"...` });

  let candidates: ytSearch.VideoSearchResult[];
  try {
    const res = await ytSearch(args.trim());
    candidates = res.videos.slice(0, 5);
  } catch (err) {
    logger.error({ err }, "YouTube audio search failed");
    await sock.sendMessage(jid, {
      text: "❌ حدث خطأ أثناء البحث. يرجى المحاولة لاحقاً.",
    });
    return;
  }

  if (candidates.length === 0) {
    await sock.sendMessage(jid, {
      text: `❌ لم يتم العثور على نتائج لـ "${args.trim()}".`,
    });
    return;
  }

  for (const video of candidates) {
    try {
      const stream = ytdl(video.url, {
        quality: "highestaudio",
        filter: "audioonly",
      });
      const buffer = await streamToBuffer(stream as unknown as Readable);
      await sock.sendMessage(jid, {
        audio: buffer,
        mimetype: "audio/mp4",
        ptt: false,
      });
      return;
    } catch (err) {
      logger.warn({ err, url: video.url }, "Audio download failed, trying next");
    }
  }

  await sock.sendMessage(jid, {
    text: "❌ فشل في تحميل الصوت. يرجى المحاولة لاحقاً.",
  });
}
