import type { WASocket } from "@whiskeysockets/baileys";
import { translateText } from "../services/ai.js";
import { logger } from "../../lib/logger.js";

export async function handleTranslate(
  sock: WASocket,
  jid: string,
  args: string,
): Promise<void> {
  if (!args.trim()) {
    await sock.sendMessage(jid, {
      text: "❌ يرجى إدخال نص للترجمة.\nمثال: .ترجم مرحبا بالعالم",
    });
    return;
  }

  try {
    const translated = await translateText(args.trim());
    await sock.sendMessage(jid, { text: `🌐 *الترجمة:*\n${translated}` });
  } catch (err) {
    logger.error({ err }, "Translation failed");
    await sock.sendMessage(jid, {
      text: "❌ فشل في الترجمة. يرجى المحاولة مرة أخرى.",
    });
  }
}
