process.on("uncaughtException", (err) => {
  console.error("UNCAUGHT:", err);
});

process.on("unhandledRejection", (err) => {
  console.error("UNHANDLED:", err);
});
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  type WAMessage,
  type WASocket,
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import { join } from "path";
import pino from "pino";
import {
  setQR, clearQR, setConnected, setSocket, getSocket, trackChat, trackCommandUser,
  getActiveGame, clearActiveGame,
  getPendingChallenge,
  getActiveChallengeGame,
  getActiveXOGame,
  getActiveBoss,
  toggleAutoAiMode,
  addActivityLog,
} from "./state.js";
import { initDb, getUser } from "./db.js";
import { initGangs } from "./commands/gang.js";
import { initGroups, isGroupAllowed, activateGroup, deactivateGroup } from "./groups.js";
import { initGroupState, isUserMuted, getGroupMode } from "./group-state.js";
import { startEventScheduler, handleEventAnswer } from "./commands/events.js";

// ── Media / utility commands ──────────────────────────────────────────────────
import { handleImages } from "./commands/images.js";
import { handleTranslate } from "./commands/translate.js";
import { handleSummarize } from "./commands/summarize.js";
import { handleReminder, handleListReminders } from "./commands/reminder.js";
import { handleYoutube } from "./commands/youtube.js";
import { handleTiktok } from "./commands/tiktok.js";
import { handleSound } from "./commands/sound.js";
import { handleTrending } from "./commands/trending.js";
import { handleAnime } from "./commands/anime.js";
import { handleMeme } from "./commands/meme.js";

// ── Games ─────────────────────────────────────────────────────────────────────
import { handleEyeGame, handlePlayerGame, handleRiddleGame, handleGameAnswer } from "./commands/games.js";

// ── Economy ───────────────────────────────────────────────────────────────────
import {
  handleBalance, handleBank, handleLuck, handleDaily, handleTransfer,
  handleDeposit, handleWithdraw, handleBankInterest,
} from "./commands/economy.js";

// ── Level + shop + leaderboard ────────────────────────────────────────────────
import { handleLevel, awardXP } from "./commands/level.js";
import { handleShop, handleBuy } from "./commands/shop.js";
import { handleRichLeaderboard, handleXPLeaderboard } from "./commands/leaderboard.js";

// ── Challenge + XO ────────────────────────────────────────────────────────────
import { handleChallenge, handleAccept, handleChallengeAnswer } from "./commands/challenge.js";
import { handleXOMove, startXOGame } from "./commands/xo.js";

// ── PvP duel ──────────────────────────────────────────────────────────────────
import { handlePvpChallenge, handlePvpAccept, getPendingPvpDuel } from "./commands/pvp.js";

// ── Fun ───────────────────────────────────────────────────────────────────────
import { handleMarriage, handleHate, handleLove, handleIQ } from "./commands/fun.js";
import { handleTruth, handleDare } from "./commands/truth-dare.js";

// ── Phase 2 systems ───────────────────────────────────────────────────────────
import { handleSteal, handleEscape, isJailed } from "./commands/steal.js";
import { handleGamble, handleLootbox } from "./commands/gambling.js";
import { handleCreateGang, handleJoinGang, handleMyGang, handleGangWar } from "./commands/gang.js";
import { handleMissions, completeMission } from "./commands/missions.js";
import { handleAchievements, checkAchievements } from "./commands/achievements.js";
import { handleVIP, handleBuyVIP, handleUpgrade } from "./commands/vip.js";
import { handleAsk, handleClearContext } from "./commands/ask.js";
import { handleHistory } from "./commands/history.js";
import { handleSpawnBoss, handleBossAttack } from "./commands/boss.js";

// ── Group management ──────────────────────────────────────────────────────────
import { checkSpam, checkBadWords, handleParticipantsUpdate } from "./commands/moderation.js";
import {
  handleModeAdmins, handleModeMembers,
  handleMute, handleUnmute, handleDelete,
} from "./commands/group-admin.js";

// ── Commands list ─────────────────────────────────────────────────────────────
import { handleCommands } from "./commands/allcommands.js";

import { logger } from "../lib/logger.js";

const OWNER_NUMBER = "201149182286";
// FIX: Use correct, consistent session directory name
const SESSION_DIR = join(process.cwd(), "sessions");
const silentLogger = pino({ level: "silent" });

// FIX: Reconnect guard — prevents multiple concurrent startBot() instances
let _isConnecting = false;
// FIX: Event-scheduler guard — startEventScheduler must only fire once per process
let _eventSchedulerStarted = false;
// QR auto-refresh: if QR not scanned within QR_TTL_MS, restart connection to get a fresh code
const QR_TTL_MS = 120_000; // 2 minutes
let _qrRefreshTimer: ReturnType<typeof setTimeout> | null = null;

// ── Message helpers ───────────────────────────────────────────────────────────

function getMessageText(msg: WAMessage): string | null {
  return (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    null
  );
}

function getMentions(msg: WAMessage): string[] {
  return msg.message?.extendedTextMessage?.contextInfo?.mentionedJid ?? [];
}

function mentionDisplay(jids: string[], index = 0): string {
  const jid = jids[index];
  if (!jid) return "@مجهول";
  return `@${jid.replace(/[^0-9]/g, "")}`;
}

/** Fetch the list of admin JIDs for a group (returns [] on any error). */
async function fetchGroupAdmins(sock: WASocket, groupJid: string): Promise<string[]> {
  try {
    const meta = await sock.groupMetadata(groupJid);
    return meta.participants
      .filter((p) => p.admin === "admin" || p.admin === "superadmin")
      .map((p) => p.id);
  } catch {
    return [];
  }
}

// ── Main message handler ──────────────────────────────────────────────────────

async function handleMessage(sock: WASocket, msg: WAMessage): Promise<void> {
  const jid = msg.key.remoteJid;
  if (!jid) return;

  const isGroup = jid.endsWith("@g.us");
  if (isGroup) trackChat(jid);

  const sender   = msg.key.participant ?? jid;
  const isOwner  = sender.replace(/[^0-9]/g, "") === OWNER_NUMBER;

  // ── Group activation check ──────────────────────────────────────────────
  if (isGroup && !isOwner && !isGroupAllowed(jid)) return;

  // ── Muted user auto-delete (all message types) ──────────────────────────
  if (isGroup && !isOwner && isUserMuted(jid, sender)) {
    try { await sock.sendMessage(jid, { delete: msg.key }); } catch {}
    return;
  }

  // ── Text extraction (required for command dispatch) ─────────────────────
  const text = getMessageText(msg);
  if (!text) return;
  const trimmed = text.trim();

  // ── Anti-spam (groups, non-owner) ───────────────────────────────────────
  if (isGroup && !isOwner) {
    const isSpam = await checkSpam(sock, jid, sender);
    if (isSpam) return;
  }

  // ── Bad-words filter (groups, non-command messages) ─────────────────────
  if (isGroup && !trimmed.startsWith(".")) {
    await checkBadWords(sock, jid, sender, trimmed);
  }

  // ── Group admin detection ───────────────────────────────────────────────
  let groupAdminJids: string[] = [];
  if (isGroup) groupAdminJids = await fetchGroupAdmins(sock, jid);
  const isGroupAdmin = isGroup && groupAdminJids.includes(sender);

  // ── Determine if sender can run regular bot commands ─────────────────────
  //   • Owner: always
  //   • Group admin: always (regardless of mode)
  //   • Regular group member: only when group mode = "members"
  //   • DM: always (not a group)
  const canRunCommands =
    isOwner ||
    !isGroup ||
    isGroupAdmin ||
    (isGroupAllowed(jid) && getGroupMode(jid) === "members");

  const mentions = getMentions(msg);

  // ── Active-state participation (all users, regardless of permissions) ────

  // Random event answer
  const gotEvent = await handleEventAnswer(sock, jid, sender, trimmed);
  if (gotEvent) return;

  // Boss attack
  if (trimmed === ".هجوم" && getActiveBoss(jid)) {
    await handleBossAttack(sock, jid, sender);
    return;
  }

  // PvP accept
  if (trimmed === ".قبول_دوري") {
    const duel = getPendingPvpDuel(jid);
    if (duel && duel.challengerJid !== sender) {
      await handlePvpAccept(sock, jid, sender);
    }
    return;
  }

  // Challenge accept
  if (trimmed === ".قبول") {
    const pending = getPendingChallenge(jid);
    if (pending?.challengedJid === sender) await handleAccept(sock, jid, sender);
    return;
  }

  // Challenge game answer (non-command text)
  const cGame = getActiveChallengeGame(jid);
  if (cGame && (cGame.challengerJid === sender || cGame.challengedJid === sender) && !trimmed.startsWith(".")) {
    await handleChallengeAnswer(sock, jid, sender, trimmed, cGame);
    return;
  }

  // XO move
  const xoGame = getActiveXOGame(jid);
  if (xoGame && (xoGame.xPlayerJid === sender || xoGame.oPlayerJid === sender) && /^[1-9]$/.test(trimmed)) {
    await handleXOMove(sock, jid, sender, trimmed, xoGame);
    return;
  }

  // ── Moderation commands (group admins + owner) ──────────────────────────
  if (isGroup && (isGroupAdmin || isOwner)) {
    if (trimmed === ".مود مشرفين") {
      await handleModeAdmins(sock, jid, sender);
      return;
    }
    if (trimmed === ".مود اعضاء") {
      await handleModeMembers(sock, jid, sender);
      return;
    }
    if (trimmed === ".كتم") {
      await handleMute(sock, jid, msg, mentions, sender);
      return;
    }
    if (trimmed === ".الغاء كتم") {
      await handleUnmute(sock, jid, msg, mentions, sender);
      return;
    }
    if (trimmed === ".حذف") {
      await handleDelete(sock, jid, msg, sender);
      return;
    }
  }

  // ── Block if can't run regular commands ─────────────────────────────────
  if (!canRunCommands) return;

  // ── Jail check (owner only — regular users can't be jailed currently) ───
  if (isOwner) {
    const { jailed, remainingMs } = isJailed(sender);
    if (jailed) {
      if (trimmed === ".خروج") {
        await handleEscape(sock, jid, sender);
      } else {
        const mins = Math.ceil(remainingMs / 60_000);
        await sock.sendMessage(jid, {
          text: `⛓️ أنت في السجن! ${mins} دقيقة متبقية. اكتب .خروج عند انتهاء الوقت.`,
        });
      }
      return;
    }
  }

  // ── Active solo game answer ─────────────────────────────────────────────
  const activeGame = getActiveGame(jid);
  if (activeGame) {
    if (!trimmed.startsWith(".")) {
      await handleGameAnswer(sock, jid, trimmed, activeGame);
      return;
    }
    clearActiveGame(jid);
  }

  // ── +5 XP per command (only for actual bot commands, not every message) ──
  if (trimmed.startsWith(".")) {
    trackCommandUser(sender);
    try {
  await awardXP(sender, 5, sock);
  await checkAchievements(sender, sock);
} catch (e) {
  console.log("XP error:", e);
}

  // ── Command dispatch ────────────────────────────────────────────────────

  // Media
  if (trimmed.startsWith(".صور")) {
    await handleImages(sock, jid, trimmed.slice(".صور".length).trim());

  } else if (trimmed.startsWith(".ترجم")) {
    await handleTranslate(sock, jid, trimmed.slice(".ترجم".length).trim());

  } else if (trimmed.startsWith(".ملخص")) {
    await handleSummarize(sock, jid, trimmed.slice(".ملخص".length).trim());

  } else if (trimmed.startsWith(".تذكير")) {
    await handleReminder(sock, jid, trimmed.slice(".تذكير".length).trim());

  } else if (trimmed === ".تذكيراتي") {
    await handleListReminders(sock, jid);

  } else if (trimmed.startsWith(".يوتيوب")) {
    await handleYoutube(sock, jid, trimmed.slice(".يوتيوب".length).trim());

  } else if (trimmed.startsWith(".اديت")) {
    await handleTiktok(sock, jid, trimmed.slice(".اديت".length).trim());

  } else if (trimmed.startsWith(".صوت")) {
    await handleSound(sock, jid, trimmed.slice(".صوت".length).trim());

  } else if (trimmed === ".ترند") {
    await handleTrending(sock, jid);

  } else if (trimmed.startsWith(".انمي")) {
    await handleAnime(sock, jid, trimmed.slice(".انمي".length).trim());

  } else if (trimmed === ".ميم") {
    await handleMeme(sock, jid);

  // Games
  } else if (trimmed === ".عين") {
    await handleEyeGame(sock, jid);

  } else if (trimmed === ".لاعب") {
    await handlePlayerGame(sock, jid);

  } else if (trimmed === ".لغز") {
    await handleRiddleGame(sock, jid);
    await completeMission(jid, "answer_riddle", sock);

  } else if (trimmed.startsWith(".xo")) {
    const xoArgs    = trimmed.slice(".xo".length).trim();
    const xoAmount  = parseInt(xoArgs.replace(/@\S+/g, "").trim()) || 0;
    const xoOpponent = mentions[0];
    if (!xoOpponent) {
      await sock.sendMessage(jid, { text: "❌ ذكِّر خصمك. مثال: .xo @user 50000" });
    } else if (xoAmount <= 0) {
      await sock.sendMessage(jid, { text: "❌ حدد مبلغ صحيح. مثال: .xo @user 50000" });
    } else {
      await startXOGame(sock, jid, sender, xoOpponent, xoAmount);
    }

  // Boss
  } else if (trimmed === ".زعيم") {
    await handleSpawnBoss(sock, jid);

  // PvP duel
  } else if (trimmed.startsWith(".دوري")) {
    await handlePvpChallenge(sock, jid, sender, trimmed.slice(".دوري".length).trim(), mentions);

  } else if (trimmed === ".قبول_دوري") {
    await handlePvpAccept(sock, jid, sender);

  // Economy
  } else if (trimmed === ".رصيدي") {
    await handleBalance(sock, jid);

  } else if (trimmed === ".بنك") {
    await handleBank(sock, jid);

  } else if (trimmed.startsWith(".ايداع")) {
    await handleDeposit(sock, jid, trimmed.slice(".ايداع".length).trim());

  } else if (trimmed.startsWith(".سحب")) {
    await handleWithdraw(sock, jid, trimmed.slice(".سحب".length).trim());

  } else if (trimmed === ".فائدة") {
    await handleBankInterest(sock, jid);

  } else if (trimmed === ".حظ") {
    await handleLuck(sock, jid);
    await completeMission(jid, "use_luck", sock);

  } else if (trimmed === ".يومي") {
    await handleDaily(sock, jid);
    await completeMission(jid, "use_daily", sock);

  } else if (trimmed.startsWith(".تحويل")) {
    await handleTransfer(sock, jid, sender, trimmed.slice(".تحويل".length).trim(), mentions);
    await completeMission(jid, "transfer_coins", sock);

  // Steal
  } else if (trimmed.startsWith(".سرقة")) {
    await handleSteal(sock, jid, sender, mentions);
    await completeMission(jid, "steal_once", sock);

  } else if (trimmed === ".خروج") {
    await handleEscape(sock, jid, sender);

  // Gambling
  } else if (trimmed.startsWith(".قمار")) {
    await handleGamble(sock, jid, sender, trimmed.slice(".قمار".length).trim());
    await completeMission(jid, "gamble_once", sock);

  } else if (trimmed === ".صندوق") {
    await handleLootbox(sock, jid, sender);
    await completeMission(jid, "open_lootbox", sock);

  // Level + shop + leaderboard
  } else if (trimmed === ".لفلي") {
    await handleLevel(sock, jid);

  } else if (trimmed === ".متجر") {
    await handleShop(sock, jid);

  } else if (trimmed.startsWith(".شراء_vip")) {
    await handleBuyVIP(sock, jid, sender);

  } else if (trimmed.startsWith(".شراء")) {
    await handleBuy(sock, jid, trimmed.slice(".شراء".length).trim());

  } else if (trimmed === ".الاباطرة") {
    await handleRichLeaderboard(sock, jid);

  } else if (trimmed === ".الجيش") {
    await handleXPLeaderboard(sock, jid);

  // VIP + Upgrade
  } else if (trimmed === ".vip") {
    await handleVIP(sock, jid, sender);

  } else if (trimmed.startsWith(".تطوير")) {
    await handleUpgrade(sock, jid, sender, trimmed.slice(".تطوير".length).trim());

  // Gangs
  } else if (trimmed.startsWith(".انشاء_عصابة")) {
    await handleCreateGang(sock, jid, sender, trimmed.slice(".انشاء_عصابة".length).trim());

  } else if (trimmed.startsWith(".انضمام")) {
    await handleJoinGang(sock, jid, sender, trimmed.slice(".انضمام".length).trim());

  } else if (trimmed === ".عصابتي") {
    await handleMyGang(sock, jid, sender);

  } else if (trimmed.startsWith(".حرب")) {
    await handleGangWar(sock, jid, sender, trimmed.slice(".حرب".length).trim());

  // Missions + Achievements
  } else if (trimmed === ".مهامي") {
    await handleMissions(sock, jid, sender);

  } else if (trimmed === ".انجازاتي") {
    await handleAchievements(sock, jid, sender);

  // Challenge system
  } else if (trimmed.startsWith(".تحدي")) {
    await handleChallenge(sock, jid, sender, trimmed.slice(".تحدي".length).trim(), mentions);

  } else if (trimmed === ".قبول") {
    await handleAccept(sock, jid, sender);

  // Fun
  } else if (trimmed === ".صراحة") {
    await handleTruth(sock, jid);

  } else if (trimmed === ".جرأة") {
    await handleDare(sock, jid);

  } else if (trimmed.startsWith(".زواج")) {
    await handleMarriage(sock, jid, mentionDisplay(mentions, 0), mentionDisplay(mentions, 1));

  } else if (trimmed.startsWith(".يكرهني")) {
    await handleHate(sock, jid, mentionDisplay(mentions, 0));

  } else if (trimmed.startsWith(".يحبك")) {
    await handleLove(sock, jid, mentionDisplay(mentions, 0));

  } else if (trimmed === ".ذكاء") {
    await handleIQ(sock, jid);

  // AI
  } else if (trimmed.startsWith(".اسأل")) {
    await handleAsk(sock, jid, trimmed.slice(".اسأل".length).trim(), sender);

  } else if (trimmed === ".مسح_ذاكرة") {
    await handleClearContext(sock, jid, sender);

  } else if (trimmed === ".ذكاء_تلقائي") {
    const isOn = toggleAutoAiMode(jid);
    await sock.sendMessage(jid, {
      text: isOn
        ? "🤖 تم تفعيل وضع الرد التلقائي بالـ AI! سيرد البوت على جميع الرسائل.\nاكتب .ذكاء_تلقائي مرة أخرى لإيقافه."
        : "🔕 تم إيقاف وضع الرد التلقائي بالـ AI.",
    });

  // History
  } else if (trimmed === ".سجل") {
    await handleHistory(sock, jid, sender);

  // Group activation (owner only)
  } else if (trimmed === ".تفعيل") {
    if (!isOwner) return;
    if (!isGroup) {
      await sock.sendMessage(jid, { text: "❌ هذا الأمر يعمل في الجروبات فقط." });
    } else {
      activateGroup(jid);
      await sock.sendMessage(jid, {
        text: "✅ تم تفعيل البوت في هذا الجروب\n🛡️ الحماية من الإسبام والكلمات المسيئة نشطة\n\n💡 نصائح:\n• *.مود مشرفين* — قصر الأوامر على المشرفين\n• *.مود اعضاء* — السماح للجميع بالأوامر",
      });
    }

  } else if (trimmed === ".تعطيل") {
    if (!isOwner) return;
    if (!isGroup) {
      await sock.sendMessage(jid, { text: "❌ هذا الأمر يعمل في الجروبات فقط." });
    } else {
      deactivateGroup(jid);
      await sock.sendMessage(jid, { text: "❌ تم تعطيل البوت في هذا الجروب" });
    }

  // Commands list
  } else if (trimmed === ".اوامر") {
    await handleCommands(sock, jid);
  }
}

// ── Bot startup ───────────────────────────────────────────────────────────────

async function startBot(): Promise<void> {
  // FIX: Reconnect guard — bail out if already connecting to prevent stacked instances
  if (_isConnecting) {
    logger.warn("startBot called while already connecting — skipping duplicate");
    return;
  }
  _isConnecting = true;

  // Only init data stores on the very first call (idempotent, but avoids log noise)
  initDb();
  initGangs();
  initGroups();
  initGroupState();
  logger.info("Starting WhatsApp bot...");

  try {
    // FIX: Use SESSION_DIR (correct persistent folder) instead of hardcoded "sessions-temp"
    const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      version,
      auth: state,
      printQRInTerminal: true,
      logger: silentLogger,
      browser: ["WhatsApp Bot", "Chrome", "1.0.0"],
      connectTimeoutMs: 60_000,
      defaultQueryTimeoutMs: 60_000,
      keepAliveIntervalMs: 30_000,
      markOnlineOnConnect: false,
    });

    setSocket(sock);
    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", (update) => {
      const { connection, lastDisconnect, qr } = update;

      // FIX: QR — set in shared state so dashboard WS broadcast fires
      if (qr && !getSocket()) {
        // Clear any previous QR expiry timer before starting a fresh one
        if (_qrRefreshTimer) { clearTimeout(_qrRefreshTimer); _qrRefreshTimer = null; }

        logger.info("QR code updated — scan with WhatsApp");
        setQR(qr);
        addActivityLog("connection", "QR code generated — scan within 2 minutes");

        // Auto-refresh: if QR not scanned in 2 minutes, restart connection for a new QR
        _qrRefreshTimer = setTimeout(() => {
          _qrRefreshTimer = null;
          logger.info("QR code expired (2 min) — restarting to generate fresh QR");
          addActivityLog("connection", "QR expired — generating fresh QR code");
          try { sock.end(undefined); } catch { /* sock may already be closed */ }
        }, QR_TTL_MS);
      }

      if (connection === "close") {
        // Cancel any pending QR refresh timer on disconnect
        if (_qrRefreshTimer) { clearTimeout(_qrRefreshTimer); _qrRefreshTimer = null; }

        setConnected(false);
        setSocket(null);
        // FIX: Release the guard so the next reconnect call can proceed
        _isConnecting = false;

        const statusCode = (lastDisconnect?.error as Boom)?.output?.statusCode;
        // FIX: Never reconnect on 401 (logged out) — only reconnect on transient errors
        const shouldReconnect =
          statusCode !== DisconnectReason.loggedOut &&
          statusCode !== 401;

        logger.info({ statusCode, shouldReconnect }, "Connection closed");
        addActivityLog(
          "connection",
          `Disconnected (code ${statusCode ?? "unknown"}) — ${shouldReconnect ? "reconnecting" : "logged out"}`,
        );

        if (shouldReconnect) {
          // FIX: Longer back-off on timeout (408), standard 5s otherwise
          const delay = statusCode === 408 ? 10_000 : 5_000;
          setTimeout(() => { void startBot(); }, delay);
        } else {
          logger.warn("Logged out (401) — delete sessions/ folder and restart to re-pair");
          addActivityLog("error", "Logged out — manual re-pair required. Delete sessions/ folder and restart.");
        }
      } else if (connection === "open") {
        // Cancel QR timer — device scanned successfully
        if (_qrRefreshTimer) { clearTimeout(_qrRefreshTimer); _qrRefreshTimer = null; }

        setConnected(true);
        // FIX: Release guard on successful connection
        _isConnecting = false;
        logger.info("WhatsApp bot connected successfully!");
        addActivityLog("connection", "WhatsApp connected successfully");
        // FIX: Only start event scheduler once per process lifetime
        if (!_eventSchedulerStarted) {
          _eventSchedulerStarted = true;
          startEventScheduler(sock);
        }
      }
    });

  // ── Group participants update (welcome / goodbye) ─────────────────────────
  sock.ev.on("group-participants.update", async ({ id, participants, action }) => {
    try {
      const jids = participants.map((p) =>
        typeof p === "string" ? p : (p as { id: string }).id,
      );
      await handleParticipantsUpdate(sock, id, jids, action as "add" | "remove" | "promote" | "demote");
    } catch (err) {
      logger.error({ err }, "group-participants.update error");
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue;
      try {
        const jid = msg.key.remoteJid ?? null;
        const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
        if (text?.startsWith(".")) {
          addActivityLog("command", text.split(" ")[0] ?? text, jid);
        }
        await handleMessage(sock, msg);
      } catch (err) {
        logger.error({ err }, "Error handling message");
        const jid = msg.key.remoteJid ?? null;
        addActivityLog(
          "error",
          `Error handling message: ${err instanceof Error ? err.message : String(err)}`,
          jid,
        );
      }
    }
  });

  } catch (err) {
    // FIX: Release guard on unexpected startup failure so reconnect can retry
    _isConnecting = false;
    logger.error({ err }, "Bot startup failed");
    addActivityLog("error", `Bot startup error: ${err instanceof Error ? err.message : String(err)}`);
    // Retry after a short delay
    setTimeout(() => { void startBot(); }, 10_000);
  }
}

/**
 * restartBot — clears the session folder and forces a fresh connection + new QR.
 * Safe to call at any time; resets all guards so startBot() can proceed cleanly.
 */
export async function restartBot(): Promise<void> {
  const { rmSync } = await import("fs");

  logger.info("restartBot: initiated by operator");
  addActivityLog("connection", "Manual restart initiated — clearing session");

  // Cancel any pending QR refresh timer
  if (_qrRefreshTimer) { clearTimeout(_qrRefreshTimer); _qrRefreshTimer = null; }

  // Reset connecting guard so the next startBot() call is not blocked
  _isConnecting = false;

  // Delete session files so Baileys starts fresh (generates a new QR)
  try {
    rmSync(SESSION_DIR, { recursive: true, force: true });
    logger.info("restartBot: session files deleted");
  } catch (err) {
    logger.warn({ err }, "restartBot: could not delete session files");
  }

  // Clear current connection state
  setConnected(false);
  clearQR();

  // If there is an active socket, end it — the close handler will call startBot() after a delay.
  // If there is no socket, kick off startBot() directly.
  const currentSock = getSocket();
  if (currentSock) {
    try { currentSock.end(undefined); } catch { /* already closed */ }
  } else {
    setTimeout(() => { void startBot(); }, 1_000);
  }
}

export { startBot };
