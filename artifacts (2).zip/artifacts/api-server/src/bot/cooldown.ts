/**
 * Global per-user cooldown manager.
 * Usage:
 *   const { ok, remainingMs } = checkCooldown(jid, "steal", 30 * 60_000);
 *   if (!ok) { ...show wait message... } else { setCooldown(jid, "steal"); }
 */

const cooldowns = new Map<string, Map<string, number>>();

export interface CooldownResult {
  ok: boolean;
  remainingMs: number;
}

export function checkCooldown(userId: string, action: string, ms: number): CooldownResult {
  const userMap = cooldowns.get(userId);
  const lastUsed = userMap?.get(action) ?? 0;
  const remaining = lastUsed + ms - Date.now();
  if (remaining > 0) return { ok: false, remainingMs: remaining };
  return { ok: true, remainingMs: 0 };
}

export function setCooldown(userId: string, action: string): void {
  let userMap = cooldowns.get(userId);
  if (!userMap) { userMap = new Map<string, number>(); cooldowns.set(userId, userMap); }
  userMap.set(action, Date.now());
}

export function clearCooldown(userId: string, action: string): void {
  cooldowns.get(userId)?.delete(action);
}

export function msToHuman(ms: number): string {
  const totalSecs = Math.ceil(ms / 1000);
  if (totalSecs < 60) return `${totalSecs} ثانية`;
  const totalMins = Math.ceil(ms / 60_000);
  if (totalMins < 60) return `${totalMins} دقيقة`;
  const hours = Math.floor(totalMins / 60);
  const mins = totalMins % 60;
  return mins > 0 ? `${hours} ساعة و${mins} دقيقة` : `${hours} ساعة`;
}
