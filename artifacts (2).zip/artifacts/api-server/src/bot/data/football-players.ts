export interface FootballPlayer {
  nameAr: string;
  nameEn: string;
  searchName: string;
  club: string;
  nationality: string;
}

export const FOOTBALL_PLAYERS: FootballPlayer[] = [
  { nameAr: "ميسي",          nameEn: "messi",        searchName: "Lionel Messi",       club: "إنتر ميامي",         nationality: "أرجنتيني" },
  { nameAr: "رونالدو",        nameEn: "ronaldo",      searchName: "Cristiano Ronaldo",  club: "النصر",              nationality: "برتغالي" },
  { nameAr: "نيمار",          nameEn: "neymar",       searchName: "Neymar",             club: "الهلال",             nationality: "برازيلي" },
  { nameAr: "مبابي",          nameEn: "mbappe",       searchName: "Kylian Mbappe",      club: "ريال مدريد",         nationality: "فرنسي" },
  { nameAr: "بنزيما",         nameEn: "benzema",      searchName: "Karim Benzema",      club: "الاتحاد",            nationality: "فرنسي" },
  { nameAr: "صلاح",           nameEn: "salah",        searchName: "Mohamed Salah",      club: "ليفربول",            nationality: "مصري" },
  { nameAr: "ديبروين",        nameEn: "de bruyne",    searchName: "Kevin De Bruyne",    club: "مانشستر سيتي",       nationality: "بلجيكي" },
  { nameAr: "ليفاندوفسكي",    nameEn: "lewandowski",  searchName: "Robert Lewandowski", club: "برشلونة",            nationality: "بولندي" },
  { nameAr: "هالاند",         nameEn: "haaland",      searchName: "Erling Haaland",     club: "مانشستر سيتي",       nationality: "نرويجي" },
  { nameAr: "كين",            nameEn: "kane",         searchName: "Harry Kane",         club: "بايرن ميونخ",        nationality: "إنجليزي" },
  { nameAr: "فينيسيوس",       nameEn: "vinicius",     searchName: "Vinicius Junior",    club: "ريال مدريد",         nationality: "برازيلي" },
  { nameAr: "بيليينغهام",     nameEn: "bellingham",   searchName: "Jude Bellingham",    club: "ريال مدريد",         nationality: "إنجليزي" },
  { nameAr: "يامال",          nameEn: "yamal",        searchName: "Lamine Yamal",       club: "برشلونة",            nationality: "إسباني" },
  { nameAr: "رودري",          nameEn: "rodri",        searchName: "Rodri",              club: "مانشستر سيتي",       nationality: "إسباني" },
  { nameAr: "مودريتش",        nameEn: "modric",       searchName: "Luka Modric",        club: "ريال مدريد",         nationality: "كرواتي" },
  { nameAr: "كروس",           nameEn: "kroos",        searchName: "Toni Kroos",         club: "ريال مدريد",         nationality: "ألماني" },
  { nameAr: "سالاه",          nameEn: "salah",        searchName: "Mohamed Salah",      club: "ليفربول",            nationality: "مصري" },
  { nameAr: "سون",            nameEn: "son",          searchName: "Son Heung-min",      club: "توتنهام",            nationality: "كوري" },
  { nameAr: "رشفورد",         nameEn: "rashford",     searchName: "Marcus Rashford",    club: "مانشستر يونايتد",    nationality: "إنجليزي" },
  { nameAr: "غريزمان",        nameEn: "griezmann",    searchName: "Antoine Griezmann",  club: "أتلتيكو مدريد",      nationality: "فرنسي" },
  { nameAr: "ديمبيلي",        nameEn: "dembele",      searchName: "Ousmane Dembele",    club: "برشلونة",            nationality: "فرنسي" },
  { nameAr: "ماونت",          nameEn: "mount",        searchName: "Mason Mount",        club: "مانشستر يونايتد",    nationality: "إنجليزي" },
  { nameAr: "فيرمينو",        nameEn: "firmino",      searchName: "Roberto Firmino",    club: "الاتحاد",            nationality: "برازيلي" },
  { nameAr: "ألابا",          nameEn: "alaba",        searchName: "David Alaba",        club: "ريال مدريد",         nationality: "نمساوي" },
];

export function randomPlayer(excludeEn?: string): FootballPlayer {
  const pool = excludeEn
    ? FOOTBALL_PLAYERS.filter((p) => p.nameEn !== excludeEn)
    : FOOTBALL_PLAYERS;
  return pool[Math.floor(Math.random() * pool.length)]!;
}
