export interface AnimeCharacter {
  anilistId: number;
  nameAr: string;
  nameEn: string;
  series: string;
}

export const ANIME_CHARACTERS: AnimeCharacter[] = [
  { anilistId: 17,     nameAr: "ناروتو",    nameEn: "naruto",     series: "ناروتو" },
  { anilistId: 13,     nameAr: "ساسكي",     nameEn: "sasuke",     series: "ناروتو" },
  { anilistId: 85,     nameAr: "كاكاشي",    nameEn: "kakashi",    series: "ناروتو" },
  { anilistId: 3247,   nameAr: "إيتاشي",    nameEn: "itachi",     series: "ناروتو" },
  { anilistId: 40,     nameAr: "لوفي",      nameEn: "luffy",      series: "ون بيس" },
  { anilistId: 62,     nameAr: "زورو",      nameEn: "zoro",       series: "ون بيس" },
  { anilistId: 65,     nameAr: "سانجي",     nameEn: "sanji",      series: "ون بيس" },
  { anilistId: 246,    nameAr: "غوكو",      nameEn: "goku",       series: "دراغون بول" },
  { anilistId: 913,    nameAr: "فيجيتا",    nameEn: "vegeta",     series: "دراغون بول" },
  { anilistId: 40882,  nameAr: "إيرين",     nameEn: "eren",       series: "هجوم العمالقة" },
  { anilistId: 36828,  nameAr: "ليفاي",     nameEn: "levi",       series: "هجوم العمالقة" },
  { anilistId: 40881,  nameAr: "ميكاسا",    nameEn: "mikasa",     series: "هجوم العمالقة" },
  { anilistId: 11,     nameAr: "إدوارد",    nameEn: "edward",     series: "المحول الكيميائي" },
  { anilistId: 71,     nameAr: "L",         nameEn: "l",          series: "دفتر الموت" },
  { anilistId: 70,     nameAr: "لايت",      nameEn: "light",      series: "دفتر الموت" },
  { anilistId: 5,      nameAr: "إيتشيغو",   nameEn: "ichigo",     series: "بليتش" },
  { anilistId: 34,     nameAr: "كيلوا",     nameEn: "killua",     series: "هانتر" },
  { anilistId: 30,     nameAr: "غون",       nameEn: "gon",        series: "هانتر" },
  { anilistId: 120500, nameAr: "تانجيرو",   nameEn: "tanjiro",    series: "قاتل الشياطين" },
  { anilistId: 120502, nameAr: "زينيتسو",   nameEn: "zenitsu",    series: "قاتل الشياطين" },
  { anilistId: 120501, nameAr: "نيزوكو",    nameEn: "nezuko",     series: "قاتل الشياطين" },
  { anilistId: 98470,  nameAr: "ديكو",      nameEn: "deku",       series: "أكاديمية الأبطال" },
  { anilistId: 98471,  nameAr: "باكوغو",    nameEn: "bakugo",     series: "أكاديمية الأبطال" },
  { anilistId: 98472,  nameAr: "تودوروكي",  nameEn: "todoroki",   series: "أكاديمية الأبطال" },
  { anilistId: 1,      nameAr: "سبايك",     nameEn: "spike",      series: "كاوبوي بيبوب" },
  { anilistId: 127083, nameAr: "ريم",       nameEn: "rem",        series: "ري زيرو" },
  { anilistId: 116543, nameAr: "زيرو تو",   nameEn: "zero two",   series: "دارلينغ" },
  { anilistId: 65496,  nameAr: "دازاي",     nameEn: "dazai",      series: "أوساكا بونغو ستراي دوغز" },
  { anilistId: 100181, nameAr: "ميليوداس",  nameEn: "meliodas",   series: "الخطايا السبع" },
  { anilistId: 57,     nameAr: "نامي",      nameEn: "nami",       series: "ون بيس" },
];

export function randomCharacter(excludeId?: number): AnimeCharacter {
  const pool = excludeId !== undefined
    ? ANIME_CHARACTERS.filter((c) => c.anilistId !== excludeId)
    : ANIME_CHARACTERS;
  return pool[Math.floor(Math.random() * pool.length)]!;
}
