export interface ShopItem {
  id: string;
  nameAr: string;
  description: string;
  price: number;
  uses: number;
  keywords: string[];
}

export const SHOP_ITEMS: ShopItem[] = [
  {
    id: "coin_boost",
    nameAr: "مضاعف فلوس",
    description: "ضاعف عملاتك في جولات الألعاب الثلاث القادمة",
    price: 50_000,
    uses: 3,
    keywords: ["مضاعف", "فلوس", "عملات"],
  },
  {
    id: "xp_boost",
    nameAr: "زيادة XP",
    description: "ضاعف نقاط XP في الخمس إجابات الصحيحة القادمة",
    price: 30_000,
    uses: 5,
    keywords: ["xp", "إكس بي", "زيادة", "نقاط"],
  },
  {
    id: "shield",
    nameAr: "حماية من الخسارة",
    description: "احمِ محفظتك من خسائر الألعاب مرة واحدة",
    price: 20_000,
    uses: 1,
    keywords: ["حماية", "درع", "خسارة"],
  },
];

export function findItem(query: string): ShopItem | undefined {
  const q = query.toLowerCase().trim();
  return SHOP_ITEMS.find(
    (item) =>
      item.nameAr.includes(q) ||
      item.id === q ||
      item.keywords.some((k) => q.includes(k) || k.includes(q)),
  );
}
