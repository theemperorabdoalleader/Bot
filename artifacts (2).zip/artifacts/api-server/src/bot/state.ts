import type { WASocket } from "@whiskeysockets/baileys";

export interface Reminder {
  id: number;
  message: string;
  dueAt: Date;
  timeoutId: ReturnType<typeof setTimeout>;
}

export interface GameSession {
  type: "eye" | "player" | "riddle";
  answer: string;
  altAnswers: string[];
  displayAnswer: string;
  timeout: ReturnType<typeof setTimeout>;
}

export interface PendingChallenge {
  challengerJid: string;
  challengedJid: string;
  amount: number;
  gameType: string;
  timeout: ReturnType<typeof setTimeout>;
}

export interface ActiveChallengeGame {
  challengerJid: string;
  challengedJid: string;
  amount: number;
  gameAnswer: string;
  gameAltAnswers: string[];
  gameDisplayAnswer: string;
  timeout: ReturnType<typeof setTimeout>;
}

export interface XOGame {
  board: string[];
  xPlayerJid: string;
  oPlayerJid: string;
  currentTurn: "X" | "O";
  amount: number;
  timeout: ReturnType<typeof setTimeout>;
}

export interface BossState {
  hp: number;
  maxHp: number;
  lastAttackerJid: string;
  timeout: ReturnType<typeof setTimeout>;
}

export interface RandomEvent {
  answer: string;
  reward: number;
  timeout: ReturnType<typeof setTimeout>;
  alts?: string[];
}

// --- Singletons ---
let currentQR: string | null = null;
let isConnected = false;
let nextReminderId = 1;
let startTime: number | null = null;
let activeSocket: WASocket | null = null;

// --- Maps ---
const reminders = new Map<string, Reminder[]>();
const activeGames = new Map<string, GameSession>();
const pendingChallenges = new Map<string, PendingChallenge>();
const activeChallengeGames = new Map<string, ActiveChallengeGame>();
const activeXOGames = new Map<string, XOGame>();
const activeBosses = new Map<string, BossState>();
const activeEvents = new Map<string, RandomEvent>();
const activeChats = new Set<string>();
const autoAiGroups = new Set<string>();

// ── Event hooks (called by index.ts to wire WS broadcasts) ───────────────────
let _onNewLog: ((entry: ActivityLogEntry) => void) | null = null;
let _onStatusChange: (() => void) | null = null;
let _onQrChange: (() => void) | null = null;
export function setOnNewLog(fn: (entry: ActivityLogEntry) => void): void { _onNewLog = fn; }
export function setOnStatusChange(fn: () => void): void { _onStatusChange = fn; }
export function setOnQrChange(fn: () => void): void { _onQrChange = fn; }

// ── QR / connection ──────────────────────────────────────────────────────────
export function getQR(): string | null { return currentQR; }
export function setQR(qr: string): void {
  currentQR = qr; isConnected = false;
  _onQrChange?.();
}
export function clearQR(): void {
  currentQR = null;
  _onQrChange?.();
}
export function getIsConnected(): boolean { return isConnected; }
export function setConnected(connected: boolean): void {
  isConnected = connected;
  if (connected) { currentQR = null; startTime = Date.now(); }
  else { startTime = null; }
  _onStatusChange?.();
}
export function getUptime(): number | null {
  if (!isConnected || startTime === null) return null;
  return Math.floor((Date.now() - startTime) / 1000);
}
export function setSocket(sock: WASocket | null): void { activeSocket = sock; }
export function getSocket(): WASocket | null { return activeSocket; }

// ── Active chats (for random events) ─────────────────────────────────────────
export function trackChat(jid: string): void { activeChats.add(jid); }
export function getActiveChats(): Set<string> { return activeChats; }

// ── Command users (only users who have sent at least one bot command) ─────────
const commandUsers = new Set<string>();
export function trackCommandUser(senderJid: string): void { commandUsers.add(senderJid); }
export function getCommandUserCount(): number { return commandUsers.size; }

// ── Reminders ────────────────────────────────────────────────────────────────
export function addReminder(jid: string, minutes: number, message: string, onFire: () => void): Reminder {
  const id = nextReminderId++;
  const dueAt = new Date(Date.now() + minutes * 60 * 1000);
  const timeoutId = setTimeout(onFire, minutes * 60 * 1000);
  const reminder: Reminder = { id, message, dueAt, timeoutId };
  if (!reminders.has(jid)) reminders.set(jid, []);
  reminders.get(jid)!.push(reminder);
  return reminder;
}
export function removeReminder(jid: string, id: number): void {
  const list = reminders.get(jid);
  if (!list) return;
  const idx = list.findIndex((r) => r.id === id);
  if (idx !== -1) { clearTimeout(list[idx]!.timeoutId); list.splice(idx, 1); }
}
export function getReminders(jid: string): Reminder[] { return reminders.get(jid) ?? []; }

// ── Solo games ────────────────────────────────────────────────────────────────
export function getActiveGame(jid: string): GameSession | undefined { return activeGames.get(jid); }
export function setActiveGame(jid: string, session: GameSession): void {
  const existing = activeGames.get(jid);
  if (existing) clearTimeout(existing.timeout);
  activeGames.set(jid, session);
}
export function clearActiveGame(jid: string): void {
  const existing = activeGames.get(jid);
  if (existing) { clearTimeout(existing.timeout); activeGames.delete(jid); }
}

// ── Pending challenges ────────────────────────────────────────────────────────
export function getPendingChallenge(jid: string): PendingChallenge | undefined { return pendingChallenges.get(jid); }
export function setPendingChallenge(jid: string, c: PendingChallenge): void {
  const existing = pendingChallenges.get(jid);
  if (existing) clearTimeout(existing.timeout);
  pendingChallenges.set(jid, c);
}
export function clearPendingChallenge(jid: string): void {
  const existing = pendingChallenges.get(jid);
  if (existing) { clearTimeout(existing.timeout); pendingChallenges.delete(jid); }
}

// ── Active challenge games (لغز / عين / لاعب) ────────────────────────────────
export function getActiveChallengeGame(jid: string): ActiveChallengeGame | undefined { return activeChallengeGames.get(jid); }
export function setActiveChallengeGame(jid: string, g: ActiveChallengeGame): void {
  const existing = activeChallengeGames.get(jid);
  if (existing) clearTimeout(existing.timeout);
  activeChallengeGames.set(jid, g);
}
export function clearActiveChallengeGame(jid: string): void {
  const existing = activeChallengeGames.get(jid);
  if (existing) { clearTimeout(existing.timeout); activeChallengeGames.delete(jid); }
}

// ── XO games ─────────────────────────────────────────────────────────────────
export function getActiveXOGame(jid: string): XOGame | undefined { return activeXOGames.get(jid); }
export function setActiveXOGame(jid: string, g: XOGame): void {
  const existing = activeXOGames.get(jid);
  if (existing) clearTimeout(existing.timeout);
  activeXOGames.set(jid, g);
}
export function clearActiveXOGame(jid: string): void {
  const existing = activeXOGames.get(jid);
  if (existing) { clearTimeout(existing.timeout); activeXOGames.delete(jid); }
}

// ── Boss system ───────────────────────────────────────────────────────────────
export function getActiveBoss(jid: string): BossState | undefined { return activeBosses.get(jid); }
export function setActiveBoss(jid: string, b: BossState): void {
  const existing = activeBosses.get(jid);
  if (existing) clearTimeout(existing.timeout);
  activeBosses.set(jid, b);
}
export function clearActiveBoss(jid: string): void {
  const existing = activeBosses.get(jid);
  if (existing) { clearTimeout(existing.timeout); activeBosses.delete(jid); }
}

// ── Random events ─────────────────────────────────────────────────────────────
export function getActiveEvent(jid: string): RandomEvent | undefined { return activeEvents.get(jid); }
export function setActiveEvent(jid: string, e: RandomEvent): void {
  const existing = activeEvents.get(jid);
  if (existing) clearTimeout(existing.timeout);
  activeEvents.set(jid, e);
}
export function clearActiveEvent(jid: string): void {
  const existing = activeEvents.get(jid);
  if (existing) { clearTimeout(existing.timeout); activeEvents.delete(jid); }
}

// ── Auto AI mode ─────────────────────────────────────────────────────────────
export function getAutoAiMode(chatJid: string): boolean { return autoAiGroups.has(chatJid); }
export function toggleAutoAiMode(chatJid: string): boolean {
  if (autoAiGroups.has(chatJid)) { autoAiGroups.delete(chatJid); return false; }
  autoAiGroups.add(chatJid); return true;
}

// ── Activity log ──────────────────────────────────────────────────────────────
export interface ActivityLogEntry {
  id: number;
  timestamp: number;
  type: "command" | "connection" | "error" | "info";
  jid: string | null;
  message: string;
}

const MAX_LOG_ENTRIES = 200;
const activityLog: ActivityLogEntry[] = [];
let nextLogId = 1;

export function addActivityLog(
  type: ActivityLogEntry["type"],
  message: string,
  jid: string | null = null,
): void {
  const entry: ActivityLogEntry = { id: nextLogId++, timestamp: Date.now(), type, jid, message };
  activityLog.unshift(entry);
  if (activityLog.length > MAX_LOG_ENTRIES) activityLog.length = MAX_LOG_ENTRIES;
  _onNewLog?.(entry);
}

export function getActivityLogs(): ActivityLogEntry[] {
  return activityLog;
}
