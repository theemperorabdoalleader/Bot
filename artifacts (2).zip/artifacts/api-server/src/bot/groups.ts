import { existsSync, readFileSync, writeFileSync, mkdirSync } from "fs";
import { join } from "path";

const DATA_DIR = join(process.cwd(), "data");
const GROUPS_FILE = join(DATA_DIR, "groups.json");

interface GroupsDB {
  groups: string[];
}

let cache: GroupsDB = { groups: [] };

export function initGroups(): void {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
  if (existsSync(GROUPS_FILE)) {
    try { cache = JSON.parse(readFileSync(GROUPS_FILE, "utf8")) as GroupsDB; } catch { cache = { groups: [] }; }
  }
  if (!Array.isArray(cache.groups)) cache.groups = [];
}

function save(): void {
  writeFileSync(GROUPS_FILE, JSON.stringify(cache, null, 2), "utf8");
}

export function isGroupAllowed(jid: string): boolean {
  return cache.groups.includes(jid);
}

export function activateGroup(jid: string): boolean {
  if (cache.groups.includes(jid)) return false;
  cache.groups.push(jid);
  save();
  return true;
}

export function deactivateGroup(jid: string): boolean {
  const idx = cache.groups.indexOf(jid);
  if (idx === -1) return false;
  cache.groups.splice(idx, 1);
  save();
  return true;
}
