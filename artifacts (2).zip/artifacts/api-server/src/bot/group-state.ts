/**
 * Per-group persistent state:
 *  - mode:       "admins" | "members"  (who can use bot commands)
 *  - mutedUsers: string[]              (JIDs that are muted — messages auto-deleted)
 *
 * Persisted to data/group-settings.json
 */
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "fs";
import { join } from "path";

export type GroupMode = "admins" | "members";

interface GroupSettings {
  mode: GroupMode;
  mutedUsers: string[];
}

interface GroupSettingsDB {
  groups: Record<string, GroupSettings>;
}

const DATA_DIR  = join(process.cwd(), "data");
const SETTINGS_FILE = join(DATA_DIR, "group-settings.json");

let db: GroupSettingsDB = { groups: {} };

function defaults(): GroupSettings {
  return { mode: "members", mutedUsers: [] };
}

export function initGroupState(): void {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
  if (existsSync(SETTINGS_FILE)) {
    try {
      const raw = JSON.parse(readFileSync(SETTINGS_FILE, "utf8")) as GroupSettingsDB;
      db = raw;
    } catch {
      db = { groups: {} };
    }
  }
  if (!db.groups || typeof db.groups !== "object") db.groups = {};
}

function getSettings(groupJid: string): GroupSettings {
  if (!db.groups[groupJid]) db.groups[groupJid] = defaults();
  return db.groups[groupJid]!;
}

function persist(): void {
  writeFileSync(SETTINGS_FILE, JSON.stringify(db, null, 2), "utf8");
}

// ── Mode ──────────────────────────────────────────────────────────────────────

export function getGroupMode(groupJid: string): GroupMode {
  return getSettings(groupJid).mode;
}

export function setGroupMode(groupJid: string, mode: GroupMode): void {
  getSettings(groupJid).mode = mode;
  persist();
}

// ── Muted users ───────────────────────────────────────────────────────────────

export function isUserMuted(groupJid: string, userJid: string): boolean {
  return getSettings(groupJid).mutedUsers.includes(userJid);
}

export function muteUser(groupJid: string, userJid: string): boolean {
  const s = getSettings(groupJid);
  if (s.mutedUsers.includes(userJid)) return false;
  s.mutedUsers.push(userJid);
  persist();
  return true;
}

export function unmuteUser(groupJid: string, userJid: string): boolean {
  const s = getSettings(groupJid);
  const idx = s.mutedUsers.indexOf(userJid);
  if (idx === -1) return false;
  s.mutedUsers.splice(idx, 1);
  persist();
  return true;
}

export function getMutedUsers(groupJid: string): string[] {
  return [...getSettings(groupJid).mutedUsers];
}
