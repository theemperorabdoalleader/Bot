/**
 * Single source of truth for all bot commands.
 * Used by:
 *   - allcommands.ts  → builds the Arabic WhatsApp text reply
 *   - routes/commands.ts → exposes /api/commands endpoint for the dashboard
 */

export interface CommandItem {
  cmd: string;
  desc: string;
}

export interface CommandCategory {
  category: string;
  categoryAr: string;
  emoji: string;
  items: CommandItem[];
}

export const COMMAND_REGISTRY: CommandCategory[] = [
  {
    category: "Media",
    categoryAr: "ميديا",
    emoji: "🎬",
    items: [
      { cmd: ".صور <query>", desc: "بحث عن صور (حتى 10)" },
      { cmd: ".ترجم <text>", desc: "ترجمة عربي ↔ إنجليزي" },
      { cmd: ".ملخص <text>", desc: "تلخيص نص بالعربي" },
      { cmd: ".يوتيوب <query>", desc: "بحث وتحميل يوتيوب" },
      { cmd: ".اديت <query>", desc: "بحث تيك توك" },
      { cmd: ".صوت <query>", desc: "بحث صوتي" },
      { cmd: ".ترند", desc: "الفيديوهات الرائجة" },
      { cmd: ".انمي <query>", desc: "بحث أنمي" },
      { cmd: ".ميم", desc: "ميم عشوائي" },
    ],
  },
  {
    category: "Economy",
    categoryAr: "الاقتصاد",
    emoji: "💰",
    items: [
      { cmd: ".رصيدي", desc: "المحفظة والبنك" },
      { cmd: ".بنك", desc: "تفاصيل البنك + الفائدة" },
      { cmd: ".ايداع <مبلغ>", desc: "إيداع في البنك" },
      { cmd: ".سحب <مبلغ>", desc: "سحب من البنك" },
      { cmd: ".فائدة", desc: "جمع فائدة البنك 5% يومياً" },
      { cmd: ".حظ", desc: "حظ عشوائي (كل ساعة)" },
      { cmd: ".يومي", desc: "مكافأة يومية مع سلسلة 🔥" },
      { cmd: ".تحويل @user <مبلغ>", desc: "تحويل عملات (رسوم 2%)" },
      { cmd: ".سجل", desc: "سجل آخر 10 معاملات" },
    ],
  },
  {
    category: "Steal & Gambling",
    categoryAr: "السرقة والقمار",
    emoji: "🎰",
    items: [
      { cmd: ".سرقة @user", desc: "سرقة محفظة (كولداون 30 دقيقة)" },
      { cmd: ".خروج", desc: "الخروج من السجن" },
      { cmd: ".قمار <مبلغ>", desc: "قمار على ضعف المبلغ" },
      { cmd: ".صندوق", desc: "صندوق مكافآت (كل 30 دقيقة)" },
    ],
  },
  {
    category: "PvP & Boss",
    categoryAr: "PvP والزعيم",
    emoji: "⚔️",
    items: [
      { cmd: ".دوري @user <مبلغ>", desc: "تحدي دوري PvP (ELO)" },
      { cmd: ".قبول_دوري", desc: "قبول تحدي الدوري" },
      { cmd: ".زعيم", desc: "استدعاء زعيم (مستويات 1–5)" },
      { cmd: ".هجوم", desc: "الهجوم على الزعيم" },
      { cmd: ".تحدي @user <مبلغ>", desc: "تحدٍّ مباشر" },
      { cmd: ".قبول", desc: "قبول تحدٍّ معلق" },
    ],
  },
  {
    category: "Games",
    categoryAr: "الألعاب",
    emoji: "🎮",
    items: [
      { cmd: ".عين", desc: "خمّن شخصية أنمي" },
      { cmd: ".لاعب", desc: "خمّن اللاعب" },
      { cmd: ".لغز", desc: "حل اللغز" },
      { cmd: ".xo @user <مبلغ>", desc: "لعبة XO" },
      { cmd: ".صراحة", desc: "سؤال عشوائي" },
      { cmd: ".جرأة", desc: "تحدي عشوائي" },
      { cmd: ".زواج @user1 @user2", desc: "اختبار الزواج" },
      { cmd: ".يحبك @user", desc: "من يحبك" },
      { cmd: ".يكرهني @user", desc: "من يكرهك" },
      { cmd: ".ذكاء", desc: "اختبار الذكاء" },
    ],
  },
  {
    category: "Levels & Ranking",
    categoryAr: "الرتب والمستويات",
    emoji: "📈",
    items: [
      { cmd: ".لفلي", desc: "الرتبة + الفئة التنافسية + PvP" },
      { cmd: ".الاباطرة", desc: "أغنى 5 لاعبين" },
      { cmd: ".الجيش", desc: "أعلى 5 رتباً XP" },
      { cmd: ".متجر", desc: "عرض المتجر" },
      { cmd: ".شراء <عنصر>", desc: "شراء عنصر" },
      { cmd: ".vip", desc: "حالة VIP" },
      { cmd: ".شراء_vip", desc: "شراء VIP (200k عملة)" },
      { cmd: ".تطوير", desc: "تطوير العملات أو XP" },
    ],
  },
  {
    category: "Gangs",
    categoryAr: "العصابات",
    emoji: "🏴",
    items: [
      { cmd: ".انشاء_عصابة <اسم>", desc: "أنشئ عصابة" },
      { cmd: ".انضمام <اسم>", desc: "انضم لعصابة" },
      { cmd: ".عصابتي", desc: "معلومات عصابتك" },
      { cmd: ".حرب <اسم>", desc: "اعلن حرباً على عصابة" },
    ],
  },
  {
    category: "Missions & Achievements",
    categoryAr: "المهام والإنجازات",
    emoji: "📋",
    items: [
      { cmd: ".مهامي", desc: "مهامك اليومية" },
      { cmd: ".انجازاتي", desc: "إنجازاتك" },
      { cmd: ".تذكير <دقائق> <رسالة>", desc: "ضبط تذكير" },
      { cmd: ".تذكيراتي", desc: "قائمة التذكيرات" },
    ],
  },
  {
    category: "AI",
    categoryAr: "الذكاء الاصطناعي",
    emoji: "🤖",
    items: [
      { cmd: ".اسأل <سؤال>", desc: "سؤال بذاكرة سياق" },
      { cmd: ".مسح_ذاكرة", desc: "مسح ذاكرة المحادثة مع AI" },
      { cmd: ".ذكاء_تلقائي", desc: "تفعيل/إيقاف الرد التلقائي بالـ AI" },
    ],
  },
  {
    category: "Moderation",
    categoryAr: "الإشراف",
    emoji: "🛡️",
    items: [
      { cmd: ".مود مشرفين", desc: "قصر أوامر البوت على المشرفين فقط (مشرف)" },
      { cmd: ".مود اعضاء",  desc: "السماح لجميع الأعضاء باستخدام البوت (مشرف)" },
      { cmd: ".كتم @user",  desc: "كتم مستخدم — حذف رسائله تلقائياً (مشرف)" },
      { cmd: ".الغاء كتم @user", desc: "إلغاء كتم مستخدم (مشرف)" },
      { cmd: ".حذف",        desc: "حذف رسالة مُشار إليها + أمر الحذف نفسه (مشرف)" },
    ],
  },
  {
    category: "Admin",
    categoryAr: "إدارة البوت",
    emoji: "🔐",
    items: [
      { cmd: ".تفعيل", desc: "تفعيل البوت في الجروب (المالك)" },
      { cmd: ".تعطيل", desc: "تعطيل البوت في الجروب (المالك)" },
      { cmd: ".اوامر", desc: "قائمة جميع الأوامر" },
    ],
  },
];

export const TOTAL_COMMANDS = COMMAND_REGISTRY.reduce((n, c) => n + c.items.length, 0);
