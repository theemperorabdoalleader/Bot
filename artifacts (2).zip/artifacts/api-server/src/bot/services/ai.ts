import OpenAI from "openai";

let _client: OpenAI | null = null;

function getClient(): OpenAI {
  if (!_client) {
    const apiKey = process.env["OPENAI_API_KEY"];
    if (!apiKey) {
      throw new Error("OPENAI_API_KEY is not set. AI features are unavailable.");
    }
    _client = new OpenAI({ apiKey });
  }
  return _client;
}

function isArabic(text: string): boolean {
  return /[\u0600-\u06FF]/.test(text);
}

export async function translateText(text: string): Promise<string> {
  const targetLang = isArabic(text) ? "English" : "Arabic";
  const response = await getClient().chat.completions.create({
    model: "gpt-4o-mini",
    max_tokens: 1000,
    messages: [
      {
        role: "user",
        content: `Translate the following text to ${targetLang}. Reply with only the translation, no explanations or extra text:\n\n${text}`,
      },
    ],
  });
  return response.choices[0]?.message?.content?.trim() ?? "❌ فشل في الترجمة";
}

export async function translateToEnglish(text: string): Promise<string> {
  if (!isArabic(text)) return text;
  const response = await getClient().chat.completions.create({
    model: "gpt-4o-mini",
    max_tokens: 200,
    messages: [
      {
        role: "user",
        content: `Translate the following Arabic text to English. Reply with only the translation:\n\n${text}`,
      },
    ],
  });
  return response.choices[0]?.message?.content?.trim() ?? text;
}

export async function summarizeText(text: string): Promise<string> {
  const response = await getClient().chat.completions.create({
    model: "gpt-4o-mini",
    max_tokens: 1000,
    messages: [
      {
        role: "user",
        content: `لخّص النص التالي باللغة العربية بشكل موجز وواضح. اعطِ الملخص فقط بدون مقدمة:\n\n${text}`,
      },
    ],
  });
  return response.choices[0]?.message?.content?.trim() ?? "❌ فشل في التلخيص";
}
