/**
 * Per-user AI conversation memory.
 * Keeps the last MAX_TURNS exchanges per user (volatile, resets on restart).
 */

export interface ConversationTurn {
  role: "user" | "assistant";
  content: string;
}

const MAX_TURNS = 10; // max message pairs per user
const contexts = new Map<string, ConversationTurn[]>();

export function getContext(jid: string): ConversationTurn[] {
  return [...(contexts.get(jid) ?? [])];
}

export function addToContext(jid: string, role: "user" | "assistant", content: string): void {
  const history = contexts.get(jid) ?? [];
  history.push({ role, content });
  // Keep last MAX_TURNS * 2 messages (trim oldest pairs)
  while (history.length > MAX_TURNS * 2) history.splice(0, 2);
  contexts.set(jid, history);
}

export function clearContext(jid: string): void {
  contexts.delete(jid);
}

export function getContextSize(jid: string): number {
  return contexts.get(jid)?.length ?? 0;
}
