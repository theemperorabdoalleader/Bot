const PIXABAY_API_KEY = "55968732-3137a24d161c34c1c603d3091";
const PIXABAY_BASE_URL = "https://pixabay.com/api/";

export async function searchImages(query: string, count: number): Promise<string[]> {
  const enhancedQuery = `${query} anime character HD art wallpaper`;
  const url = new URL(PIXABAY_BASE_URL);
  url.searchParams.set("key", PIXABAY_API_KEY);
  url.searchParams.set("q", enhancedQuery);
  url.searchParams.set("image_type", "illustration");
  url.searchParams.set("safesearch", "true");
  url.searchParams.set("per_page", "20");

  const res = await fetch(url.toString());
  if (!res.ok) {
    throw new Error(`Pixabay API error: ${res.status}`);
  }

  const data = (await res.json()) as {
    hits?: Array<{ webformatURL: string; largeImageURL: string }>;
    totalHits?: number;
  };

  if (!data.hits || data.hits.length === 0) {
    return [];
  }

  return data.hits.slice(0, count).map((h) => h.largeImageURL || h.webformatURL);
}

export async function fetchImageBuffer(url: string): Promise<Buffer | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const arr = await res.arrayBuffer();
    return Buffer.from(arr);
  } catch {
    return null;
  }
}
